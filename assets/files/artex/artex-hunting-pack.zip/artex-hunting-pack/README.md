# ARTEX Hunting Pack

Detection, hunting and forensics material for ARTEX, the open-source autonomous LLM pentest
framework abused in intrusions since at least August 2026 (FBI FLASH-20261113-001).

Write-up: https://thelocalh0st.com/posts/artex-detection-forensics/
Author: Sujay Adkesar. Licence: MIT.

## What is in here

| Path | What it does | Tested how |
|---|---|---|
| `tools/artex_hunter.py` | Retro-hunts web, WAF and proxy logs. Scores each source and each rotating-IP cluster on strings (L1), behaviour (L2) and kill-chain order (L3). Pulls intent numbers and zz markers out as join keys. HTML + CSV output. | Synthetic replay of four published ARTEX cases mixed with benign traffic, in six log formats; 1 million line run for speed |
| `tools/find_artex_console.py` | Finds ARTEX consoles on networks you own (`/api/health`, page title, favicon hash). | Mock console and a look-alike service on localhost |
| `sigma/*.yml` | 7 single-event rules, 5 correlation rules (Sigma 2.0), 1 Linux process rule, 1 proxy rule. | Single-event and correlation rules replayed on the synthetic log with a small evaluator; not run through pySigma backends |
| `waf/cloudflare_rules.md` | Custom rule and rate limiting expressions. | Not tested |
| `waf/aws_waf_artex_rules.json` | WAFv2 rules array for a rule group. | JSON validated only |
| `waf/modsecurity_artex.conf` | ModSecurity / Coraza rules, IDs 1009000-1009099. | Not tested |
| `waf/nginx_artex.conf`, `waf/haproxy_artex.cfg` | String blocks, real client IP handling, cross-host rate limits. | Not tested |
| `siem/splunk_artex_hunts.spl` | Nine Splunk hunts on a normalising macro. | Not tested |
| `siem/kql_artex_hunts.kql` | Eleven Sentinel / Defender XDR hunts. | Not tested |
| `iocs/artex_iocs.csv` | 92 indicators with source, date, confidence and use (block, hunt, hunt-internal). | Values checked against the cited reports |
| `lab/lab_access.log.gz` | The synthetic log used for testing. All addresses are documentation ranges. | |

## Quick start

```
python3 tools/artex_hunter.py /var/log/nginx/access.log* -o hunt --since 2026-08-01
python3 tools/artex_hunter.py lab/lab_access.log.gz -o lab_hunt      # see what a hit looks like
```

Open `hunt/report.html`. Read the evidence before you act on a score.

## Read before you block

* Strings age fast. ARTEX agents invent user agents and file names at run time.
* Proxy and VPN exits in the IOC list are shared. They are marked `hunt`, not `block`.
* Your own scanners, monitors and announced testers will score. Use `--allow-ip`.
* `tcp/8787` is also RStudio Server's default port. The console finder reads the page.
