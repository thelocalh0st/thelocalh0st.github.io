// Smoke test for the scoring engine: node tests/engine.test.js
const path = require('path');
const fs = require('fs');
const E = require('../workbench-src/app/js/engine.js');
const kb = JSON.parse(fs.readFileSync(path.join(__dirname, '../workbench-src/dist/kb.json'), 'utf8'));
const eng = JSON.parse(fs.readFileSync(path.join(__dirname, '../samples/sample-engagement.json'), 'utf8'));
const idx = E.indexKB(kb);
const s = E.summary(idx, eng);
console.log('progress', s.progress);
console.log('levels', E.ladder(idx, eng).map(r => `${r.name}: L${r.level} -> L${r.achievable} | ${r.why}`).join('\n'));
console.log('distribution', s.distribution, 'median', s.median, 'achievable median', s.achievableMedian);
console.log('findings', s.findings, s.bySev);
console.log('scenarios', E.scenarios(idx, eng).map(x => `${x.id} ${x.yes}/${x.total} (+${x.partial} partial)`).join(' | '));
console.log('domains', E.domains(idx, eng).map(d => `${d.id}:${d.score == null ? '-' : Math.round(d.score * 100)}%`).join(' '));
console.log('components', E.components(idx, eng).map(c => `${c.id}:${c.state}`).join(' '));
const kg = E.keyGrid(idx, eng); console.log('keys', JSON.stringify(kg.totals));
const h = E.horizon(idx, eng); console.log('horizon rows', h.rows.length, 'floors', h.floors.map(f => f.id + ':' + f.days).join(','));
const rm = E.roadmap(idx, eng); console.log('roadmap', rm.map(p => p.id + ':' + p.items.length).join(' '));
// invariants
const ladder = E.ladder(idx, eng);
if (ladder.some(r => r.achievable < r.level)) throw new Error('achievable below current');
const nat = { scope: eng.scope, results: {}, meta: eng.meta };
console.log('native-only levels', E.ladder(idx, nat).map(r => r.name + ':' + r.level).join(' '));
console.log('OK');
