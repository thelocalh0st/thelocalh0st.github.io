// Write the sample field runbook and the standalone client report as HTML files,
// using the Workbench's own generators.
//   node samples/export_samples.js
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..', 'workbench-src');
const css = fs.readFileSync(path.join(root, 'app', 'app.css'), 'utf8');
globalThis.window = globalThis;
globalThis.document = { querySelectorAll: () => [{ textContent: css }], getElementById: () => null, documentElement: { classList: { contains: () => false } } };
globalThis.AIFR = { views: {}, actions: {} };
const js = p => require(path.join(root, 'app', 'js', p));
['util.js', 'engine.js', 'store.js', 'importer.js', 'charts.js', 'views/results.js', 'views/runbook.js', 'views/report.js'].forEach(js);

const kb = JSON.parse(fs.readFileSync(path.join(root, 'dist', 'kb.json'), 'utf8'));
const eng = JSON.parse(fs.readFileSync(path.join(__dirname, 'sample-engagement.json'), 'utf8'));
const idx = AIFR.engine.indexKB(kb);
const S = AIFR.store;
Object.assign(S, { kb, idx, eng });
S.ui.report = {};

function write(name, html) {
  const out = path.join(__dirname, name);
  fs.writeFileSync(out, html, 'utf8');
  console.log('Wrote', out, Math.round(html.length / 1024) + ' KB');
}

const ctx = { A: AIFR, U: AIFR.util, E: AIFR.engine, C: AIFR.charts, I: AIFR.importer, S, idx, eng };
write('sample-field-runbook.html', AIFR.views.runbook.exportHTML(ctx));

// The report export downloads in the browser; capture it here instead.
AIFR.util.download = (name, html) => write('sample-client-report.html', html);
AIFR.util.toast = () => {};
S.commit = () => {};
AIFR.actions['export-report'](null, null, ctx);
