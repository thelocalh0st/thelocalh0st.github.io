"""Generate the sample engagement used to demonstrate the Workbench.

The client, people and figures are fictional. Run after `python build.py --check`
so that workbench-src/dist/kb.json exists:

    python samples/make_sample.py
"""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
KB = json.loads((ROOT / "workbench-src" / "dist" / "kb.json").read_text(encoding="utf-8"))
OUT = ROOT / "samples" / "sample-engagement.json"

SCOPE = {
    "m365-copilot": "prem", "copilot-studio": "", "chatgpt-enterprise": "ent", "claude-enterprise": "ent",
    "github-copilot": "ghec", "claude-code": "ent", "cursor": "teams", "azure-openai": "", "aws-bedrock": "",
    "ai-gateway": "litellm", "selfhosted-inference": "", "chat-frontend": "", "rag-pipeline": "", "agents-mcp": "",
    "endpoint-ai": "", "shadow-ai": "", "identity": "entra", "central-logging": "", "governance-ir": "",
}

OWNERS = {
    "m365-copilot": "Workplace technology", "chatgpt-enterprise": "Digital office", "claude-enterprise": "Engineering",
    "github-copilot": "Engineering", "claude-code": "Engineering", "cursor": "Engineering (unsanctioned pilot)",
    "azure-openai": "Cloud platform", "aws-bedrock": "Cloud platform", "ai-gateway": "AI platform team",
    "selfhosted-inference": "AI platform team", "chat-frontend": "AI platform team", "rag-pipeline": "Customer service AI",
    "agents-mcp": "AI platform team",
}

R = {
    # Microsoft 365 Copilot
    "M365-01": ("met", "UnifiedAuditLogIngestionEnabled : True (collector, 14 Oct 2026)."),
    "M365-02": ("met", "Sampled 20 CopilotInteraction records; UserIds, AppHost and AccessedResources present."),
    "M365-03": ("met", "Audit Premium; custom policy 'AI interactions' keeps CopilotInteraction for one year."),
    "M365-04": ("partial", "Retention policy on Microsoft Copilot experiences is scoped to the 300-user pilot group only."),
    "M365-05": ("partial", "92-day-old prompt and response retrieved for a pilot user; no content for a non-pilot user."),
    "M365-06": ("met", "Sentinel Microsoft 365 connector; oldest Copilot event 11 months."),
    "M365-07": ("gap", "No Preservation Lock; retention policy edits not alerted."),
    "M365-08": ("partial", "eDiscovery Manager held by two compliance staff; IR team has no standing or PIM-eligible role."),
    "M365-09": ("gap", "No DLP policy targets the Microsoft 365 Copilot location."),
    # Copilot Studio
    "CPS-01": ("gap", "Bulk-delete job removes transcripts after 30 days in all three production environments."),
    "CPS-02": ("partial", "Two of nine agents published with 'No authentication' (HR FAQ, IT helpdesk)."),
    "CPS-03": ("gap", "Application Insights not configured on any agent."),
    "CPS-04": ("met", "Agent interactions present with Copilot.Studio AppIdentity."),
    "CPS-05": ("gap", "Environment makers can edit the bulk-delete job."),
    # ChatGPT Enterprise
    "CGE-01": ("gap", "Admin key created in March 2026 but no collector is running. Nothing older than ~30 days is recoverable."),
    "CGE-02": ("gap", "No archive exists."),
    "CGE-03": ("gap", "No archive exists."),
    "CGE-04": ("met", "SAML SSO enforced for asterion.example; SCIM from Entra."),
    "CGE-05": ("partial", "Standard retention confirmed; no written owner for the retention decision."),
    "CGE-06": ("gap", "Codex enabled for 40 users; no collection."),
    "CGE-07": ("gap", "Retrieval not possible: no archive."),
    # Claude Enterprise
    "CLE-01": ("met", "Enterprise plan, 620 seats."),
    "CLE-02": ("met", "Compliance API enabled 18 Aug 2026. Coverage starts on that date."),
    "CLE-03": ("met", "Listed 50 local sessions; transcript with tool_use and tool_result retrieved."),
    "CLE-04": ("met", "No custom retention period set; captured sessions kept 6 years by default."),
    "CLE-05": ("met", "No ZDR; HIPAA readiness off. Recorded in DPIA v2."),
    "CLE-06": ("partial", "Endpoint scan: 21 of 126 Claude Code users authenticate with Console API keys."),
    "CLE-07": ("partial", "Collection uses a key that also carries delete scopes."),
    "CLE-08": ("gap", "No SIEM integration; data pulled manually on request."),
    # GitHub Copilot
    "GHC-01": ("met", "Audit log stream to Azure Event Hubs, then Sentinel (2 years)."),
    "GHC-02": ("met", "action:copilot and actor:Copilot events returned."),
    "GHC-04": ("gap", "VS Code chat sessions and Copilot CLI state stay on laptops."),
    "GHC-05": ("gap", "No policy hooks deployed."),
    "GHC-06": ("partial", "MCP registry configured but set to allow all servers."),
    "GHC-07": ("met", "Agent PR traced to requester via agent_session_id."),
    # Claude Code
    "CCD-01": ("partial", "Managed settings found on 76 of 126 endpoints with Claude Code."),
    "CCD-02": ("gap", "cleanupPeriodDays not set in managed settings; default 30 days on 118 endpoints."),
    "CCD-03": ("partial", "Compliance API covers Enterprise-signed sessions; API-key sessions not captured."),
    "CCD-04": ("gap", "No telemetry variables in managed settings."),
    "CCD-05": ("gap", "No export hooks."),
    "CCD-06": ("met", "CLAUDE_CODE_SKIP_PROMPT_HISTORY not found on any scanned endpoint."),
    "CCD-07": ("gap", "Bypass mode allowed; 9 endpoints run with defaultMode bypassPermissions."),
    # Cursor (Teams, unsanctioned pilot)
    "CUR-02": ("gap", "No hooks configured."),
    "CUR-03": ("partial", "Privacy Mode on team-wide; no owner or compensating capture recorded."),
    "CUR-04": ("gap", "Triage kit does not include Cursor databases."),
    # Azure OpenAI
    "AOA-01": ("partial", "Diagnostic settings on 3 of 5 AI resources (two dev resources missing)."),
    "AOA-02": ("gap", "Key authentication enabled on all resources; three apps share one key."),
    "AOA-03": ("partial", "APIM fronts two resources; LLM message logging enabled for the claims-assist API only."),
    "AOA-04": ("partial", "Workspace retention 90 days."),
    "AOA-05": ("gap", "No immutable export."),
    "AOA-06": ("met", "Standard abuse monitoring; no exemption requested."),
    "AOA-07": ("met", "Defender for AI services: Standard."),
    "AOA-08": ("gap", "No tracing on the claims-assist agent."),
    # AWS Bedrock
    "BDR-01": ("partial", "Invocation logging on in ap-south-1; off in eu-west-1 (EU subsidiary workloads)."),
    "BDR-02": ("gap", "CloudWatch destination only."),
    "BDR-03": ("met", "Log group retention 400 days."),
    "BDR-04": ("gap", "No Object Lock on log bucket."),
    "BDR-05": ("met", "Organisation trail, multi-Region, log file validation on."),
    "BDR-06": ("gap", "No Bedrock data event selectors."),
    "BDR-07": ("unverified", "Client states bedrock-mantle is not used; not yet checked in CloudTrail."),
    "BDR-08": ("partial", "Guardrail attached to the customer chatbot only."),
    "BDR-09": ("met", "One role per application; no Bedrock API keys."),
    # AI gateway (LiteLLM)
    "GW-01": ("partial", "Internal apps route through LiteLLM; data-science notebooks call providers directly."),
    "GW-02": ("met", "Virtual keys per application; end-user ID passed for the HR assistant."),
    "GW-03": ("gap", "store_prompts_in_spend_logs: false."),
    "GW-04": ("partial", "Spend logs exported nightly to Sentinel; no retention period set in LiteLLM."),
    "GW-05": ("gap", "Gateway team administers the export workspace."),
    "GW-06": ("met", "No secrets found in 200 sampled log rows."),
    "GW-07": ("gap", "Guardrail outcomes not logged."),
    "GW-08": ("partial", "Request IDs logged by two of five applications."),
    # Self-hosted inference
    "INF-01": ("gap", "Ollama reachable unauthenticated on two GPU workstations (OLLAMA_HOST=0.0.0.0)."),
    "INF-02": ("gap", "vLLM containers use json-file driver, 3 x 10 MB rotation."),
    "INF-03": ("gap", "No model hash manifest."),
    "INF-04": ("partial", "auditd on, no rules for model directories."),
    "INF-05": ("met", "Request logging disabled on servers by decision; content to be captured at gateway."),
    # Open WebUI
    "CHT-01": ("met", "OIDC only; local sign-up disabled."),
    "CHT-02": ("gap", "Users can permanently delete chats."),
    "CHT-03": ("gap", "AUDIT_LOG_LEVEL=NONE."),
    "CHT-04": ("partial", "Nightly backups kept 30 days."),
    # RAG
    "RAG-01": ("partial", "Chunk IDs recorded in traces for the claims-assist app only."),
    "RAG-02": ("gap", "Ingestion overwrites documents without history."),
    "RAG-03": ("gap", "pgvector database logging at default."),
    "RAG-04": ("gap", "Permission filtering not logged."),
    # Agents & MCP
    "AGT-01": ("partial", "Langfuse traces for two of four production agents."),
    "AGT-02": ("gap", "Content capture off."),
    "AGT-03": ("gap", "Agents run with the deploying developer's personal access token."),
    "AGT-04": ("gap", "Approvals given in chat; not recorded."),
    "AGT-05": ("partial", "Endpoint scan found 31 distinct MCP servers; 9 on the approved list. No MCP gateway."),
    "AGT-06": ("gap", "Langfuse Cloud plan keeps 30 days."),
    # Endpoints
    "EPT-01": ("met", "Collector run on 412 endpoints (all engineering, sample of business users)."),
    "EPT-02": ("partial", "EDR on 92% of endpoints; Windows command-line auditing off."),
    "EPT-03": ("met", "Script block logging enforced by GPO."),
    "EPT-04": ("partial", "EDR raw events 30 days; detections only in Sentinel."),
    "EPT-05": ("gap", "No central copies of local AI transcripts."),
    "EPT-06": ("gap", "Ollama exposed on 0.0.0.0 on 2 endpoints; LM Studio server on 1."),
    "EPT-07": ("met", "Domain hierarchy to NIC NTP; offsets under 50 ms."),
    "EPT-08": ("partial", "14 AI extensions found; ChatGPT Atlas on 3 Macs; no allowlist."),
    "EPT-09": ("gap", "Triage kit predates AI tools."),
    "EPT-10": ("met", "Recall disabled by Intune policy."),
    # Shadow AI
    "SHD-01": ("met", "Defender for Cloud Apps generative AI discovery active."),
    "SHD-02": ("partial", "Proxy logs 90 days in Sentinel; DNS logs not collected."),
    "SHD-03": ("gap", "No prompt-level capture for third-party AI."),
    "SHD-04": ("partial", "Endpoint DLP warns on paste to 6 AI sites; upload not covered."),
    "SHD-05": ("gap", "Personal ChatGPT and Claude sign-in not restricted."),
    "SHD-06": ("met", "60-day proxy export analysed with the AIFR shadow analyser."),
    # Identity
    "IDN-01": ("met", "Entra SignInLogs and AuditLogs to Sentinel, 2 years."),
    "IDN-02": ("partial", "Cursor and Open WebUI pilot instance not on SSO."),
    "IDN-03": ("gap", "No inventory of AI service principals or keys."),
    "IDN-04": ("partial", "Key Vault for Azure keys; OpenAI and Anthropic keys in CI variables."),
    "IDN-05": ("met", "Admin consent workflow enforced."),
    # Central logging
    "LOG-01": ("partial", "M365, Entra, GitHub, AWS present; LiteLLM partial; Claude, ChatGPT, Open WebUI absent."),
    "LOG-02": ("met", "Sentinel interactive 90 days plus long-term retention to 2 years."),
    "LOG-03": ("gap", "No immutable tier."),
    "LOG-04": ("gap", "No hash manifests."),
    "LOG-05": ("met", "UTC normalised at ingest."),
    "LOG-06": ("met", "RBAC on workspaces; query auditing on."),
    "LOG-07": ("partial", "UPN mapped; request IDs not joined."),
    # Governance & IR
    "GOV-01": ("partial", "AI register covers 7 sanctioned systems; no discovered or local tools."),
    "GOV-02": ("gap", "No AI-specific playbooks."),
    "GOV-03": ("partial", "Roles exist for M365; none pre-approved for Claude, ChatGPT or AWS logs."),
    "GOV-04": ("gap", "No retrieval drill held."),
    "GOV-05": ("partial", "DPIA covers M365 Copilot only; employee notice silent on prompt logging."),
    "GOV-06": ("gap", "Legal-hold checklist has no AI sources."),
    "GOV-07": ("partial", "Hashing and chain of custody in SOP; no BSA s.63 certificate template."),
    "GOV-08": ("gap", "No AI vendor clauses on log access."),
    "GOV-09": ("met", "CERT-In 6-hour and DPDP intimation duties mapped with owners."),
}

RETENTION = {
    "m365-ual": (365, "2025-11-03"), "m365-mbx": (365, "2026-08-04"), "cps-transcripts": (30, "2026-10-04"),
    "cge-logs": (30, ""), "cle-sessions": (2190, "2026-08-18"), "cle-csv": (180, ""),
    "ghc-audit": (730, "2025-03-11"), "ccd-local": (30, ""), "aoa-diag": (90, "2026-08-05"),
    "aoa-apim": (90, "2026-08-05"), "bdr-ct": (2555, "2024-06-01"), "bdr-inv": (400, "2026-02-14"),
    "gw-requests": (60, "2026-09-04"), "inf-server": (3, ""), "ept-agents": (30, ""), "ept-process": (30, ""),
    "shd-proxy": (90, "2026-08-05"), "shd-dns": (0, ""), "idn-signin": (730, "2025-01-10"),
}

EVIDENCE = {
    "M365-01": "PS> Get-AdminAuditLogConfig | Format-List UnifiedAuditLogIngestionEnabled\nUnifiedAuditLogIngestionEnabled : True",
    "BDR-01": "== ap-south-1\n{\"loggingConfig\": {\"cloudWatchConfig\": {\"logGroupName\": \"/aifr/bedrock/invocations\", \"roleArn\": \"arn:aws:iam::111122223333:role/bedrock-logging\"}, \"textDataDeliveryEnabled\": true, \"imageDataDeliveryEnabled\": false, \"embeddingDataDeliveryEnabled\": false}}\n== eu-west-1\n{}",
    "GW-03": "41:general_settings:\n42:  master_key: os.environ/LITELLM_MASTER_KEY\n47:  store_prompts_in_spend_logs: false",
    "AOA-02": "Name                 DisableLocalAuth\n-------------------  ----------------\naoai-claims-prod     False\naoai-hr-prod         False\naoai-dev-01          None",
}


def sha(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def demo_bundles():
    """Generate the synthetic collector bundles and compact them the way the Workbench importer does."""
    import sys
    sys.path.insert(0, str(ROOT / "collectors"))
    from aifr_collect.demo import generate
    out = ROOT / "samples" / "bundles"
    for old in out.glob("aifr_*"):
        old.unlink()
    recs = []
    for path, digest in generate(out):
        doc = json.loads(path.read_text(encoding="utf-8"))
        obs = []
        for o in doc["observations"]:
            row = [o["control"], o["status"]]
            if o["status"] in ("gap", "partial", "error", "info") and o.get("detail"):
                row.append(o["detail"][:160])
            obs.append(row)
        rec = {
            "id": doc["bundle_id"], "file": path.name, "sha256": digest, "bytes": path.stat().st_size, "verified": True,
            "collector": doc["collector"]["name"], "version": doc["collector"]["version"], "impl": doc["collector"]["impl"],
            "targetType": doc["target"]["type"], "target": doc["target"]["id"], "os": doc["target"]["os"],
            "collectedAt": doc["run"]["finished"], "operator": doc["run"]["operator"], "importedAt": "2026-10-21T09:30:00Z", "obs": obs,
            "ret": [{"source": o["retention"]["source"], "days": o["retention"].get("days"), "oldest": o["retention"].get("oldest", "")} for o in doc["observations"] if o.get("retention")],
        }
        inv = doc.get("inventory") or {}
        if rec["targetType"] == "endpoint":
            rec["inv"] = {
                "tools": [{"id": t["id"], "name": t["name"], "users": len(t.get("users") or []), "transcripts": t.get("transcripts", 0), "bytes": t.get("bytes", 0),
                           "oldest": t.get("oldest", ""), "newest": t.get("newest", ""), "retentionDays": t.get("retention_days"), "managed": bool(t.get("managed")), "central": bool(t.get("central_capture"))} for t in inv.get("tools", [])],
                "mcp": [{"name": m["name"], "transport": m.get("transport", ""), "target": m.get("target", ""), "client": m.get("client", "")} for m in inv.get("mcp_servers", [])[:80]],
                "ext": [{"name": x["name"], "browser": x.get("browser", "")} for x in inv.get("extensions", [])[:60]],
                "listeners": [{"port": l["port"], "addr": l["address"], "proc": l.get("process", "")} for l in inv.get("listeners", [])[:20]],
                "agentic": inv.get("agentic_browsers", [])[:10], "telemetry": inv.get("telemetry"),
            }
        if inv.get("shadow"):
            rec["shadow"] = inv["shadow"]
        if inv.get("cloud"):
            rec["cloud"] = inv["cloud"]
        recs.append(rec)
    return recs


def main():
    ids = {c["id"]: p["id"] for p in KB["platforms"] for c in p["controls"]}
    unknown = [k for k in R if k not in ids]
    if unknown:
        raise SystemExit(f"Unknown control IDs: {unknown}")
    results = {}
    for cid, (status, note) in R.items():
        if ids[cid] not in SCOPE:
            raise SystemExit(f"{cid} belongs to an out-of-scope platform")
        entry = {"status": status, "note": note, "source": "manual", "by": "Field analyst", "at": "2026-10-28T10:00:00Z", "evidence": []}
        if cid in EVIDENCE:
            t = EVIDENCE[cid]
            entry["evidence"].append({"kind": "text", "label": "Command output", "sha256": sha(t), "bytes": len(t.encode()), "addedAt": "2026-10-21T09:30:00Z", "text": t})
        results[cid] = entry
    eng = {
        "schema": "aifr.engagement/1",
        "id": "eng-sample-2026-014",
        "sample": True,
        "createdAt": "2026-10-12T04:30:00Z",
        "updatedAt": "2026-11-03T08:00:00Z",
        "meta": {
            "client": "Asterion Financial Services Ltd",
            "ref": "AIFR-2026-014",
            "firm": "Digital Forensics Services",
            "lead": "Engagement lead",
            "team": "Two field analysts",
            "start": "2026-10-12", "end": "2026-11-06",
            "sector": "bfsi", "jurisdictions": ["IN", "EU"], "targetDays": 365,
            "classification": "Confidential. Prepared at the request of counsel.",
            "employees": 4200, "endpoints": 3800,
            "objective": "Establish whether Asterion can reconstruct an AI-related incident across its sanctioned and unsanctioned AI estate, and what it must change to meet a one-year evidence target.",
        },
        "scope": {"platforms": {pid: {"variant": v, "owner": OWNERS.get(pid, ""), "notes": ""} for pid, v in SCOPE.items()}},
        "results": results,
        "retention": {sid: {"days": d, "oldest": o} for sid, (d, o) in RETENTION.items()},
        "bundles": demo_bundles(),
        "log": [
            {"at": "2026-10-12T04:30:00Z", "by": "Engagement lead", "action": "Engagement created"},
            {"at": "2026-10-14T06:10:00Z", "by": "Field analyst", "action": "Microsoft 365 collector bundle imported"},
            {"at": "2026-10-21T09:30:00Z", "by": "Field analyst", "action": "Endpoint fleet bundles imported (412 hosts)"},
            {"at": "2026-10-28T10:00:00Z", "by": "Field analyst", "action": "Configuration checks completed"},
        ],
    }
    OUT.write_text(json.dumps(eng, indent=1, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {OUT} with {len(results)} results across {len(SCOPE)} platforms")


if __name__ == "__main__":
    main()
