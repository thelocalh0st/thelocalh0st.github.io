# AIFR: AI Forensic Readiness Workbench

A toolkit for the **AI Forensic Readiness Assessment** service line. It answers one question for a client:
*if one of our AI systems is misused tomorrow, can we prove what happened?*

The assessment goes beyond a checklist. Automated collectors gather hashed evidence from endpoints, cloud and SaaS control planes, and network logs. The Workbench scores the estate against a 12-item evidence model and tests eight incident scenarios. It then produces a client report, a field runbook and a remediation roadmap. Everything runs offline.

| Part | What it is |
|---|---|
| `AIFR-Workbench.html` | The assessor's console. One self-contained file: scope, tailored runbook, evidence intake, assessment, results, client report, research library. Open it in Edge or Chrome. No install, no network calls (enforced by Content-Security-Policy). |
| `collectors/windows/Invoke-AIFREndpointScan.ps1` | Windows endpoint collector (PowerShell 5.1, no dependencies). Deploy across the fleet with Intune, SCCM or a scheduled task. |
| `collectors/windows/Invoke-AIFRM365Collect.ps1` | Microsoft 365 / Purview collector for Copilot audit, retention, lookback, DLP and investigator roles. |
| `collectors/aifr_collect/` | Python 3.8+ collectors, standard library only: endpoint (Windows, macOS, Linux), AWS, Azure, Google Cloud, GitHub, Anthropic, OpenAI, self-hosted AI, shadow-AI log analysis, bundle verification. |
| `workbench-src/kb/` | The knowledge base: 34 platforms, 196 checks, 8 incident scenarios, 67 framework references, each platform with sources and a confidence label. |
| `samples/` | A complete fictional engagement (Asterion Financial Services) with 26 collector bundles, the generated field runbook and the client report as PDF and standalone HTML. |

## Quick start

1. Open `AIFR-Workbench.html` and choose **Open the sample engagement** to see a finished assessment. All names and figures in the sample are fictional.
2. For a real client, choose **Start a new engagement**, fill in Scope, and select the AI estate.
3. **Runbook** now lists exactly what to do for that estate: access requests, collector commands, per-platform checks with commands and expected results, the retrieval sampling plan and the tabletop scenarios. **Export runbook** produces a printable field document.
4. Run the collectors (below) and drop every `.json` bundle together with its `.sha256` sidecar onto **Evidence**. Each file is hashed on receipt and checked against its sidecar. Collector results fill the checks automatically. Your own verdicts always take precedence.
5. Work through **Assess**. Paste command output into a check to get a suggested verdict. Attach output or files, which are hashed into the evidence register. Keyboard: arrow keys move between checks; `M` `P` `G` `C` `N` `U` set the verdict.
6. **Results** shows readiness levels, the four questions, scenario answerability, evidence coverage, lookback against legal floors, target state and the roadmap. **Report** shows the client report as A4 pages sized to your screen (Auto picks two pages side by side on wide screens, otherwise fit width; Fit width, Two pages and 100% are one click away). **Full screen** hides the app chrome for reading or presenting; Esc returns. Print it to PDF or export it as standalone HTML.

The engagement lives in the browser while you work. **Save engagement file** writes the system of record (`*.aifr.json`) to keep in the case folder. Every assessor action is recorded in the engagement's activity log.

Deep links open a view directly, for training and demos: `AIFR-Workbench.html#sample-results`, `#sample-report`, `#library`.

## Collectors

All collectors are read-only. Each writes `aifr_<collector>_<target>_<time>.json` plus a `sha256sum`-compatible sidecar. Run them from `collectors/` (Python) or `collectors/windows/` (PowerShell).

| Command | What it establishes | Access needed |
|---|---|---|
| `Invoke-AIFREndpointScan.ps1 -AllUsers -OutputPath \\server\aifr$` | Claude Code, Codex, Gemini CLI, Antigravity, Copilot (VS Code and CLI), Cursor, Windsurf/Devin, Kiro, Amazon Q, Claude Desktop, ChatGPT desktop, Ollama, LM Studio, Jan: transcript counts and dates, retention, managed policy, hooks, telemetry, login method, MCP servers, AI browser extensions, agentic browsers, exposed model ports, process auditing, EDR, script block logging, time sync, Recall | Run as SYSTEM or administrator for all profiles |
| `python -m aifr_collect endpoint --all-users` | The same on macOS and Linux (and Windows where Python exists) | root / administrator |
| `Invoke-AIFRM365Collect.ps1` | Unified audit ingestion, CopilotInteraction sample, **lookback probe** (searches for Copilot records at 90, 180, 365 and 730 days), audit, retention and DLP policies, investigator role groups, third-party AI audit | Exchange Online + Security & Compliance PowerShell, read-only roles |
| `python -m aifr_collect aws --regions ap-south-1 eu-west-1` | Bedrock invocation logging per Region, S3 large-payload delivery, log retention, Object Lock, CloudTrail trails and Bedrock data events, guardrails | AWS CLI, SecurityAudit |
| `python -m aifr_collect azure --subscription <id>` | Azure OpenAI / AI Services diagnostics, key authentication, workspace retention, APIM LLM logging, Defender for AI, Entra ID log export | Azure CLI, Reader + Monitoring Reader |
| `python -m aifr_collect gcp --project <id>` | Vertex AI Data Access logs, log bucket retention and locks, sinks, Gemini Code Assist prompt logging | gcloud, Viewer + Private Logs Viewer |
| `python -m aifr_collect github --enterprise <slug>` | Audit log streaming, Copilot and agent events and their lookback, MCP registry events, Copilot usage-records API | `GITHUB_TOKEN` (classic PAT, read:audit_log, read:enterprise) |
| `python -m aifr_collect anthropic` | Compliance API Activity Feed, Claude Code / Cowork local-session capture | `ANTHROPIC_COMPLIANCE_KEY` (read scopes) |
| `python -m aifr_collect openai` | API organisation audit logging, project key ownership | `OPENAI_ADMIN_KEY` |
| `python -m aifr_collect selfhosted --config litellm.yaml .env --probe http://host:11434` | LiteLLM / Kong content logging and retention, Open WebUI authentication and audit level, unauthenticated model endpoints, container log drivers, host auditing | Read access on gateway and inference hosts |
| `python -m aifr_collect shadow --logs proxy.csv --sanctioned m365-copilot,github-copilot` | AI services reached from the network (about 100 domains and cloud endpoint patterns), account tier, users and devices counted, upload volume, and how far back the logs reach | A CSV/TSV export from the proxy, SWG, firewall or SIEM; Squid, BIND, Windows DNS debug and Zeek logs also work |
| `python -m aifr_collect verify <bundle.json>` | Recomputes the SHA-256 and compares it with the sidecar | none |
| `python -m aifr_collect demo --out ./training` | Synthetic bundles for training | none |

**Privacy by design.** Inventory mode never reads conversation content. MCP commands and URLs have tokens and keys redacted. The shadow analyser counts users and devices but never lists them. `--pseudonymise-top` lists the heaviest users as salted hashes, which the client can resolve through its own approved process.

**Incident triage.** `--preserve DIR` (Python) or `-Preserve DIR` (PowerShell) copies AI transcripts and databases, including Cursor's SQLite write-ahead log, into a folder with a SHA-256 manifest. Use it only under an authorised investigation.

## How scoring works

- **Evidence model.** Twelve items an investigator needs (E1 identity to E12 integrity). Each platform's knowledge-base entry states which items the vendor provides natively, which need configuration, which are partial and which are unavailable at any configuration.
- **Four questions** (K1 to K4): Is the content captured? How far back can you see? Who can delete it? Has a privacy setting voided it?
- **Readiness levels per platform**, scored by its weakest surface. 0 no record; 1 activity only; 2 content retrievable; 3 content preserved (retention at target, protected from deletion, retrieval proven); 4 reconstructable (adds context, authorisation, safeguard decisions and integrity proof). A failed retrieval test caps a platform at Level 1. The ladder also shows the level reachable by configuration alone.
- **Scenarios.** Eight incident scenarios, 42 investigator questions. A question is answerable only if every in-scope platform where the incident could happen can produce the evidence. Endpoint, identity and network sources count where they can stand in.
- **Severity** starts from each check's forensic weight. It rises for a failed key question and falls for partial or unevidenced results. Fixes are placed in 30, 90 and 90+ day windows by value and effort.
- **Legal floors** are set by jurisdiction and sector: CERT-In 180 days, DPDP Rules 2025 one year (from May 2027), EU AI Act six months for high-risk systems, PCI DSS twelve months.

## Maintaining the knowledge base

Vendor logging changes every few months. The knowledge base is plain JSON in `workbench-src/kb/`, one file per category. Each platform lists its sources, marked vendor or secondary, with an overall confidence label shown in the Library. To update:

```bash
cd workbench-src
python build.py --check      # validate IDs, references, regexes
python build.py              # rebuild AIFR-Workbench.html
```

Then refresh the sample and run the tests:

```bash
python samples/make_sample.py
node samples/export_samples.js
node tests/engine.test.js
cd collectors && python -m unittest discover -s tests -v
```

## Verification status

| Component | Tested |
|---|---|
| Workbench: every view, import of 26 bundles with sidecar verification and tamper detection, A4 report pagination (31 pages, one per sheet), runbook export | Yes, in Edge |
| Scoring engine | Node smoke test with invariants |
| Python collectors: endpoint (run on a real Windows workstation with ten AI tools), shadow (CSV, Squid, BIND), self-hosted config scan, bundle write and verify, demo | Yes, 9 unit tests |
| PowerShell endpoint collector | Yes, on Windows PowerShell 5.1; results match the Python collector |
| AWS, Azure, GCP, GitHub, Anthropic, OpenAI and M365 collectors | Written against vendor documentation, syntax-checked, fail safe without credentials. **Not yet run against a live tenant.** Run each once in a lab tenant before the first engagement. |

Some endpoint artefact locations come from practitioner documentation rather than vendor documentation: Antigravity, Copilot CLI session state, the Cursor and Gemini CLI enterprise configuration paths, and ChatGPT Atlas and Comet install paths. The collectors treat them as best effort. Confirm them on a reference machine when a tool updates.

Microsoft, GitHub, AWS, Google, OpenAI, Anthropic and other names are trademarks of their owners. They are used here only to describe the platforms that are assessed.
