"""Collector tests. Run from aifr/collectors:  python -m unittest discover -s tests -v"""
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from aifr_collect import ai_domains, shadow, selfhosted
from aifr_collect.bundle import Bundle
from aifr_collect.cli import main
from aifr_collect.endpoint import load_jsonc, mcp_servers, redact, toml_sections

FIX = Path(__file__).parent / "fixtures"


class Domains(unittest.TestCase):
    def test_suffix_and_patterns(self):
        self.assertEqual(ai_domains.match("chatgpt.com")[0], "ChatGPT")
        self.assertEqual(ai_domains.match("files.oaiusercontent.com:443")[0], "ChatGPT file uploads")
        self.assertEqual(ai_domains.match("bedrock-runtime.ap-south-1.amazonaws.com")[3], "aws-bedrock")
        self.assertEqual(ai_domains.match("aoai-claims.openai.azure.com")[3], "azure-openai")
        self.assertEqual(ai_domains.match("us-central1-aiplatform.googleapis.com")[3], "gcp-vertex")
        self.assertIsNone(ai_domains.match("www.bbc.co.uk"))
        self.assertIsNone(ai_domains.match("notchatgpt.com"))


class Shadow(unittest.TestCase):
    def test_formats(self):
        for name in ("proxy-sample.csv", "squid-access.log", "bind-query.log"):
            an = shadow.Analyzer(sanctioned=["m365-copilot", "github-copilot"])
            an.feed(FIX / name)
            res = an.result()
            self.assertGreater(res["rows"], 100, name)
            self.assertGreater(res["events"], 50, name)
            apps = {a["app"]: a for a in res["apps"]}
            self.assertIn("ChatGPT", apps, name)
            self.assertNotIn("www.bbc.co.uk", json.dumps(res), name)
            if "Microsoft 365 Copilot Chat" in apps:
                self.assertTrue(apps["Microsoft 365 Copilot Chat"]["sanctioned"])
            self.assertFalse(apps["ChatGPT"]["sanctioned"])

    def test_bundle_and_privacy(self):
        b = shadow.analyse([FIX / "proxy-sample.csv"], sanctioned=["m365-copilot"], target_days=365, top_users=True)
        doc = json.dumps(b.doc)
        self.assertNotIn("user1@corp.example", doc)
        obs = {o["control"]: o for o in b.doc["observations"]}
        self.assertEqual(obs["SHD-02"]["status"], "partial")
        self.assertGreaterEqual(obs["SHD-02"]["retention"]["days"], 90)
        self.assertEqual(obs["SHD-06"]["status"], "met")
        self.assertTrue(all(u["user"].startswith("u-") for u in b.inventory["shadow"]["top_users"]))


class SelfHosted(unittest.TestCase):
    def test_litellm_and_webui(self):
        b = selfhosted.collect(configs=[FIX / "litellm-config.yaml", FIX / "openwebui.env"], probes=[], docker=False)
        obs = {}
        for o in b.doc["observations"]:
            obs.setdefault(o["control"], o)
        self.assertEqual(obs["GW-03"]["status"], "gap")
        self.assertIn("turn_off_message_logging", obs["GW-03"]["detail"])
        self.assertEqual(obs["GW-04"]["retention"]["days"], 30)
        self.assertEqual(obs["CHT-01"]["status"], "partial")
        self.assertEqual(obs["CHT-03"]["status"], "gap")


class Parsers(unittest.TestCase):
    def test_jsonc_and_mcp(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "mcp.json"
            p.write_text('{\n // comment\n "servers": {"gh": {"command": "npx", "args": ["-y", "server", "--token", "ghp_abcdef123456"],},\n "remote": {"url": "https://x.example/mcp?api_key=SECRET123"}},\n}', encoding="utf-8")
            data = load_jsonc(p)
            servers = mcp_servers(data, "VS Code", p)
            self.assertEqual({s["name"] for s in servers}, {"gh", "remote"})
            joined = json.dumps(servers)
            self.assertNotIn("abcdef123456", joined)
            self.assertNotIn("SECRET123", joined)

    def test_toml(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "config.toml"
            p.write_text('model = "gpt-5"\n[otel]\nexporter = "otlp-http"\n[mcp_servers.docs]\ncommand = "npx"\n[mcp_servers.docs.env]\nKEY = "x"\n', encoding="utf-8")
            s = toml_sections(p)
            self.assertIn("otel", s)
            self.assertEqual(s["mcp_servers.docs"]["command"], "npx")

    def test_redact(self):
        self.assertNotIn("sk-live-123456789", redact("--api-key sk-live-123456789"))
        self.assertIn("***", redact("Authorization: Bearer abc.def"))


class BundleIO(unittest.TestCase):
    def test_write_and_verify(self):
        with tempfile.TemporaryDirectory() as d:
            b = Bundle("aifr-test", "endpoint", "host-1")
            b.observe("EPT-01", "met", "ok", "endpoint-ai")
            path, digest = b.write(d)
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), digest)
            side = Path(str(path) + ".sha256").read_text().split()
            self.assertEqual(side, [digest, path.name])
            self.assertEqual(main(["verify", str(path)]), 0)
            path.write_bytes(path.read_bytes().replace(b'"met"', b'"gap"'))
            self.assertEqual(main(["verify", str(path)]), 1)

    def test_demo(self):
        with tempfile.TemporaryDirectory() as d:
            main(["demo", "--out", d, "--hosts", "6"])
            files = list(Path(d).glob("*.json"))
            self.assertEqual(len(files), 8)
            for f in files:
                doc = json.loads(f.read_text(encoding="utf-8"))
                self.assertTrue(doc["schema"].startswith("aifr.bundle/"))


if __name__ == "__main__":
    unittest.main()
