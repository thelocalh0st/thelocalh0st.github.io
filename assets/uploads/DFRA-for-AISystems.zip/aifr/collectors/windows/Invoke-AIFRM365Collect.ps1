<#
.SYNOPSIS
    AIFR Microsoft 365 collector: Copilot and AI audit posture from Exchange Online and
    Security & Compliance PowerShell. Read-only.

.DESCRIPTION
    Checks unified audit ingestion, samples CopilotInteraction records, probes how far back
    Copilot audit records can actually be retrieved (lookback at 90, 180, 365 and 730 days),
    lists audit retention policies, retention and DLP policies that reference Copilot, the
    investigator role groups, and whether third-party AI interactions are audited.
    Writes an AIFR evidence bundle and a SHA-256 sidecar for the AIFR Workbench.

    Record content is never written to the bundle: only counts, dates, host applications
    and policy names. User identities are counted, not listed.

    Before running, connect with a read-only account (Audit Reader / View-Only Audit Logs,
    plus Compliance Administrator read or Global Reader for policies):
        Connect-ExchangeOnline -UserPrincipalName reader@tenant.example
        Connect-IPPSSession -UserPrincipalName reader@tenant.example

.PARAMETER OutputPath
    Folder for the bundle. Defaults to .\evidence.
.PARAMETER SampleDays
    Days of recent CopilotInteraction records to sample. Default 30.
.PARAMETER SkipLookback
    Skip the historical lookback probe (it runs up to four extra audit searches).
#>
[CmdletBinding()]
param(
    [string]$OutputPath = ".\evidence",
    [int]$SampleDays = 30,
    [switch]$SkipLookback
)

Set-StrictMode -Version 2
$ErrorActionPreference = 'Stop'
$CollectorVersion = '1.0.0'
$Started = (Get-Date).ToUniversalTime()
$Observations = New-Object System.Collections.Generic.List[object]
$Notes = New-Object System.Collections.Generic.List[string]
$Inventory = [ordered]@{}

function ConvertTo-IsoUtc([datetime]$d) { return $d.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ') }
function Add-Observation([string]$Control, [string]$Status, [string]$Detail, [string]$Platform = 'm365-copilot', $Retention = $null, $Data = $null) {
    $o = [ordered]@{ control = $Control; platform = $Platform; status = $Status; detail = $Detail }
    if ($Data) { $o.data = $Data }
    if ($Retention) { $o.retention = $Retention }
    $Observations.Add($o)
}
function Test-Cmdlet([string]$Name) { return [bool](Get-Command -Name $Name -ErrorAction SilentlyContinue) }
function Invoke-Safe([scriptblock]$Block, [string]$What) {
    try { return & $Block } catch { $Notes.Add("$What failed: $($_.Exception.Message)"); return $null }
}

if (-not (Test-Cmdlet 'Get-AdminAuditLogConfig')) {
    throw 'Exchange Online cmdlets not loaded. Run Connect-ExchangeOnline (and Connect-IPPSSession) with a read-only role first.'
}
$tenant = Invoke-Safe { (Get-OrganizationConfig).Name } 'Get-OrganizationConfig'
if (-not $tenant) { $tenant = 'm365-tenant' }

# ---- M365-01 unified audit ingestion (and organisation-level mailbox audit switch)
$cfg = Invoke-Safe { Get-AdminAuditLogConfig } 'Get-AdminAuditLogConfig'
$orgAuditDisabled = Invoke-Safe { (Get-OrganizationConfig).AuditDisabled } 'Get-OrganizationConfig.AuditDisabled'
if ($cfg) {
    $on = [bool]$cfg.UnifiedAuditLogIngestionEnabled
    $detail = "UnifiedAuditLogIngestionEnabled : $on"
    if ($orgAuditDisabled) { $detail += "; organisation AuditDisabled : True (mailbox auditing off)" }
    $st = 'gap'; if ($on -and -not $orgAuditDisabled) { $st = 'met' } elseif ($on) { $st = 'partial' }
    Add-Observation 'M365-01' $st $detail
}

# ---- M365-02 sample recent CopilotInteraction records; CPS-04 Copilot Studio presence
$now = Get-Date
$sample = Invoke-Safe { @(Search-UnifiedAuditLog -StartDate $now.AddDays(-$SampleDays) -EndDate $now -RecordType CopilotInteraction -ResultSize 1000) } 'Search-UnifiedAuditLog (sample)'
if ($null -ne $sample) {
    $hosts = @{}; $withRes = 0; $studio = 0; $users = @{}; $jail = 0; $xpia = 0
    foreach ($r in $sample) {
        $users[[string]$r.UserIds] = 1
        try { $a = $r.AuditData | ConvertFrom-Json } catch { continue }
        $ced = $a.PSObject.Properties['CopilotEventData']; if ($ced) { $d = $ced.Value } else { $d = $a }
        $h = [string]$d.AppHost; if (-not $h) { $h = 'unknown' }; $hosts[$h] = 1 + [int]$hosts[$h]
        if ($d.PSObject.Properties['AccessedResources'] -and @($d.AccessedResources).Count -gt 0) { $withRes++ }
        if ([string]$d.AppIdentity -like 'Copilot.Studio.*') { $studio++ }
        foreach ($m in @($d.Messages)) { if ($m -and $m.PSObject.Properties['JailbreakDetected'] -and $m.JailbreakDetected) { $jail++ } }
        foreach ($res in @($d.AccessedResources)) { if ($res -and $res.PSObject.Properties['XPIADetected'] -and $res.XPIADetected) { $xpia++ } }
    }
    $n = $sample.Count
    $hostText = ($hosts.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 6 | ForEach-Object { "$($_.Key) $($_.Value)" }) -join ', '
    if ($n -gt 0) {
        Add-Observation 'M365-02' 'met' "$n CopilotInteraction records in the last $SampleDays days from $($users.Count) users; $withRes reference accessed resources. Host apps: $hostText." 'm365-copilot' $null ([ordered]@{ records = $n; users = $users.Count; hosts = $hosts; jailbreak_flags = $jail; xpia_flags = $xpia })
        if ($studio -gt 0) { Add-Observation 'CPS-04' 'met' "$studio Copilot Studio agent interactions in the sample." 'copilot-studio' }
    } else {
        Add-Observation 'M365-02' 'gap' "No CopilotInteraction records in the last $SampleDays days. Check licences, ingestion and the account's audit role."
    }
    $Inventory.copilot_sample = [ordered]@{ days = $SampleDays; records = $n; users = $users.Count; host_apps = $hosts; jailbreak_flags = $jail; xpia_flags = $xpia }
}

# ---- M365-03 lookback probe and audit retention policies
$policies = Invoke-Safe { @(Get-UnifiedAuditLogRetentionPolicy) } 'Get-UnifiedAuditLogRetentionPolicy'
$copilotPolicies = @($policies | Where-Object { $_ -and (@($_.RecordTypes) -contains 'CopilotInteraction') })
$polText = ($copilotPolicies | ForEach-Object { "$($_.Name) ($($_.RetentionDuration))" }) -join '; '
$reach = 0
if (-not $SkipLookback) {
    foreach ($days in @(90, 180, 365, 730)) {
        $hit = Invoke-Safe { @(Search-UnifiedAuditLog -StartDate $now.AddDays(-$days) -EndDate $now.AddDays(-$days + 7) -RecordType CopilotInteraction -ResultSize 1) } "Lookback probe at $days days"
        if ($hit -and $hit.Count -gt 0) { $reach = $days } else { break }
    }
}
$longPolicy = @($copilotPolicies | Where-Object { [string]$_.RetentionDuration -match 'OneYear|ThreeYears|FiveYears|SevenYears|TenYears' }).Count -gt 0
$st = 'gap'; if ($reach -ge 365 -or $longPolicy) { $st = 'met' } elseif ($reach -ge 180) { $st = 'partial' }
$detail = "Copilot records retrievable at least $reach days back"
if ($SkipLookback) { $detail = 'Lookback probe skipped' }
if ($polText) { $detail += "; audit retention policies: $polText" } else { $detail += '; no audit retention policy names CopilotInteraction (Standard keeps 180 days, Premium one year)' }
$ret = $null; if ($reach -gt 0) { $ret = [ordered]@{ source = 'm365-ual'; days = $reach } }
Add-Observation 'M365-03' $st ($detail + '.') 'm365-copilot' $ret

# ---- M365-04 retention policies that hold Copilot content
if (Test-Cmdlet 'Get-RetentionCompliancePolicy') {
    $rp = Invoke-Safe { @(Get-RetentionCompliancePolicy -DistributionDetail) } 'Get-RetentionCompliancePolicy'
    if ($null -ne $rp) {
        $hits = @()
        foreach ($p in $rp) {
            $text = ($p.PSObject.Properties | Where-Object { $_.Name -match 'Location|Workload|Applications' } | ForEach-Object { "$($_.Name)=$($_.Value)" }) -join ' '
            if ($text -match 'Copilot' -or $p.Name -match 'Copilot') { $hits += "$($p.Name) (enabled: $($p.Enabled), mode: $($p.Mode))" }
        }
        if ($hits.Count) { Add-Observation 'M365-04' 'partial' ("Retention policies referencing Copilot: " + ($hits -join '; ') + '. Confirm the location, scope and duration in the Purview portal.') }
        elseif ($rp.Count) { Add-Observation 'M365-04' 'info' "$($rp.Count) retention policies found; none references Copilot by name or location. Check the 'Microsoft Copilot experiences' location in the portal." }
        else { Add-Observation 'M365-04' 'gap' 'No retention policies exist: Copilot prompts and responses are not held.' }
    }
} else { $Notes.Add('Security & Compliance cmdlets not loaded (Connect-IPPSSession): retention, DLP and role checks skipped.') }

# ---- M365-08 investigator role groups (counts only)
if (Test-Cmdlet 'Get-RoleGroup') {
    $groups = Invoke-Safe { @(Get-RoleGroup | Where-Object { $_.Name -match 'eDiscovery|Audit' -or $_.DisplayName -match 'eDiscovery|Audit' }) } 'Get-RoleGroup'
    if ($null -ne $groups) {
        $summary = @()
        $ediscovery = 0; $audit = 0
        foreach ($g in $groups) {
            $count = @(Invoke-Safe { Get-RoleGroupMember -Identity $g.Identity -ResultSize Unlimited } "Get-RoleGroupMember $($g.Name)").Count
            $summary += "$($g.Name): $count"
            if ($g.Name -match 'eDiscovery') { $ediscovery += $count } else { $audit += $count }
        }
        $st = 'gap'; if ($ediscovery -gt 0 -and $audit -gt 0) { $st = 'partial' }
        Add-Observation 'M365-08' $st ("Role group membership counts: " + ($summary -join '; ') + '. Confirm IR team access is pre-approved (PIM) and audited.')
    }
}

# ---- M365-09 DLP for the Copilot location
if (Test-Cmdlet 'Get-DlpCompliancePolicy') {
    $dlp = Invoke-Safe { @(Get-DlpCompliancePolicy) } 'Get-DlpCompliancePolicy'
    if ($null -ne $dlp) {
        $cop = @($dlp | Where-Object { (($_.PSObject.Properties | Where-Object { $_.Name -match 'Location|Workload' } | ForEach-Object { [string]$_.Value }) -join ' ') -match 'Copilot' -or $_.Name -match 'Copilot' })
        if ($cop.Count) { Add-Observation 'M365-09' 'met' ("DLP policies covering Copilot: " + (($cop | ForEach-Object { "$($_.Name) ($($_.Mode))" }) -join '; ')) }
        else { Add-Observation 'M365-09' 'gap' "$($dlp.Count) DLP policies; none covers the Microsoft 365 Copilot location." }
    }
}

# ---- SHD-03 third-party AI interactions audited (DSPM for AI, pay-as-you-go)
$ai = Invoke-Safe { @(Search-UnifiedAuditLog -StartDate $now.AddDays(-30) -EndDate $now -RecordType AIAppInteraction -ResultSize 50) } 'Search-UnifiedAuditLog (AIAppInteraction)'
if ($null -ne $ai) {
    if ($ai.Count -gt 0) { Add-Observation 'SHD-03' 'partial' "$($ai.Count)+ third-party AI interaction records in the last 30 days (DSPM for AI collection active)." 'shadow-ai' }
    else { Add-Observation 'SHD-03' 'info' 'No AIAppInteraction records in the last 30 days: third-party AI collection may not be configured.' 'shadow-ai' }
}

# ---- bundle
$finished = (Get-Date).ToUniversalTime()
$bundle = [ordered]@{
    schema       = 'aifr.bundle/1'
    bundle_id    = [guid]::NewGuid().ToString()
    collector    = [ordered]@{ name = 'aifr-m365'; version = $CollectorVersion; impl = "powershell $($PSVersionTable.PSVersion)" }
    run          = [ordered]@{ started = (ConvertTo-IsoUtc $Started); finished = (ConvertTo-IsoUtc $finished); operator = "$env:USERDOMAIN\$env:USERNAME"; mode = 'inventory'; argv = ($PSBoundParameters.Keys -join ' ') }
    target       = [ordered]@{ type = 'saas'; id = [string]$tenant; os = 'Microsoft 365'; details = [ordered]@{ sample_days = $SampleDays } }
    observations = $Observations.ToArray()
    inventory    = $Inventory
    files        = @()
    notes        = $Notes.ToArray()
}
New-Item -ItemType Directory -Force -Path $OutputPath | Out-Null
$name = "aifr_m365_{0}_{1}.json" -f ([string]$tenant -replace '[^A-Za-z0-9\-.]', '-'), $finished.ToString('yyyyMMddTHHmmssZ')
$path = Join-Path (Resolve-Path $OutputPath) $name
$json = $bundle | ConvertTo-Json -Depth 10
if (-not $json) { throw 'Bundle serialisation produced no output.' }
[IO.File]::WriteAllText($path, $json, (New-Object System.Text.UTF8Encoding $false))
$hash = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower()
[IO.File]::WriteAllText("$path.sha256", "$hash  $name`n", (New-Object System.Text.UTF8Encoding $false))
Write-Output "Wrote $path"
Write-Output "SHA-256 $hash"
$Observations | ForEach-Object { Write-Output ("  {0,-8} {1,-8} {2}" -f $_.control, $_.status, $_.detail) }
if ($Notes.Count) { Write-Output 'Notes:'; $Notes | ForEach-Object { Write-Output "  $_" } }
