<#
.SYNOPSIS
    AIFR endpoint collector for Windows. Read-only inventory of AI tools, their forensic
    artefacts, and the host telemetry that corroborates them.

.DESCRIPTION
    Writes an AIFR evidence bundle (aifr.bundle/1) and a SHA-256 sidecar that the AIFR
    Workbench imports. Inventory mode records metadata only (tool presence, transcript
    counts and dates, retention and capture settings, MCP servers, local model runtimes,
    AI browser extensions, process auditing, EDR and time sync). It never reads
    conversation content.

    -Preserve copies the artefacts into a folder with a SHA-256 manifest for incident
    triage. Use it only under an authorised investigation: the copies contain prompts,
    responses and anything the AI tools read.

    Designed for fleet deployment: run as SYSTEM with -AllUsers from Intune (platform
    script or remediation), SCCM or a scheduled task, writing to a collection share.

.PARAMETER OutputPath
    Folder or UNC share for the bundle. Defaults to .\evidence.
.PARAMETER AllUsers
    Scan every profile under C:\Users. Needs administrator or SYSTEM.
.PARAMETER Preserve
    Folder to copy artefacts into, with manifest.csv. Incident triage only.
.PARAMETER ExpectClaudeOrg
    Claude Enterprise organisation UUID that Claude Code users should be signed in to.
.PARAMETER MaxPreserveMB
    Upper limit for preserved bytes. Default 2048.

.EXAMPLE
    powershell.exe -ExecutionPolicy Bypass -File .\Invoke-AIFREndpointScan.ps1 -AllUsers -OutputPath \\fileserver\aifr$\AIFR-2026-014
#>
[CmdletBinding()]
param(
    [string]$OutputPath = ".\evidence",
    [switch]$AllUsers,
    [string]$Preserve,
    [string]$ExpectClaudeOrg,
    [int]$MaxPreserveMB = 2048
)

Set-StrictMode -Version 2
$ErrorActionPreference = 'SilentlyContinue'
$CollectorVersion = '1.0.0'
$Started = (Get-Date).ToUniversalTime()
$AiPorts = @{ 11434 = 'Ollama'; 1234 = 'LM Studio'; 1337 = 'Jan'; 4891 = 'GPT4All' }
$ExtPattern = '\b(chat ?gpt|gpt|openai|claude|anthropic|gemini|copilot|perplexity|deepseek|grok|monica|merlin|sider|harpa|maxai|grammarly|jasper|writesonic|llm|ai (assistant|chat|agent|writer|sidebar|summar\w*))\b'
$ExportHint = '(curl|wget|Invoke-WebRequest|Invoke-RestMethod|aws s3|azcopy|gsutil|rsync|robocopy|scp |Copy-Item|https?://)'
$EdrServices = [ordered]@{ 'Sense' = 'Microsoft Defender for Endpoint'; 'CSFalconService' = 'CrowdStrike Falcon'; 'SentinelAgent' = 'SentinelOne'; 'CbDefense' = 'Carbon Black';
    'cyserver' = 'Cortex XDR'; 'ElasticEndpoint' = 'Elastic Defend'; 'xagt' = 'Trellix HX'; 'Sophos Endpoint Defense Service' = 'Sophos'; 'ekrn' = 'ESET'; 'CylanceSvc' = 'Cylance' }

$Observations = New-Object System.Collections.Generic.List[object]
$Files = New-Object System.Collections.Generic.List[object]
$Notes = New-Object System.Collections.Generic.List[string]
$Tools = [ordered]@{}
$Mcp = New-Object System.Collections.Generic.List[object]
$Extensions = New-Object System.Collections.Generic.List[object]
$Agentic = New-Object System.Collections.Generic.List[string]
$Listeners = New-Object System.Collections.Generic.List[object]
$Flags = @{ claude = @(); codex = @(); gemini = @(); cursorUserHooks = $false; recallUsers = @() }
$script:PreservedBytes = 0

function ConvertTo-IsoUtc([datetime]$d) { if ($null -eq $d) { return '' } return $d.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ') }

function Add-Observation([string]$Control, [string]$Status, [string]$Detail, [string]$Platform, $Retention = $null, $Data = $null) {
    $o = [ordered]@{ control = $Control; platform = $Platform; status = $Status; detail = $Detail }
    if ($Data) { $o.data = $Data }
    if ($Retention) { $o.retention = $Retention }
    $Observations.Add($o)
}

function Protect-Secret([string]$s) {
    $s = [regex]::Replace($s, '(?i)((?:api[_-]?key|token|secret|password|bearer|authorization)["'']?\s*[:=]\s*["'']?)[^\s"'',}]+', '$1***')
    return [regex]::Replace($s, '\b(sk-[A-Za-z0-9_\-]{6}|ghp_|gho_|github_pat_|xox[abpr]-|AKIA)[A-Za-z0-9_\-]*', '$1***')
}

function Read-JsonLoose([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
    try {
        $t = [IO.File]::ReadAllText($Path)
        $t = [regex]::Replace($t, '(?m)^\s*//.*$', '')
        $t = [regex]::Replace($t, '(?s)/\*.*?\*/', '')
        $t = [regex]::Replace($t, ',(\s*[}\]])', '$1')
        return ($t | ConvertFrom-Json)
    } catch { return $null }
}

function Get-Prop($obj, [string]$name) {
    if ($null -eq $obj) { return $null }
    $p = $obj.PSObject.Properties[$name]
    if ($p) { return $p.Value } else { return $null }
}

function Get-Stats([string]$Root, [string[]]$Filters, [switch]$Recurse) {
    $r = @{ count = 0; bytes = [int64]0; oldest = $null; newest = $null; files = @() }
    if (-not (Test-Path -LiteralPath $Root)) { return $r }
    $items = @()
    foreach ($f in $Filters) {
        if ($Recurse) { $items += @(Get-ChildItem -LiteralPath $Root -Recurse -File -Filter $f -Force -ErrorAction SilentlyContinue) }
        else { $items += @(Get-ChildItem -Path (Join-Path $Root $f) -File -Force -ErrorAction SilentlyContinue) }
    }
    foreach ($i in $items) {
        $r.count++; $r.bytes += $i.Length
        if ($null -eq $r.oldest -or $i.LastWriteTimeUtc -lt $r.oldest) { $r.oldest = $i.LastWriteTimeUtc }
        if ($null -eq $r.newest -or $i.LastWriteTimeUtc -gt $r.newest) { $r.newest = $i.LastWriteTimeUtc }
    }
    $r.files = $items
    return $r
}

function Get-Tool([string]$Id, [string]$Name, [string]$Platform) {
    if (-not $Tools.Contains($Id)) {
        $Tools[$Id] = [ordered]@{ id = $Id; name = $Name; platform = $Platform; users = New-Object System.Collections.Generic.List[string]; transcripts = 0; bytes = [int64]0;
            oldest = ''; newest = ''; retention_days = $null; managed = $false; central_capture = $false; paths = New-Object System.Collections.Generic.List[string] }
    }
    return $Tools[$Id]
}

function Add-ToolStats($Tool, [string]$User, $Stats, [string]$Path) {
    if (-not $Tool.users.Contains($User)) { $Tool.users.Add($User) }
    $Tool.transcripts += $Stats.count
    $Tool.bytes += $Stats.bytes
    $o = ConvertTo-IsoUtc $Stats.oldest; $n = ConvertTo-IsoUtc $Stats.newest
    if ($o -and (-not $Tool.oldest -or $o -lt $Tool.oldest)) { $Tool.oldest = $o }
    if ($n -and $n -gt $Tool.newest) { $Tool.newest = $n }
    if ($Tool.paths.Count -lt 6) { $Tool.paths.Add($Path) }
    if ($Preserve) { Save-Artefacts $Stats.files $Tool.id $User }
}

function Save-Artefacts($Items, [string]$ToolId, [string]$User) {
    foreach ($i in $Items) {
        $set = @($i.FullName)
        if ($i.Name -like '*.vscdb') { $set += @("$($i.FullName)-wal", "$($i.FullName)-shm") }
        foreach ($p in $set) {
            if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { continue }
            $f = Get-Item -LiteralPath $p -Force
            if ($script:PreservedBytes + $f.Length -gt ($MaxPreserveMB * 1MB)) { $Notes.Add("Preserve limit reached; skipped $p"); return }
            $dest = Join-Path (Join-Path (Join-Path $Preserve $ToolId) $User) (Join-Path $f.Directory.Name $f.Name)
            New-Item -ItemType Directory -Force -Path (Split-Path $dest) | Out-Null
            Copy-Item -LiteralPath $p -Destination $dest -Force
            $script:PreservedBytes += $f.Length
            $h = (Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash.ToLower()
            $Files.Add([ordered]@{ path = $p; role = "preserved:$ToolId"; sha256 = $h; bytes = $f.Length; mtime = (ConvertTo-IsoUtc $f.LastWriteTimeUtc) })
        }
    }
}

function Add-ConfigFile([string]$Path, [string]$Role) {
    if (Test-Path -LiteralPath $Path -PathType Leaf) {
        $f = Get-Item -LiteralPath $Path -Force
        $Files.Add([ordered]@{ path = $Path; role = $Role; sha256 = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLower(); bytes = $f.Length; mtime = (ConvertTo-IsoUtc $f.LastWriteTimeUtc) })
    }
}

function Add-McpServers($Obj, [string]$Client, [string]$Source) {
    if ($null -eq $Obj) { return }
    foreach ($key in @('mcpServers', 'servers', 'mcp_servers', 'context_servers')) {
        $d = Get-Prop $Obj $key
        if ($null -eq $d) { continue }
        foreach ($p in $d.PSObject.Properties) {
            $cfg = $p.Value
            if ($null -eq $cfg -or $cfg -is [string]) { continue }
            $url = Get-Prop $cfg 'url'; if (-not $url) { $url = Get-Prop $cfg 'serverUrl' }; if (-not $url) { $url = Get-Prop $cfg 'httpUrl' }
            $cmd = Get-Prop $cfg 'command'; $args2 = @(Get-Prop $cfg 'args') | Select-Object -First 8
            $transport = Get-Prop $cfg 'type'; if (-not $transport) { if ($url) { $transport = 'http' } else { $transport = 'stdio' } }
            if ($url) { $target = [string]$url } else { $target = (@([string]$cmd) + @($args2 | ForEach-Object { [string]$_ })) -join ' ' }
            $t = Protect-Secret $target; if ($t.Length -gt 220) { $t = $t.Substring(0, 220) }
            $Mcp.Add([ordered]@{ name = [string]$p.Name; transport = [string]$transport; target = $t; client = $Client; source = $Source })
        }
    }
    $nested = Get-Prop $Obj 'mcp'
    if ($nested) { Add-McpServers $nested $Client $Source }
}

function Get-HookCommands($Settings) {
    $out = @()
    $hooks = Get-Prop $Settings 'hooks'
    if ($null -eq $hooks) { return $out }
    foreach ($ev in @('SessionEnd', 'Stop', 'PostToolUse', 'UserPromptSubmit')) {
        foreach ($m in @(Get-Prop $hooks $ev)) {
            foreach ($h in @(Get-Prop $m 'hooks')) {
                $c = Get-Prop $h 'command'
                if ($c) { $out += , @($ev, [string]$c) }
            }
        }
    }
    return $out
}

function Get-RegValue([string]$Path, [string]$Name) {
    $v = Get-ItemProperty -LiteralPath $Path -Name $Name -ErrorAction SilentlyContinue
    if ($v) { return $v.$Name } else { return $null }
}

# ---------------------------------------------------------------- profiles
$Homes = @()
if ($AllUsers) {
    $skip = @('public', 'default', 'default user', 'all users', 'defaultapppool', 'wdagutilityaccount')
    $Homes = @(Get-ChildItem -LiteralPath (Join-Path $env:SystemDrive 'Users') -Directory -Force | Where-Object { $skip -notcontains $_.Name.ToLower() } | ForEach-Object { $_.FullName })
} else { $Homes = @($env:USERPROFILE) }

foreach ($homeDir in $Homes) {
    $user = Split-Path $homeDir -Leaf
    $roam = Join-Path $homeDir 'AppData\Roaming'
    $loc = Join-Path $homeDir 'AppData\Local'

    # Claude Code
    $cdir = Join-Path $homeDir '.claude'
    $cjson = Read-JsonLoose (Join-Path $homeDir '.claude.json')
    if ((Test-Path -LiteralPath $cdir) -or $cjson) {
        $t = Get-Tool 'claude-code' 'Claude Code' 'claude-code'
        $st = Get-Stats (Join-Path $cdir 'projects') @('*.jsonl') -Recurse
        Add-ToolStats $t $user $st (Join-Path $cdir 'projects')
        $settings = Read-JsonLoose (Join-Path $cdir 'settings.json')
        Add-ConfigFile (Join-Path $cdir 'settings.json') 'config:claude-code'
        $info = @{ user = $user; cleanup = (Get-Prop $settings 'cleanupPeriodDays'); env = (Get-Prop $settings 'env'); hooks = (Get-HookCommands $settings); defaultMode = (Get-Prop (Get-Prop $settings 'permissions') 'defaultMode'); login = 'none'; org = '' }
        if ($cjson) {
            $oa = Get-Prop $cjson 'oauthAccount'
            if ($oa) { $info.login = 'claude.ai'; $info.org = [string](Get-Prop $oa 'organizationUuid') }
            elseif ((Get-Prop $cjson 'primaryApiKey') -or (Get-Prop $cjson 'customApiKeyResponses')) { $info.login = 'api-key' }
            Add-McpServers $cjson 'Claude Code' (Join-Path $homeDir '.claude.json')
            $projects = Get-Prop $cjson 'projects'
            if ($projects) { foreach ($pp in $projects.PSObject.Properties) { Add-McpServers $pp.Value 'Claude Code (project)' $pp.Name } }
        }
        $Flags.claude += , $info
    }

    # Codex
    $xdir = Join-Path $homeDir '.codex'
    if (Test-Path -LiteralPath $xdir) {
        $t = Get-Tool 'codex' 'OpenAI Codex CLI' 'openai-codex'
        Add-ToolStats $t $user (Get-Stats (Join-Path $xdir 'sessions') @('rollout-*') -Recurse) (Join-Path $xdir 'sessions')
        $cfgPath = Join-Path $xdir 'config.toml'
        Add-ConfigFile $cfgPath 'config:codex'
        $toml = ''; if (Test-Path -LiteralPath $cfgPath) { $toml = [IO.File]::ReadAllText($cfgPath) }
        $otel = $toml -match '(?m)^\s*\[otel[\].]' -and $toml -match '(?m)exporter'
        $histNone = $toml -match '(?ms)^\s*\[history\][^\[]*persistence\s*=\s*"none"'
        $auth = Read-JsonLoose (Join-Path $xdir 'auth.json')
        $apiKey = [bool](Get-Prop $auth 'OPENAI_API_KEY')
        $Flags.codex += , @{ user = $user; otel = $otel; histNone = $histNone; apiKey = $apiKey }
        if ($otel) { $t.central_capture = $true }
        foreach ($m in [regex]::Matches($toml, '(?ms)^\s*\[mcp_servers\.([A-Za-z0-9_\-]+)\]\s*(.*?)(?=^\s*\[|\z)')) {
            $body = $m.Groups[2].Value
            $u = [regex]::Match($body, '(?m)^\s*url\s*=\s*"([^"]+)"').Groups[1].Value
            $c = [regex]::Match($body, '(?m)^\s*command\s*=\s*"([^"]+)"').Groups[1].Value
            $tr = 'stdio'; $tg = $c; if ($u) { $tr = 'http'; $tg = $u }
            $Mcp.Add([ordered]@{ name = $m.Groups[1].Value; transport = $tr; target = (Protect-Secret $tg); client = 'Codex'; source = $cfgPath })
        }
    }

    # Gemini CLI and Antigravity
    $gdir = Join-Path $homeDir '.gemini'
    if (Test-Path -LiteralPath $gdir) {
        $gs = Read-JsonLoose (Join-Path $gdir 'settings.json')
        Add-ConfigFile (Join-Path $gdir 'settings.json') 'config:gemini-cli'
        $t = Get-Tool 'gemini-cli' 'Gemini CLI' 'google-code'
        Add-ToolStats $t $user (Get-Stats (Join-Path $gdir 'tmp') @('*.json', 'checkpoint*') -Recurse) (Join-Path $gdir 'tmp')
        $tel = Get-Prop $gs 'telemetry'
        $Flags.gemini += , @{ user = $user; telemetry = [bool](Get-Prop $tel 'enabled') }
        Add-McpServers $gs 'Gemini CLI' (Join-Path $gdir 'settings.json')
        $ag = Join-Path $gdir 'antigravity'
        if (Test-Path -LiteralPath $ag) {
            $ta = Get-Tool 'antigravity' 'Google Antigravity' 'google-code'
            $agc = @(Get-ChildItem -Path (Join-Path $ag 'conversations') -File -ErrorAction SilentlyContinue) + @(Get-ChildItem -Path (Join-Path $ag 'brain') -Directory -ErrorAction SilentlyContinue | ForEach-Object { Get-ChildItem -LiteralPath $_.FullName -File -ErrorAction SilentlyContinue })
            $ags = @{ count = $agc.Count; bytes = [int64](($agc | Measure-Object -Property Length -Sum).Sum); oldest = ($agc | Sort-Object LastWriteTimeUtc | Select-Object -First 1).LastWriteTimeUtc; newest = ($agc | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1).LastWriteTimeUtc; files = $agc }
            Add-ToolStats $ta $user $ags $ag
            Add-McpServers (Read-JsonLoose (Join-Path $ag 'mcp_config.json')) 'Antigravity' (Join-Path $ag 'mcp_config.json')
        }
    }

    # GitHub Copilot in VS Code and Copilot CLI
    $codeUser = Join-Path $roam 'Code\User'
    $copExt = @(Get-ChildItem -Path (Join-Path $homeDir '.vscode\extensions') -Directory -Filter 'github.copilot*' -ErrorAction SilentlyContinue)
    if (Test-Path -LiteralPath $codeUser) {
        $ws = Join-Path $codeUser 'workspaceStorage'
        $chat = @(Get-ChildItem -Path $ws -Directory -ErrorAction SilentlyContinue | ForEach-Object { Get-ChildItem -Path (Join-Path $_.FullName 'chatSessions') -File -ErrorAction SilentlyContinue })
        $chat += @(Get-ChildItem -Path (Join-Path $codeUser 'globalStorage\emptyWindowChatSessions') -File -ErrorAction SilentlyContinue)
        if ($copExt.Count -gt 0 -or $chat.Count -gt 0) {
            $st = @{ count = $chat.Count; bytes = [int64](($chat | Measure-Object -Property Length -Sum).Sum); oldest = ($chat | Sort-Object LastWriteTimeUtc | Select-Object -First 1).LastWriteTimeUtc; newest = ($chat | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1).LastWriteTimeUtc; files = $chat }
            Add-ToolStats (Get-Tool 'vscode-copilot' 'GitHub Copilot in VS Code' 'github-copilot') $user $st $ws
        }
        Add-McpServers (Read-JsonLoose (Join-Path $codeUser 'mcp.json')) 'VS Code' (Join-Path $codeUser 'mcp.json')
        Add-McpServers (Read-JsonLoose (Join-Path $codeUser 'settings.json')) 'VS Code' (Join-Path $codeUser 'settings.json')
    }
    $cop = Join-Path $homeDir '.copilot'
    if (Test-Path -LiteralPath $cop) {
        Add-ToolStats (Get-Tool 'copilot-cli' 'GitHub Copilot CLI' 'github-copilot') $user (Get-Stats (Join-Path $cop 'session-state') @('*') -Recurse) $cop
        Add-McpServers (Read-JsonLoose (Join-Path $cop 'mcp-config.json')) 'Copilot CLI' (Join-Path $cop 'mcp-config.json')
    }

    # Cursor
    $cu = Join-Path $roam 'Cursor\User'
    $cd = Join-Path $homeDir '.cursor'
    if ((Test-Path -LiteralPath $cu) -or (Test-Path -LiteralPath $cd)) {
        $t = Get-Tool 'cursor' 'Cursor' 'cursor'
        $dbs = @(Get-Item -LiteralPath (Join-Path $cu 'globalStorage\state.vscdb') -Force -ErrorAction SilentlyContinue)
        $dbs += @(Get-ChildItem -Path (Join-Path $cu 'workspaceStorage') -Directory -ErrorAction SilentlyContinue | ForEach-Object { Get-Item -LiteralPath (Join-Path $_.FullName 'state.vscdb') -Force -ErrorAction SilentlyContinue })
        $dbs = @($dbs | Where-Object { $_ })
        $st = @{ count = $dbs.Count; bytes = [int64](($dbs | Measure-Object -Property Length -Sum).Sum); oldest = ($dbs | Sort-Object LastWriteTimeUtc | Select-Object -First 1).LastWriteTimeUtc; newest = ($dbs | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1).LastWriteTimeUtc; files = $dbs }
        Add-ToolStats $t $user $st (Join-Path $cu 'globalStorage')
        Add-McpServers (Read-JsonLoose (Join-Path $cd 'mcp.json')) 'Cursor' (Join-Path $cd 'mcp.json')
        if (Test-Path -LiteralPath (Join-Path $cd 'hooks.json')) { $Flags.cursorUserHooks = $true }
    }

    # Other tools
    $simple = @(
        @('windsurf', 'Windsurf / Devin Desktop', 'devin-desktop', (Join-Path $homeDir '.codeium\windsurf'), 'mcp_config.json', @('cascade', 'memories'), '*'),
        @('kiro', 'Kiro', 'amazon-q-kiro', (Join-Path $homeDir '.kiro'), 'settings\mcp.json', @(), ''),
        @('amazon-q', 'Amazon Q Developer', 'amazon-q-kiro', (Join-Path $homeDir '.aws\amazonq'), 'mcp.json', @('history'), '*'),
        @('claude-desktop', 'Claude Desktop', 'claude-enterprise', (Join-Path $roam 'Claude'), 'claude_desktop_config.json', @('logs'), '*.log'),
        @('ollama', 'Ollama', 'endpoint-ai', (Join-Path $homeDir '.ollama'), '', @('.'), 'history'),
        @('lmstudio', 'LM Studio', 'endpoint-ai', (Join-Path $homeDir '.lmstudio'), '', @('conversations'), '*.json'),
        @('jan', 'Jan', 'endpoint-ai', (Join-Path $roam 'Jan\data'), '', @('threads'), '*.json*')
    )
    foreach ($s in $simple) {
        if (-not (Test-Path -LiteralPath $s[3])) { continue }
        $t = Get-Tool $s[0] $s[1] $s[2]
        $agg = @{ count = 0; bytes = [int64]0; oldest = $null; newest = $null; files = @() }
        foreach ($sub in $s[5]) {
            if (-not $s[6]) { continue }
            if ($sub -eq '.') { $part = Get-Stats $s[3] @($s[6]) } else { $part = Get-Stats (Join-Path $s[3] $sub) @($s[6]) -Recurse }
            $agg.count += $part.count; $agg.bytes += $part.bytes; $agg.files += $part.files
            if ($part.oldest -and ($null -eq $agg.oldest -or $part.oldest -lt $agg.oldest)) { $agg.oldest = $part.oldest }
            if ($part.newest -and ($null -eq $agg.newest -or $part.newest -gt $agg.newest)) { $agg.newest = $part.newest }
        }
        Add-ToolStats $t $user $agg $s[3]
        if ($s[4]) { Add-McpServers (Read-JsonLoose (Join-Path $s[3] $s[4])) $s[1] (Join-Path $s[3] $s[4]) }
    }
    foreach ($pkg in @(Get-ChildItem -Path (Join-Path $loc 'Packages') -Directory -Filter 'OpenAI.ChatGPT-Desktop_*' -ErrorAction SilentlyContinue)) {
        Add-ToolStats (Get-Tool 'chatgpt-desktop' 'ChatGPT desktop' 'chatgpt-enterprise') $user @{ count = 0; bytes = 0; oldest = $null; newest = $null; files = @() } $pkg.FullName
    }
    if (Test-Path -LiteralPath (Join-Path $loc 'CoreAIPlatform.00\UKP')) { $Flags.recallUsers += $user }
    foreach ($ab in @(@('Perplexity Comet', (Join-Path $loc 'Perplexity\Comet')), @('ChatGPT Atlas', (Join-Path $loc 'Programs\ChatGPT Atlas')))) {
        if ((Test-Path -LiteralPath $ab[1]) -and -not $Agentic.Contains($ab[0])) { $Agentic.Add($ab[0]) }
    }

    # Browser extensions
    $browserRoots = @(@('Chrome', (Join-Path $loc 'Google\Chrome\User Data')), @('Edge', (Join-Path $loc 'Microsoft\Edge\User Data')), @('Brave', (Join-Path $loc 'BraveSoftware\Brave-Browser\User Data')))
    foreach ($br in $browserRoots) {
        if (-not (Test-Path -LiteralPath $br[1])) { continue }
        foreach ($man in @(Get-ChildItem -Path (Join-Path $br[1] '*\Extensions\*\*\manifest.json') -File -ErrorAction SilentlyContinue)) {
            $m = Read-JsonLoose $man.FullName
            $name = [string](Get-Prop $m 'name')
            if ($name -like '__MSG_*') {
                $key = $name.Substring(6, $name.Length - 8)
                foreach ($locale in @((Get-Prop $m 'default_locale'), 'en', 'en_US')) {
                    if (-not $locale) { continue }
                    $msgs = Read-JsonLoose (Join-Path $man.DirectoryName "_locales\$locale\messages.json")
                    if ($msgs) {
                        $hit = $msgs.PSObject.Properties | Where-Object { $_.Name -ieq $key } | Select-Object -First 1
                        if ($hit) { $name = [string](Get-Prop $hit.Value 'message'); break }
                    }
                }
            }
            if ($name -match $ExtPattern -and -not ($Extensions | Where-Object { $_.name -eq $name -and $_.browser -eq $br[0] })) {
                if ($name.Length -gt 80) { $name = $name.Substring(0, 80) }
                $Extensions.Add([ordered]@{ name = $name; browser = $br[0]; id = $man.Directory.Parent.Name; user = $user })
            }
        }
    }
}

# ---------------------------------------------------------------- host telemetry
$Host_ = [ordered]@{ edr = @(); process_audit = $null; cmdline = $null; sysmon = $false; scriptblock = $null; time_source = ''; time_ok = $null; recall_policy = $null }
$Host_.cmdline = Get-RegValue 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit' 'ProcessCreationIncludeCmdLine_Enabled'
$Host_.scriptblock = Get-RegValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging' 'EnableScriptBlockLogging'
$Host_.recall_policy = Get-RegValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsAI' 'DisableAIDataAnalysis'
foreach ($svc in $EdrServices.Keys) { if (Get-Service -Name $svc -ErrorAction SilentlyContinue) { $Host_.edr += $EdrServices[$svc] } }
if ((Get-Service -Name 'Sysmon64' -ErrorAction SilentlyContinue) -or (Get-Service -Name 'Sysmon' -ErrorAction SilentlyContinue)) { $Host_.sysmon = $true }
$ap = (& auditpol.exe /get /subcategory:"Process Creation" 2>$null) -join "`n"
if ($LASTEXITCODE -eq 0 -and $ap) { $Host_.process_audit = [bool]($ap -match 'Process Creation\s+(Success|Success and Failure)') }
$w32 = (& w32tm.exe /query /status 2>$null) -join "`n"
$m = [regex]::Match($w32, 'Source:\s*(.+)')
if ($m.Success) { $Host_.time_source = $m.Groups[1].Value.Trim(); $Host_.time_ok = -not ($Host_.time_source -match 'Local CMOS Clock|Free-running') }
foreach ($c in @(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue)) {
    if ($AiPorts.ContainsKey([int]$c.LocalPort)) { $Listeners.Add([ordered]@{ port = [int]$c.LocalPort; address = [string]$c.LocalAddress; process = $AiPorts[[int]$c.LocalPort] }) }
}
$ollamaHost = $env:OLLAMA_HOST
if (-not $ollamaHost) { $ollamaHost = [Environment]::GetEnvironmentVariable('OLLAMA_HOST', 'Machine') }

# ---------------------------------------------------------------- decisions
$managed = $null; $managedSrc = @()
foreach ($dir in @((Join-Path $env:ProgramFiles 'ClaudeCode'), (Join-Path $env:ProgramData 'ClaudeCode'))) {
    $mf = Join-Path $dir 'managed-settings.json'
    if (Test-Path -LiteralPath $mf) { $managed = Read-JsonLoose $mf; $managedSrc += $mf; Add-ConfigFile $mf 'config:claude-code-managed'; break }
}
if (-not $managed) {
    $reg = Get-RegValue 'HKLM:\SOFTWARE\Policies\ClaudeCode' 'Settings'
    if ($reg) { try { $managed = $reg | ConvertFrom-Json; $managedSrc += 'HKLM\SOFTWARE\Policies\ClaudeCode' } catch { } }
}
if ($Tools.Contains('claude-code')) {
    $cc = $Tools['claude-code']; $cc.managed = ($managedSrc.Count -gt 0)
    $menv = Get-Prop $managed 'env'
    if ($managedSrc.Count) { Add-Observation 'CCD-01' 'met' ("Managed settings found: " + ($managedSrc -join ', ')) 'claude-code' } else { Add-Observation 'CCD-01' 'gap' 'No managed-settings.json or policy key on this endpoint.' 'claude-code' }
    $mcl = Get-Prop $managed 'cleanupPeriodDays'
    $userCleanups = @($Flags.claude | ForEach-Object { $_.cleanup } | Where-Object { $_ -is [int] -or $_ -is [long] })
    if ($mcl) { $eff = [int]$mcl } elseif ($userCleanups.Count) { $eff = [int](($userCleanups | Measure-Object -Minimum).Minimum) } else { $eff = 30 }
    $cc.retention_days = $eff
    $src = 'user or default'; if ($mcl) { $src = 'managed' }
    $stt = 'gap'; if ($mcl -and [int]$mcl -ge 90) { $stt = 'met' }
    $oldestDay = ''; if ($cc.oldest) { $oldestDay = $cc.oldest.Substring(0, 10) }
    Add-Observation 'CCD-02' $stt "Effective cleanupPeriodDays $eff ($src); $($cc.transcripts) transcripts, oldest $oldestDay." 'claude-code' ([ordered]@{ source = 'ccd-local'; days = $eff; oldest = $oldestDay })
    $telM = ([string](Get-Prop $menv 'CLAUDE_CODE_ENABLE_TELEMETRY') -eq '1') -and (Get-Prop $menv 'OTEL_EXPORTER_OTLP_ENDPOINT') -and (Get-Prop $menv 'OTEL_LOGS_EXPORTER')
    $telU = @($Flags.claude | Where-Object { [string](Get-Prop $_.env 'CLAUDE_CODE_ENABLE_TELEMETRY') -eq '1' }).Count -gt 0
    if ($telM) { Add-Observation 'CCD-04' 'met' 'Telemetry exporter set in managed settings.' 'claude-code' } elseif ($telU) { Add-Observation 'CCD-04' 'partial' 'Telemetry only in user settings; developers can change it.' 'claude-code' } else { Add-Observation 'CCD-04' 'gap' 'No OpenTelemetry export configured.' 'claude-code' }
    $mh = @(Get-HookCommands $managed | Where-Object { $_[1] -match $ExportHint })
    $uh = @($Flags.claude | ForEach-Object { $_.hooks } | Where-Object { $_ -and $_[1] -match $ExportHint })
    $locked = [bool](Get-Prop $managed 'allowManagedHooksOnly')
    if ($mh.Count -and $locked) { Add-Observation 'CCD-05' 'met' 'Managed export hook with allowManagedHooksOnly.' 'claude-code' }
    elseif ($mh.Count -or $uh.Count) { Add-Observation 'CCD-05' 'partial' 'Export hook present but user hooks still allowed or hook is user-level.' 'claude-code' }
    else { Add-Observation 'CCD-05' 'gap' 'No hook copies transcripts off the endpoint.' 'claude-code' }
    $content = ([string](Get-Prop $menv 'OTEL_LOG_USER_PROMPTS') -eq '1') -and ([string](Get-Prop $menv 'OTEL_LOG_TOOL_DETAILS') -eq '1')
    $cc.central_capture = ($mh.Count -gt 0) -or ($telM -and $content)
    $sup = $env:CLAUDE_CODE_SKIP_PROMPT_HISTORY -or (Get-Prop $menv 'CLAUDE_CODE_SKIP_PROMPT_HISTORY') -or (@($Flags.claude | Where-Object { Get-Prop $_.env 'CLAUDE_CODE_SKIP_PROMPT_HISTORY' }).Count -gt 0)
    if ($sup) { Add-Observation 'CCD-06' 'gap' 'CLAUDE_CODE_SKIP_PROMPT_HISTORY is set.' 'claude-code' } else { Add-Observation 'CCD-06' 'met' 'No transcript or history suppression found.' 'claude-code' }
    $dis = [string](Get-Prop (Get-Prop $managed 'permissions') 'disableBypassPermissionsMode') -eq 'disable'
    $byp = @($Flags.claude | Where-Object { $_.defaultMode -eq 'bypassPermissions' } | ForEach-Object { $_.user })
    if ($dis) { Add-Observation 'CCD-07' 'met' 'Bypass mode disabled by managed policy.' 'claude-code' } else { $d = 'Bypass mode not disabled'; if ($byp.Count) { $d += '; default mode bypassPermissions for ' + ($byp -join ', ') }; Add-Observation 'CCD-07' 'gap' ($d + '.') 'claude-code' }
    $logins = @($Flags.claude | ForEach-Object { $_.login } | Sort-Object -Unique)
    if ($ExpectClaudeOrg) {
        $bad = @($Flags.claude | Where-Object { $_.login -ne 'none' -and ($_.login -ne 'claude.ai' -or $_.org -ne $ExpectClaudeOrg) })
        if ($bad.Count) { Add-Observation 'CLE-06' 'gap' 'Some Claude Code users are not signed in to the expected Enterprise organisation.' 'claude-enterprise' } else { Add-Observation 'CLE-06' 'met' 'All Claude Code users signed in to the expected organisation.' 'claude-enterprise' }
    } else { Add-Observation 'CLE-06' 'info' ("Claude Code login methods: " + ($logins -join ', ') + ". Pass -ExpectClaudeOrg to verify the organisation.") 'claude-enterprise' }
} else {
    foreach ($cid in @('CCD-01', 'CCD-02', 'CCD-04', 'CCD-05', 'CCD-06', 'CCD-07')) { Add-Observation $cid 'na' 'Claude Code not found on this endpoint.' 'claude-code' }
}
if ($Tools.Contains('vscode-copilot') -or $Tools.Contains('copilot-cli')) {
    $n = 0; foreach ($k in @('vscode-copilot', 'copilot-cli')) { if ($Tools.Contains($k)) { $n += $Tools[$k].transcripts } }
    Add-Observation 'GHC-04' 'gap' "$n Copilot chat or CLI session files held only on this endpoint; no central capture detected." 'github-copilot'
}
if ($Tools.Contains('cursor')) {
    $ent = Test-Path -LiteralPath (Join-Path $env:ProgramData 'Cursor\hooks.json')
    $Tools['cursor'].managed = $ent; $Tools['cursor'].central_capture = $ent
    if ($ent) { Add-Observation 'CUR-02' 'met' 'Enterprise hooks.json deployed.' 'cursor' } elseif ($Flags.cursorUserHooks) { Add-Observation 'CUR-02' 'partial' 'User-level hooks only.' 'cursor' } else { Add-Observation 'CUR-02' 'gap' 'No Cursor hooks configured; chat history stays in the local database.' 'cursor' }
}
if ($Flags.codex.Count) {
    $api = @($Flags.codex | Where-Object { $_.apiKey } | ForEach-Object { $_.user })
    if ($api.Count) { Add-Observation 'CDX-01' 'gap' ("API-key authentication for: " + ($api -join ', ')) 'openai-codex' } else { Add-Observation 'CDX-01' 'met' 'Codex signed in with ChatGPT.' 'openai-codex' }
    if (@($Flags.codex | Where-Object { -not $_.otel }).Count -eq 0) { Add-Observation 'CDX-04' 'met' 'OpenTelemetry exporter configured in config.toml.' 'openai-codex' } else { Add-Observation 'CDX-04' 'gap' 'No [otel] exporter in Codex config.' 'openai-codex' }
}
if ($Flags.gemini.Count) {
    $sysp = Join-Path $env:ProgramData 'gemini-cli\settings.json'
    $sys = Read-JsonLoose $sysp
    $stel = Get-Prop $sys 'telemetry'
    if ((Get-Prop $stel 'enabled') -and ((Get-Prop $stel 'otlpEndpoint') -or (Get-Prop $stel 'target') -eq 'gcp')) { Add-Observation 'GCA-03' 'met' 'System settings export telemetry.' 'google-code'; $Tools['gemini-cli'].central_capture = $true }
    elseif (@($Flags.gemini | Where-Object { $_.telemetry }).Count) { Add-Observation 'GCA-03' 'partial' 'Telemetry set only in user settings.' 'google-code' }
    else { Add-Observation 'GCA-03' 'gap' 'Gemini CLI telemetry not configured.' 'google-code' }
    $Tools['gemini-cli'].managed = [bool]$sys
}
$toolCount = $Tools.Count
Add-Observation 'EPT-01' 'met' "$toolCount AI tools, $($Mcp.Count) MCP server entries, $($Extensions.Count) AI browser extensions, $($Listeners.Count) local model listeners." 'endpoint-ai'
$edrText = 'none detected'; if ($Host_.edr.Count) { $edrText = ($Host_.edr -join ', ') }
$pa = 'off or unreadable'; if ($Host_.process_audit) { $pa = 'on' }
$cl = 'off'; if ($Host_.cmdline -eq 1) { $cl = 'on' }
$sy = 'absent'; if ($Host_.sysmon) { $sy = 'present' }
$st = 'gap'; if (($Host_.process_audit -and $Host_.cmdline -eq 1) -or $Host_.sysmon) { $st = 'met' } elseif ($Host_.edr.Count) { $st = 'partial' }
Add-Observation 'EPT-02' $st "Process Creation auditing $pa; command line $cl; Sysmon $sy; EDR: $edrText." 'endpoint-ai' $null ([ordered]@{ edr = $Host_.edr })
if ($Host_.scriptblock -eq 1) { Add-Observation 'EPT-03' 'met' 'Script block logging enforced by policy.' 'endpoint-ai' } else { Add-Observation 'EPT-03' 'gap' 'Script block logging not enforced.' 'endpoint-ai' }
$withContent = @($Tools.Values | Where-Object { $_.transcripts -gt 0 })
if ($withContent.Count) {
    $central = @($withContent | Where-Object { $_.central_capture })
    $st = 'gap'; if ($central.Count -eq $withContent.Count) { $st = 'met' } elseif ($central.Count) { $st = 'partial' }
    $rets = @($withContent | Where-Object { $_.retention_days } | ForEach-Object { $_.retention_days }); $rd = 30; if ($rets.Count) { $rd = ($rets | Measure-Object -Minimum).Minimum }
    $old = (@($withContent | Where-Object { $_.oldest } | ForEach-Object { $_.oldest }) | Sort-Object | Select-Object -First 1); if ($old) { $old = $old.Substring(0, 10) } else { $old = '' }
    Add-Observation 'EPT-05' $st "$($central.Count) of $($withContent.Count) tools with local transcripts have central capture." 'endpoint-ai' ([ordered]@{ source = 'ept-agents'; days = $rd; oldest = $old })
}
$exposed = @($Listeners | Where-Object { @('127.0.0.1', '::1') -notcontains $_.address })
if ($ollamaHost -and ($ollamaHost -like '0.0.0.0*' -or $ollamaHost -like '[::]*')) { $exposed += [ordered]@{ port = 11434; address = $ollamaHost; process = 'Ollama (OLLAMA_HOST)' } }
if ($exposed.Count) { Add-Observation 'EPT-06' 'gap' ("Model runtime reachable beyond localhost: " + (($exposed | ForEach-Object { "$($_.process) $($_.address):$($_.port)" }) -join ', ')) 'endpoint-ai' }
elseif ($Listeners.Count -or $Tools.Contains('ollama')) { Add-Observation 'EPT-06' 'met' 'Local model runtimes bound to localhost only.' 'endpoint-ai' }
else { Add-Observation 'EPT-06' 'na' 'No local model runtime listening.' 'endpoint-ai' }
if ($null -eq $Host_.time_ok) { Add-Observation 'EPT-07' 'info' 'Time synchronisation state could not be read.' 'endpoint-ai' }
elseif ($Host_.time_ok) { Add-Observation 'EPT-07' 'met' ("Time source: " + $Host_.time_source) 'endpoint-ai' }
else { Add-Observation 'EPT-07' 'gap' ("Time source: " + $Host_.time_source) 'endpoint-ai' }
$ag = 'none'; if ($Agentic.Count) { $ag = ($Agentic -join ', ') }
Add-Observation 'EPT-08' 'met' "$($Extensions.Count) AI-related browser extensions; agentic browsers: $ag." 'endpoint-ai'
if ($Host_.recall_policy -eq 1) { Add-Observation 'EPT-10' 'met' 'Recall disabled by policy.' 'endpoint-ai' }
elseif ($Flags.recallUsers.Count) { Add-Observation 'EPT-10' 'partial' ("Recall snapshot store present for: " + ($Flags.recallUsers -join ', ') + '; no disabling policy.') 'endpoint-ai' }
else { Add-Observation 'EPT-10' 'info' 'No Recall store found; no policy set.' 'endpoint-ai' }
if ($Mcp.Count) { Add-Observation 'AGT-05' 'info' "$($Mcp.Count) MCP server definitions found." 'agents-mcp' }

# ---------------------------------------------------------------- bundle
$toolList = New-Object System.Collections.Generic.List[object]
foreach ($t in $Tools.Values) {
    $toolList.Add([ordered]@{ id = $t.id; name = $t.name; platform = $t.platform; users = $t.users.ToArray(); transcripts = $t.transcripts; bytes = $t.bytes; oldest = $t.oldest; newest = $t.newest;
        retention_days = $t.retention_days; managed = [bool]$t.managed; central_capture = [bool]$t.central_capture; paths = $t.paths.ToArray() })
}
if ($Preserve -and $Files.Count) {
    $man = Join-Path $Preserve 'manifest.csv'
    $Files | ForEach-Object { [pscustomobject]$_ } | Export-Csv -LiteralPath $man -NoTypeInformation -Encoding UTF8
    $Notes.Add("Preserved $($Files.Count) files ($script:PreservedBytes bytes) to $Preserve; manifest.csv lists SHA-256 values.")
}
$hostName = $env:COMPUTERNAME
$operator = "$env:USERDOMAIN\$env:USERNAME"
$os = (Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue)
$osText = 'Windows'; if ($os) { $osText = "$($os.Caption) $($os.Version)" }
$finished = (Get-Date).ToUniversalTime()
$mode = 'inventory'; if ($Preserve) { $mode = 'preserve' }
$bundle = [ordered]@{
    schema       = 'aifr.bundle/1'
    bundle_id    = [guid]::NewGuid().ToString()
    collector    = [ordered]@{ name = 'aifr-endpoint'; version = $CollectorVersion; impl = "powershell $($PSVersionTable.PSVersion)" }
    run          = [ordered]@{ started = (ConvertTo-IsoUtc $Started); finished = (ConvertTo-IsoUtc $finished); operator = $operator; mode = $mode; argv = ($PSBoundParameters.Keys -join ' ') }
    target       = [ordered]@{ type = 'endpoint'; id = $hostName; os = $osText; details = [ordered]@{ all_users = [bool]$AllUsers; os_family = 'Windows' } }
    observations = $Observations.ToArray()
    inventory    = [ordered]@{ tools = $toolList.ToArray(); mcp_servers = @($Mcp.ToArray() | Select-Object -First 300); extensions = $Extensions.ToArray(); agentic_browsers = $Agentic.ToArray(); listeners = $Listeners.ToArray(); local_models = @(); telemetry = $Host_ }
    files        = $Files.ToArray()
    notes        = $Notes.ToArray()
}
New-Item -ItemType Directory -Force -Path $OutputPath | Out-Null
$name = "aifr_endpoint_{0}_{1}.json" -f ($hostName -replace '[^A-Za-z0-9\-.]', '-'), $finished.ToString('yyyyMMddTHHmmssZ')
$path = Join-Path (Resolve-Path $OutputPath) $name
try { $json = $bundle | ConvertTo-Json -Depth 10 -ErrorAction Stop } catch { throw "Could not serialise the bundle: $($_.Exception.Message)" }
if (-not $json) { throw 'Bundle serialisation produced no output.' }
[IO.File]::WriteAllText($path, $json, (New-Object System.Text.UTF8Encoding $false))
$hash = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower()
[IO.File]::WriteAllText("$path.sha256", "$hash  $name`n", (New-Object System.Text.UTF8Encoding $false))

$counts = $Observations | Group-Object { $_.status } | ForEach-Object { "$($_.Count) $($_.Name)" }
Write-Output "Wrote $path"
Write-Output "SHA-256 $hash"
Write-Output ("{0} observations: {1}" -f $Observations.Count, ($counts -join ', '))
foreach ($t in $toolList) { Write-Output ("  {0,-28} transcripts {1,6}  managed {2}" -f $t.name, $t.transcripts, $(if ($t.managed) { 'yes' } else { 'no' })) }
