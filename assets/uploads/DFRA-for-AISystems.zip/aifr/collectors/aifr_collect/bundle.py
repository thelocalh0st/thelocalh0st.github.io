"""Evidence bundle: the one format every collector writes and the Workbench imports.

A bundle is a JSON document (schema aifr.bundle/1) with observations keyed by
knowledge-base check IDs, an optional inventory, and a list of hashed files.
It is written next to a sha256sum-compatible sidecar so integrity can be
verified on receipt.
"""
import getpass
import hashlib
import json
import os
import platform
import socket
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path

from . import __version__

SCHEMA = "aifr.bundle/1"
STATUSES = {"met", "partial", "gap", "na", "info", "error"}


def utcnow():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def iso(ts):
    """Epoch seconds to ISO-8601 UTC."""
    if ts is None:
        return ""
    return datetime.fromtimestamp(ts, timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def sha256_file(path, limit=None):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        read = 0
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
            read += len(chunk)
            if limit and read >= limit:
                break
    return h.hexdigest()


def operator():
    try:
        user = getpass.getuser()
    except Exception:
        user = os.environ.get("USERNAME") or os.environ.get("USER") or "unknown"
    return f"{user}@{socket.gethostname()}"


class Bundle:
    def __init__(self, collector, target_type, target_id, mode="inventory", details=None):
        self.started = utcnow()
        self.doc = {
            "schema": SCHEMA,
            "bundle_id": str(uuid.uuid4()),
            "collector": {"name": collector, "version": __version__, "impl": "python " + platform.python_version()},
            "run": {"started": self.started, "finished": "", "operator": operator(), "mode": mode,
                    "argv": " ".join(_redact_argv(sys.argv[1:]))},
            "target": {"type": target_type, "id": target_id, "os": platform.platform(), "details": details or {}},
            "observations": [],
            "inventory": {},
            "files": [],
            "notes": [],
        }

    def observe(self, control, status, detail, platform_id="", data=None, retention=None, title=""):
        if status not in STATUSES:
            raise ValueError(f"bad status {status}")
        obs = {"control": control, "platform": platform_id, "status": status, "detail": detail}
        if title:
            obs["title"] = title
        if data:
            obs["data"] = data
        if retention:
            obs["retention"] = retention
        self.doc["observations"].append(obs)
        return obs

    def note(self, text):
        self.doc["notes"].append(text)

    def add_file(self, path, role, sha=None, size=None, mtime=None):
        self.doc["files"].append({"path": str(path), "role": role, "sha256": sha, "bytes": size, "mtime": mtime})

    @property
    def inventory(self):
        return self.doc["inventory"]

    def write(self, out_dir, label=None):
        if not self.doc["run"]["finished"]:
            self.doc["run"]["finished"] = utcnow()
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)
        stamp = self.doc["run"]["finished"].replace(":", "").replace("-", "")
        name = "aifr_{}_{}_{}.json".format(
            self.doc["collector"]["name"].replace("aifr-", ""),
            _safe(label or self.doc["target"]["id"]), stamp)
        path = out / name
        data = json.dumps(self.doc, indent=1, ensure_ascii=False, sort_keys=False).encode("utf-8")
        path.write_bytes(data)
        digest = hashlib.sha256(data).hexdigest()
        (out / (name + ".sha256")).write_text(f"{digest}  {name}\n", encoding="ascii")
        return path, digest


def _safe(s):
    return "".join(c if c.isalnum() or c in "-." else "-" for c in str(s))[:60] or "target"


def _redact_argv(argv):
    out, skip = [], False
    for a in argv:
        if skip:
            out.append("***")
            skip = False
            continue
        if a.lower() in ("--token", "--key", "--api-key", "--password"):
            skip = True
        out.append(a)
    return out


def summarise(path, digest, bundle):
    obs = bundle.doc["observations"]
    counts = {}
    for o in obs:
        counts[o["status"]] = counts.get(o["status"], 0) + 1
    order = ["met", "partial", "gap", "na", "info", "error"]
    parts = [f"{counts[k]} {k}" for k in order if counts.get(k)]
    print(f"\nWrote {path}")
    print(f"SHA-256 {digest}")
    print(f"{len(obs)} observations: " + ", ".join(parts))
