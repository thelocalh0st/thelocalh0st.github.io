"""Endpoint collector: AI tools, their forensic artefacts and the host telemetry that corroborates them.

Inventory mode (default) records metadata only: which tools exist, how many
transcript files they hold, date ranges, retention and capture settings, MCP
servers, local model runtimes, AI browser extensions, and process-auditing,
EDR and time-sync posture. It never reads conversation content.

Preserve mode (--preserve DIR) additionally copies the artefacts into DIR with
a SHA-256 manifest, for incident triage under an authorised investigation.
"""
import json
import os
import platform
import re
import shutil
import subprocess
from pathlib import Path

from .bundle import Bundle, iso, sha256_file

OS = platform.system()
WIN, MAC, LIN = OS == "Windows", OS == "Darwin", OS == "Linux"
AI_PORTS = {11434: "Ollama", 1234: "LM Studio", 1337: "Jan", 4891: "GPT4All"}
EXT_PATTERN = re.compile(r"\b(chat ?gpt|gpt|openai|claude|anthropic|gemini|copilot|perplexity|deepseek|grok|monica|merlin|sider|harpa|maxai|grammarly|jasper|writesonic|llm|ai (assistant|chat|agent|writer|sidebar|summar\w*))\b", re.I)
EDR_WIN = {"Sense": "Microsoft Defender for Endpoint", "CSFalconService": "CrowdStrike Falcon", "SentinelAgent": "SentinelOne",
           "CbDefense": "Carbon Black", "cyserver": "Cortex XDR", "ElasticEndpoint": "Elastic Defend", "xagt": "Trellix HX",
           "Sophos Endpoint Defense Service": "Sophos", "ekrn": "ESET", "CylanceSvc": "Cylance"}
EDR_PROC = {"falcon-sensor": "CrowdStrike Falcon", "falcond": "CrowdStrike Falcon", "SentinelAgent": "SentinelOne", "sentineld": "SentinelOne",
            "wdavdaemon": "Microsoft Defender for Endpoint", "mdatp": "Microsoft Defender for Endpoint", "elastic-endpoint": "Elastic Defend",
            "cbagentd": "Carbon Black", "traps_pmd": "Cortex XDR", "pmd": "Cortex XDR", "JamfProtect": "Jamf Protect", "osqueryd": "osquery"}
SECRET = re.compile(r"(?i)((?:api[_-]?key|token|secret|password|bearer|authorization)[\"']?\s*[:=]\s*[\"']?)[^\s\"',}]+")
SECRET2 = re.compile(r"\b(sk-[A-Za-z0-9_\-]{6}|ghp_|gho_|github_pat_|xox[abpr]-|AKIA)[A-Za-z0-9_\-]*")


def redact(s):
    s = SECRET.sub(lambda m: m.group(1) + "***", str(s))
    return SECRET2.sub(lambda m: m.group(1) + "***", s)


def run(cmd, timeout=15):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, errors="replace")
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except (OSError, subprocess.SubprocessError) as e:
        return -1, str(e)


def load_jsonc(path):
    """JSON with comments and trailing commas (VS Code style)."""
    try:
        text = Path(path).read_text(encoding="utf-8-sig", errors="replace")
    except OSError:
        return None
    out, i, n, in_str = [], 0, len(text), False
    while i < n:
        c = text[i]
        if in_str:
            out.append(c)
            if c == "\\" and i + 1 < n:
                out.append(text[i + 1]); i += 2; continue
            if c == '"':
                in_str = False
        elif c == '"':
            in_str = True; out.append(c)
        elif text.startswith("//", i):
            j = text.find("\n", i); i = n if j < 0 else j; continue
        elif text.startswith("/*", i):
            j = text.find("*/", i + 2); i = n if j < 0 else j + 2; continue
        else:
            out.append(c)
        i += 1
    cleaned = re.sub(r",(\s*[}\]])", r"\1", "".join(out))
    try:
        return json.loads(cleaned)
    except ValueError:
        return None


def toml_sections(path):
    """Minimal TOML reader: {section: {key: raw value}} for flat keys. Enough for Codex config.toml."""
    sections, cur = {"": {}}, ""
    try:
        lines = Path(path).read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return None
    for line in lines:
        s = line.split("#", 1)[0].strip()
        if not s:
            continue
        m = re.match(r"^\[\[?([^\]]+)\]\]?$", s)
        if m:
            cur = m.group(1).strip(); sections.setdefault(cur, {}); continue
        if "=" in s:
            k, v = s.split("=", 1)
            sections.setdefault(cur, {})[k.strip()] = v.strip().strip('"').strip("'")
    return sections


def file_stats(root, patterns, cap=200000):
    count = size = 0
    oldest = newest = None
    files = []
    root = Path(root)
    if not root.exists():
        return {"count": 0, "bytes": 0, "oldest": "", "newest": "", "files": []}
    for pat in patterns:
        try:
            it = root.glob(pat)
            for p in it:
                if count >= cap:
                    break
                try:
                    if not p.is_file():
                        continue
                    st = p.stat()
                except OSError:
                    continue
                count += 1
                size += st.st_size
                oldest = st.st_mtime if oldest is None or st.st_mtime < oldest else oldest
                newest = st.st_mtime if newest is None or st.st_mtime > newest else newest
                files.append(p)
        except OSError:
            continue
    return {"count": count, "bytes": size, "oldest": iso(oldest), "newest": iso(newest), "files": files}


def roaming(home):
    if WIN:
        return home / "AppData" / "Roaming"
    if MAC:
        return home / "Library" / "Application Support"
    return home / ".config"


def local(home):
    if WIN:
        return home / "AppData" / "Local"
    if MAC:
        return home / "Library" / "Application Support"
    return home / ".local" / "share"


def user_homes(all_users):
    if not all_users:
        return [Path.home()]
    homes = []
    if WIN:
        base, skip = Path(os.environ.get("SystemDrive", "C:") + "\\Users"), {"public", "default", "default user", "all users", "defaultapppool", "wdagutilityaccount"}
    elif MAC:
        base, skip = Path("/Users"), {"shared", ".localized", "guest"}
    else:
        base, skip = Path("/home"), set()
        if Path("/root").exists() and os.access("/root", os.R_OK):
            homes.append(Path("/root"))
    try:
        for d in sorted(base.iterdir()):
            if d.is_dir() and d.name.lower() not in skip:
                homes.append(d)
    except OSError:
        homes.append(Path.home())
    return homes or [Path.home()]


def mcp_servers(obj, client, source):
    out = []
    if not isinstance(obj, dict):
        return out
    for key in ("mcpServers", "servers", "mcp_servers", "context_servers"):
        d = obj.get(key)
        if isinstance(d, dict):
            for name, cfg in d.items():
                if not isinstance(cfg, dict):
                    continue
                url = cfg.get("url") or cfg.get("serverUrl") or cfg.get("httpUrl")
                cmd = cfg.get("command")
                args = cfg.get("args") or []
                transport = cfg.get("type") or cfg.get("transport") or ("http" if url else "stdio")
                target = url or " ".join([str(cmd or "")] + [str(a) for a in args[:8]])
                out.append({"name": str(name), "transport": str(transport), "target": redact(target)[:220], "client": client, "source": str(source)})
    if isinstance(obj.get("mcp"), dict):
        out += mcp_servers(obj["mcp"], client, source)
    return out


def managed_paths():
    if WIN:
        pf = Path(os.environ.get("ProgramFiles", r"C:\Program Files"))
        pd = Path(os.environ.get("ProgramData", r"C:\ProgramData"))
        return {"claude": [pf / "ClaudeCode", pd / "ClaudeCode"], "gemini": [pd / "gemini-cli" / "settings.json"], "cursor_hooks": [pd / "Cursor" / "hooks.json"]}
    if MAC:
        return {"claude": [Path("/Library/Application Support/ClaudeCode")], "gemini": [Path("/Library/Application Support/GeminiCli/settings.json")], "cursor_hooks": [Path("/Library/Application Support/Cursor/hooks.json")]}
    return {"claude": [Path("/etc/claude-code")], "gemini": [Path("/etc/gemini-cli/settings.json")], "cursor_hooks": [Path("/etc/cursor/hooks.json")]}


def claude_managed():
    """Merge managed-settings.json and managed-settings.d/*.json (alphabetical)."""
    merged, sources = {}, []
    for d in managed_paths()["claude"]:
        files = []
        if (d / "managed-settings.json").exists():
            files.append(d / "managed-settings.json")
        if (d / "managed-settings.d").is_dir():
            files += sorted((d / "managed-settings.d").glob("*.json"))
        for f in files:
            data = load_jsonc(f)
            if isinstance(data, dict):
                sources.append(str(f))
                for k, v in data.items():
                    if isinstance(v, dict) and isinstance(merged.get(k), dict):
                        merged[k] = dict(merged[k], **v)
                    else:
                        merged[k] = v
        if sources:
            break
    if WIN and not sources:
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Policies\ClaudeCode") as k:
                val, _ = winreg.QueryValueEx(k, "Settings")
                data = json.loads(val)
                if isinstance(data, dict):
                    merged, sources = data, [r"HKLM\SOFTWARE\Policies\ClaudeCode"]
        except (OSError, ValueError, ImportError):
            pass
    return merged, sources


EXPORT_HINT = re.compile(r"(curl|wget|Invoke-WebRequest|Invoke-RestMethod|aws s3|azcopy|gsutil|rsync|robocopy|scp |Copy-Item|cp |https?://)", re.I)


def hook_commands(settings, events=("SessionEnd", "Stop", "PostToolUse", "UserPromptSubmit")):
    cmds = []
    hooks = settings.get("hooks") if isinstance(settings, dict) else None
    if not isinstance(hooks, dict):
        return cmds
    for ev in events:
        for matcher in hooks.get(ev) or []:
            for h in (matcher.get("hooks") if isinstance(matcher, dict) else None) or []:
                if isinstance(h, dict) and h.get("command"):
                    cmds.append((ev, str(h["command"])))
    return cmds


class EndpointScan:
    def __init__(self, all_users=False, preserve=None, expect_claude_org=None, max_preserve_mb=2048):
        self.all_users = all_users
        self.preserve = Path(preserve) if preserve else None
        self.expect_org = expect_claude_org
        self.max_preserve = max_preserve_mb * 1024 * 1024
        self.preserved = 0
        host = platform.node() or "host"
        self.b = Bundle("aifr-endpoint", "endpoint", host, mode="preserve" if preserve else "inventory",
                        details={"all_users": all_users, "os_family": OS})
        self.tools = {}
        self.mcp = []
        self.extensions = []
        self.agentic = []
        self.listeners = []
        self.flags = {}

    # ---------- helpers ----------
    def tool(self, tid, name, kb):
        t = self.tools.get(tid)
        if not t:
            t = self.tools[tid] = {"id": tid, "name": name, "platform": kb, "users": [], "transcripts": 0, "bytes": 0,
                                   "oldest": "", "newest": "", "retention_days": None, "managed": False, "central_capture": False, "paths": []}
        return t

    def add_stats(self, t, user, stats, path):
        if user not in t["users"]:
            t["users"].append(user)
        t["transcripts"] += stats["count"]
        t["bytes"] += stats["bytes"]
        if stats["oldest"] and (not t["oldest"] or stats["oldest"] < t["oldest"]):
            t["oldest"] = stats["oldest"]
        if stats["newest"] and stats["newest"] > t["newest"]:
            t["newest"] = stats["newest"]
        t["paths"].append(str(path))
        self.keep(stats["files"], t["id"], user)

    def keep(self, files, tid, user):
        if not self.preserve:
            return
        for f in files:
            for p in [f] + ([Path(str(f) + "-wal"), Path(str(f) + "-shm")] if str(f).endswith(".vscdb") else []):
                try:
                    if not p.exists():
                        continue
                    size = p.stat().st_size
                    if self.preserved + size > self.max_preserve:
                        self.b.note(f"Preserve limit reached; skipped {p}")
                        return
                    rel = Path(tid) / user / p.name if p.parent.name == "" else Path(tid) / user / p.parent.name / p.name
                    dest = self.preserve / rel
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(p, dest)
                    self.preserved += size
                    self.b.add_file(p, "preserved:" + tid, sha256_file(dest), size, iso(p.stat().st_mtime))
                except OSError as e:
                    self.b.note(f"Could not preserve {p}: {e}")

    def config_file(self, path, role):
        try:
            p = Path(path)
            if p.is_file():
                self.b.add_file(p, role, sha256_file(p), p.stat().st_size, iso(p.stat().st_mtime))
                if self.preserve:
                    self.keep([p], "config", "_")
        except OSError:
            pass

    # ---------- per-user tools ----------
    def scan_user(self, home):
        user = home.name
        self.claude_code(home, user)
        self.codex(home, user)
        self.gemini(home, user)
        self.copilot(home, user)
        self.cursor(home, user)
        self.simple(home, user)
        self.browsers(home, user)

    def claude_code(self, home, user):
        root = home / ".claude"
        cfg = load_jsonc(home / ".claude.json")
        if not root.exists() and cfg is None:
            return
        t = self.tool("claude-code", "Claude Code", "claude-code")
        stats = file_stats(root, ["projects/*/*.jsonl", "projects/*/*/subagents/*.jsonl"])
        self.add_stats(t, user, stats, root / "projects")
        hist = root / "history.jsonl"
        if hist.exists():
            self.keep([hist], "claude-code", user)
        settings = load_jsonc(root / "settings.json") or {}
        self.config_file(root / "settings.json", "config:claude-code")
        u = self.flags.setdefault("claude_users", [])
        info = {"user": user, "cleanup": settings.get("cleanupPeriodDays"), "env": settings.get("env") or {},
                "hooks": hook_commands(settings), "defaultMode": ((settings.get("permissions") or {}).get("defaultMode")),
                "login": "none"}
        if isinstance(cfg, dict):
            oa = cfg.get("oauthAccount")
            if isinstance(oa, dict):
                info["login"] = "claude.ai"
                info["org"] = oa.get("organizationUuid") or ""
            elif cfg.get("primaryApiKey") or cfg.get("customApiKeyResponses"):
                info["login"] = "api-key"
            self.mcp += mcp_servers(cfg, "Claude Code", home / ".claude.json")
            for ppath, pcfg in (cfg.get("projects") or {}).items():
                self.mcp += mcp_servers(pcfg if isinstance(pcfg, dict) else {}, "Claude Code (project)", ppath)
        u.append(info)

    def codex(self, home, user):
        root = Path(os.environ.get("CODEX_HOME")) if os.environ.get("CODEX_HOME") and home == Path.home() else home / ".codex"
        if not root.exists():
            return
        t = self.tool("codex", "OpenAI Codex CLI", "openai-codex")
        self.add_stats(t, user, file_stats(root, ["sessions/**/rollout-*.jsonl", "sessions/**/rollout-*.jsonl.zst", "archived_sessions/**/rollout-*"]), root / "sessions")
        cfg = toml_sections(root / "config.toml") or {}
        self.config_file(root / "config.toml", "config:codex")
        otel = cfg.get("otel") or {}
        exporter = any(k.startswith("exporter") or k == "exporter" for k in otel) or any(s.startswith("otel.exporter") for s in cfg)
        hist = (cfg.get("history") or {}).get("persistence", "")
        auth = load_jsonc(root / "auth.json") or {}
        api_key = bool(auth.get("OPENAI_API_KEY"))
        self.flags.setdefault("codex", []).append({"user": user, "otel": exporter, "history": hist, "api_key": api_key, "chatgpt": bool(auth.get("tokens"))})
        if exporter:
            t["central_capture"] = True
        for name, sec in cfg.items():
            if name.startswith("mcp_servers.") and "." not in name.split(".", 1)[1]:
                tgt = sec.get("url") or (sec.get("command", "") + " " + sec.get("args", "")).strip()
                self.mcp.append({"name": name.split(".", 1)[1], "transport": "http" if sec.get("url") else "stdio", "target": redact(tgt)[:220], "client": "Codex", "source": str(root / "config.toml")})

    def gemini(self, home, user):
        root = home / ".gemini"
        if not root.exists():
            return
        settings = load_jsonc(root / "settings.json") or {}
        self.config_file(root / "settings.json", "config:gemini-cli")
        t = self.tool("gemini-cli", "Gemini CLI", "google-code")
        self.add_stats(t, user, file_stats(root, ["tmp/*/chats/*.json", "tmp/*/logs.json", "tmp/*/checkpoint*", "tmp/*/checkpoints/*"]), root / "tmp")
        tel = settings.get("telemetry") or {}
        self.flags.setdefault("gemini", []).append({"user": user, "telemetry": bool(tel.get("enabled")), "target": tel.get("target", ""), "otlp": bool(tel.get("otlpEndpoint")), "logPrompts": tel.get("logPrompts", True)})
        self.mcp += mcp_servers(settings, "Gemini CLI", root / "settings.json")
        ag = root / "antigravity"
        if ag.exists():
            ta = self.tool("antigravity", "Google Antigravity", "google-code")
            self.add_stats(ta, user, file_stats(ag, ["conversations/*", "brain/*/*"]), ag)
            self.mcp += mcp_servers(load_jsonc(ag / "mcp_config.json") or {}, "Antigravity", ag / "mcp_config.json")

    def copilot(self, home, user):
        code_user = roaming(home) / "Code" / "User"
        ext = list((home / ".vscode" / "extensions").glob("github.copilot*")) if (home / ".vscode" / "extensions").exists() else []
        if code_user.exists() and (ext or (code_user / "workspaceStorage").exists()):
            st = file_stats(code_user, ["workspaceStorage/*/chatSessions/*.json", "workspaceStorage/*/chatSessions/*.jsonl", "globalStorage/emptyWindowChatSessions/*.json*"])
            if ext or st["count"]:
                t = self.tool("vscode-copilot", "GitHub Copilot in VS Code", "github-copilot")
                self.add_stats(t, user, st, code_user / "workspaceStorage")
            self.mcp += mcp_servers(load_jsonc(code_user / "mcp.json") or {}, "VS Code", code_user / "mcp.json")
            self.mcp += mcp_servers(load_jsonc(code_user / "settings.json") or {}, "VS Code", code_user / "settings.json")
        cop = home / ".copilot"
        if cop.exists():
            t = self.tool("copilot-cli", "GitHub Copilot CLI", "github-copilot")
            self.add_stats(t, user, file_stats(cop, ["session-state/**/*", "history-session-state/**/*"]), cop)
            hooks = list((cop / "hooks").glob("*.json")) if (cop / "hooks").exists() else []
            self.flags.setdefault("copilot_hooks", []).append({"user": user, "user_hooks": len(hooks)})
            self.mcp += mcp_servers(load_jsonc(cop / "mcp-config.json") or {}, "Copilot CLI", cop / "mcp-config.json")

    def cursor(self, home, user):
        cu = roaming(home) / "Cursor" / "User"
        dot = home / ".cursor"
        if not cu.exists() and not dot.exists():
            return
        t = self.tool("cursor", "Cursor", "cursor")
        self.add_stats(t, user, file_stats(cu, ["globalStorage/state.vscdb", "workspaceStorage/*/state.vscdb"]), cu / "globalStorage")
        if (dot / "chats").exists():
            self.add_stats(t, user, file_stats(dot, ["chats/**/*"]), dot / "chats")
        self.mcp += mcp_servers(load_jsonc(dot / "mcp.json") or {}, "Cursor", dot / "mcp.json")
        self.flags.setdefault("cursor", []).append({"user": user, "user_hooks": (dot / "hooks.json").exists()})

    def simple(self, home, user):
        ro, lo = roaming(home), local(home)
        specs = [
            ("windsurf", "Windsurf / Devin Desktop", "devin-desktop", home / ".codeium" / "windsurf", ["cascade/**/*", "memories/*"], "mcp_config.json"),
            ("kiro", "Kiro", "amazon-q-kiro", home / ".kiro", [], "settings/mcp.json"),
            ("amazon-q", "Amazon Q Developer", "amazon-q-kiro", home / ".aws" / "amazonq", ["history/*"], "mcp.json"),
            ("claude-desktop", "Claude Desktop", "claude-enterprise", ro / "Claude", ["logs/*.log"], "claude_desktop_config.json"),
            ("ollama", "Ollama", "endpoint-ai", home / ".ollama", ["history"], None),
            ("lmstudio", "LM Studio", "endpoint-ai", home / ".lmstudio", ["conversations/*.json", "conversations/**/*.json"], None),
            ("jan", "Jan", "endpoint-ai", (ro / "Jan" / "data") if (ro / "Jan" / "data").exists() else home / "jan", ["threads/*/*.json*"], None),
        ]
        if MAC:
            specs.append(("chatgpt-desktop", "ChatGPT desktop", "chatgpt-enterprise", ro / "com.openai.chat", [], None))
        for tid, name, kb, root, pats, mcpfile in specs:
            if not root.exists():
                continue
            t = self.tool(tid, name, kb)
            self.add_stats(t, user, file_stats(root, pats) if pats else {"count": 0, "bytes": 0, "oldest": "", "newest": "", "files": []}, root)
            if mcpfile:
                self.mcp += mcp_servers(load_jsonc(root / mcpfile) or {}, name, root / mcpfile)
        if WIN:
            for pkg in (lo / "Packages").glob("OpenAI.ChatGPT-Desktop_*") if (lo / "Packages").exists() else []:
                self.add_stats(self.tool("chatgpt-desktop", "ChatGPT desktop", "chatgpt-enterprise"), user, {"count": 0, "bytes": 0, "oldest": "", "newest": "", "files": []}, pkg)
            if (lo / "Ollama").exists():
                st = file_stats(lo / "Ollama", ["server*.log"])
                self.flags.setdefault("ollama_logs", []).append({"user": user, "logs": st["count"], "oldest": st["oldest"]})
            recall = lo / "CoreAIPlatform.00" / "UKP"
            if recall.exists():
                self.flags.setdefault("recall_users", []).append(user)
        om = home / ".ollama" / "models" / "manifests"
        if om.exists():
            models = sorted({"/".join(p.relative_to(om).parts[-2:]) for p in om.glob("**/*") if p.is_file()})
            self.flags.setdefault("ollama_models", []).extend(models[:50])
        # agentic browsers
        candidates = []
        if WIN:
            candidates += [("Perplexity Comet", lo / "Perplexity" / "Comet"), ("ChatGPT Atlas", lo / "Programs" / "ChatGPT Atlas")]
        if MAC:
            candidates += [("ChatGPT Atlas", Path("/Applications/ChatGPT Atlas.app")), ("Perplexity Comet", Path("/Applications/Comet.app")), ("Dia", Path("/Applications/Dia.app"))]
        for nm, p in candidates:
            if p.exists() and nm not in self.agentic:
                self.agentic.append(nm)

    def browsers(self, home, user):
        lo, ro = local(home), roaming(home)
        if WIN:
            roots = {"Chrome": lo / "Google/Chrome/User Data", "Edge": lo / "Microsoft/Edge/User Data", "Brave": lo / "BraveSoftware/Brave-Browser/User Data"}
        elif MAC:
            roots = {"Chrome": ro / "Google/Chrome", "Edge": ro / "Microsoft Edge", "Brave": ro / "BraveSoftware/Brave-Browser"}
        else:
            roots = {"Chrome": home / ".config/google-chrome", "Edge": home / ".config/microsoft-edge", "Brave": home / ".config/BraveSoftware/Brave-Browser"}
        seen = set()
        for browser, root in roots.items():
            if not root.exists():
                continue
            for man in root.glob("*/Extensions/*/*/manifest.json"):
                try:
                    data = json.loads(man.read_text(encoding="utf-8-sig", errors="replace"))
                except (OSError, ValueError):
                    continue
                name = str(data.get("name", ""))
                if name.startswith("__MSG_"):
                    key = name[6:-2]
                    for loc in (data.get("default_locale") or "en", "en", "en_US"):
                        msgs = man.parent / "_locales" / loc / "messages.json"
                        if msgs.exists():
                            try:
                                m = json.loads(msgs.read_text(encoding="utf-8-sig", errors="replace"))
                                hit = next((v for k, v in m.items() if k.lower() == key.lower()), None)
                                if hit:
                                    name = hit.get("message", name); break
                            except (OSError, ValueError):
                                pass
                if EXT_PATTERN.search(name) and (browser, name) not in seen:
                    seen.add((browser, name))
                    self.extensions.append({"name": name[:80], "browser": browser, "id": man.parent.parent.name, "user": user})

    # ---------- host-level ----------
    def host(self):
        info = {"edr": [], "process_audit": None, "cmdline": None, "sysmon": False, "scriptblock": None, "time_source": "", "time_ok": None, "recall_policy": None, "ollama_host": os.environ.get("OLLAMA_HOST", "")}
        if WIN:
            try:
                import winreg

                def reg(hive, path, name):
                    try:
                        with winreg.OpenKey(hive, path) as k:
                            return winreg.QueryValueEx(k, name)[0]
                    except OSError:
                        return None
                info["cmdline"] = reg(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit", "ProcessCreationIncludeCmdLine_Enabled")
                info["scriptblock"] = reg(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging", "EnableScriptBlockLogging")
                info["recall_policy"] = reg(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Policies\Microsoft\Windows\WindowsAI", "DisableAIDataAnalysis")
                if not info["ollama_host"]:
                    info["ollama_host"] = reg(winreg.HKEY_CURRENT_USER, "Environment", "OLLAMA_HOST") or reg(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment", "OLLAMA_HOST") or ""
                for svc, label in EDR_WIN.items():
                    if reg(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Services\\" + svc, "ImagePath"):
                        info["edr"].append(label)
                for svc in ("Sysmon64", "Sysmon"):
                    if reg(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Services\\" + svc, "ImagePath"):
                        info["sysmon"] = True
            except ImportError:
                pass
            rc, out = run(["auditpol", "/get", "/subcategory:Process Creation"])
            if rc == 0:
                info["process_audit"] = bool(re.search(r"Process Creation\s+(Success|Success and Failure)", out))
            rc, out = run(["w32tm", "/query", "/status"])
            m = re.search(r"Source:\s*(.+)", out)
            if m:
                info["time_source"] = m.group(1).strip()
                info["time_ok"] = not re.search(r"Local CMOS Clock|Free-running", info["time_source"], re.I)
            rc, out = run(["netstat", "-ano", "-p", "TCP"])
            for line in out.splitlines():
                m = re.match(r"\s*TCP\s+(\S+):(\d+)\s+\S+\s+LISTENING", line)
                if m and int(m.group(2)) in AI_PORTS:
                    self.listeners.append({"port": int(m.group(2)), "address": m.group(1), "process": AI_PORTS[int(m.group(2))]})
        else:
            rc, out = run(["ps", "-eo", "comm"])
            procs = {Path(x.strip()).name for x in out.splitlines()}
            info["edr"] = sorted({label for p, label in EDR_PROC.items() if p in procs})
            if LIN:
                rc, out = run(["systemctl", "is-active", "auditd"])
                info["process_audit"] = out.strip() == "active"
                rules = " ".join(p.read_text(errors="replace") for p in Path("/etc/audit/rules.d").glob("*.rules")) if Path("/etc/audit/rules.d").exists() else ""
                info["cmdline"] = 1 if "execve" in rules else 0
                rc, out = run(["timedatectl", "show", "-p", "NTPSynchronized", "--value"])
                info["time_ok"] = out.strip() == "yes" if rc == 0 else None
                info["time_source"] = "systemd-timesyncd/chrony" if info["time_ok"] else ""
                rc, out = run(["ss", "-ltnH"])
                for line in out.splitlines():
                    parts = line.split()
                    if len(parts) >= 4:
                        addr, _, port = parts[3].rpartition(":")
                        if port.isdigit() and int(port) in AI_PORTS:
                            self.listeners.append({"port": int(port), "address": addr.strip("[]"), "process": AI_PORTS[int(port)]})
            if MAC:
                rc, out = run(["lsof", "-nP", "-iTCP", "-sTCP:LISTEN"])
                for line in out.splitlines()[1:]:
                    m = re.search(r"\s(\S+):(\d+)\s+\(LISTEN\)", line)
                    if m and int(m.group(2)) in AI_PORTS:
                        self.listeners.append({"port": int(m.group(2)), "address": m.group(1).replace("*", "0.0.0.0"), "process": AI_PORTS[int(m.group(2))]})
                rc, out = run(["systemsetup", "-getusingnetworktime"])
                if "On" in out:
                    info["time_ok"], info["time_source"] = True, "network time"
        self.flags["host"] = info
        return info

    # ---------- decisions ----------
    def decide(self):
        b, f = self.b, self.flags
        host = f.get("host", {})
        managed, msrc = claude_managed()
        for s in msrc:
            self.config_file(s, "config:claude-code-managed") if Path(s).is_file() else None
        cc = self.tools.get("claude-code")
        if cc:
            menv = managed.get("env") or {}
            cc["managed"] = bool(msrc)
            users = f.get("claude_users", [])
            # CCD-01 managed settings
            b.observe("CCD-01", "met" if msrc else "gap", ("Managed settings found: " + ", ".join(msrc)) if msrc else "No managed-settings.json, managed-settings.d or policy key on this endpoint.", "claude-code")
            # CCD-02 retention
            mcl = managed.get("cleanupPeriodDays")
            eff = mcl if isinstance(mcl, int) else min([u["cleanup"] for u in users if isinstance(u.get("cleanup"), int)] or [30])
            cc["retention_days"] = eff
            st = "met" if isinstance(mcl, int) and mcl >= 90 else "gap"
            b.observe("CCD-02", st, f"Effective cleanupPeriodDays {eff} ({'managed' if isinstance(mcl, int) else 'user or default'}); {cc['transcripts']} transcripts, oldest {cc['oldest'][:10] or 'n/a'}.", "claude-code",
                      retention={"source": "ccd-local", "days": eff, "oldest": cc["oldest"][:10]})
            # CCD-04 telemetry locked
            tel_m = str(menv.get("CLAUDE_CODE_ENABLE_TELEMETRY", "")) == "1" and menv.get("OTEL_EXPORTER_OTLP_ENDPOINT") and menv.get("OTEL_LOGS_EXPORTER")
            tel_u = any(str((u.get("env") or {}).get("CLAUDE_CODE_ENABLE_TELEMETRY", "")) == "1" for u in users)
            b.observe("CCD-04", "met" if tel_m else "partial" if tel_u else "gap",
                      "Telemetry exporter set in managed settings." if tel_m else "Telemetry only in user settings; developers can change it." if tel_u else "No OpenTelemetry export configured.", "claude-code")
            content = str(menv.get("OTEL_LOG_USER_PROMPTS", "")) == "1" and str(menv.get("OTEL_LOG_TOOL_DETAILS", "")) == "1"
            # CCD-05 export hooks
            mh = [c for c in hook_commands(managed) if EXPORT_HINT.search(c[1])]
            uh = [c for u in users for c in u.get("hooks", []) if EXPORT_HINT.search(c[1])]
            locked = bool(managed.get("allowManagedHooksOnly"))
            st = "met" if mh and locked else "partial" if (mh or uh) else "gap"
            b.observe("CCD-05", st, ("Managed export hook(s): " + "; ".join(e for e, _ in mh) + (" with allowManagedHooksOnly" if locked else " (user hooks still allowed)")) if mh else ("User-level export hook only." if uh else "No hook copies transcripts off the endpoint."), "claude-code")
            cc["central_capture"] = bool(mh) or (tel_m and content)
            # CCD-06 suppression
            sup = os.environ.get("CLAUDE_CODE_SKIP_PROMPT_HISTORY") or any((u.get("env") or {}).get("CLAUDE_CODE_SKIP_PROMPT_HISTORY") for u in users) or menv.get("CLAUDE_CODE_SKIP_PROMPT_HISTORY")
            b.observe("CCD-06", "gap" if sup else "met", "CLAUDE_CODE_SKIP_PROMPT_HISTORY is set." if sup else "No transcript or history suppression found.", "claude-code")
            # CCD-07 bypass
            dis = (managed.get("permissions") or {}).get("disableBypassPermissionsMode") == "disable"
            byp = [u["user"] for u in users if u.get("defaultMode") == "bypassPermissions"]
            b.observe("CCD-07", "met" if dis else "gap", "Bypass mode disabled by managed policy." if dis else ("Bypass mode not disabled" + (f"; default mode bypassPermissions for {', '.join(byp)}" if byp else "") + "."), "claude-code")
            # CCD-08 / CLE-06 login method
            third = [k for k in ("CLAUDE_CODE_USE_BEDROCK", "CLAUDE_CODE_USE_VERTEX", "CLAUDE_CODE_USE_FOUNDRY") if os.environ.get(k) or menv.get(k) or any((u.get("env") or {}).get(k) for u in users)]
            if third:
                b.observe("CCD-08", "info", "Third-party routing configured: " + ", ".join(third) + ". Confirm that cloud's invocation logging.", "claude-code")
            logins = [u["login"] for u in users]
            if self.expect_org:
                ok = all(u["login"] == "claude.ai" and u.get("org") == self.expect_org for u in users if u["login"] != "none")
                b.observe("CLE-06", "met" if ok else "gap", "All Claude Code users signed in to the expected organisation." if ok else "Some Claude Code users are not signed in to the expected Enterprise organisation.", "claude-enterprise")
            else:
                b.observe("CLE-06", "info", "Claude Code login methods: " + ", ".join(sorted(set(logins))) + ". Pass --expect-claude-org to verify the organisation.", "claude-enterprise")
        else:
            for cid in ("CCD-01", "CCD-02", "CCD-04", "CCD-05", "CCD-06", "CCD-07"):
                b.observe(cid, "na", "Claude Code not found on this endpoint.", "claude-code")
        # Copilot
        vs = self.tools.get("vscode-copilot")
        cli = self.tools.get("copilot-cli")
        if vs or cli:
            n = (vs or {}).get("transcripts", 0) + (cli or {}).get("transcripts", 0)
            b.observe("GHC-04", "gap", f"{n} Copilot chat or CLI session files held only on this endpoint; no central capture detected.", "github-copilot")
        # Cursor hooks
        cur = self.tools.get("cursor")
        if cur:
            ent = any(Path(p).exists() for p in managed_paths()["cursor_hooks"])
            usr = any(x.get("user_hooks") for x in f.get("cursor", []))
            cur["managed"] = ent
            cur["central_capture"] = ent
            b.observe("CUR-02", "met" if ent else "partial" if usr else "gap", "Enterprise hooks.json deployed." if ent else "User-level hooks only." if usr else "No Cursor hooks configured; chat history stays in the local database.", "cursor")
        # Codex
        cx = f.get("codex", [])
        if cx:
            api = [x["user"] for x in cx if x["api_key"]]
            b.observe("CDX-01", "gap" if api else "met", ("API-key authentication for: " + ", ".join(api)) if api else "Codex signed in with ChatGPT.", "openai-codex")
            otel = all(x["otel"] for x in cx)
            b.observe("CDX-04", "met" if otel else "gap", "OpenTelemetry exporter configured in config.toml." if otel else "No [otel] exporter in Codex config.", "openai-codex")
            if any(x["history"] == "none" for x in cx):
                b.observe("EPT-05", "info", "Codex history persistence is disabled for at least one user.", "endpoint-ai")
        # Gemini CLI
        gm = f.get("gemini", [])
        if gm:
            sysp = next((p for p in managed_paths()["gemini"] if p.exists()), None)
            sysset = load_jsonc(sysp) if sysp else None
            stel = ((sysset or {}).get("telemetry") or {})
            st = "met" if stel.get("enabled") and (stel.get("otlpEndpoint") or stel.get("target") == "gcp") else "partial" if any(x["telemetry"] for x in gm) else "gap"
            self.tools["gemini-cli"]["managed"] = bool(sysp)
            self.tools["gemini-cli"]["central_capture"] = st == "met"
            b.observe("GCA-03", st, "System settings export telemetry." if st == "met" else "Telemetry set only in user settings." if st == "partial" else "Gemini CLI telemetry not configured.", "google-code")
        # Endpoint foundations
        tools_with_content = [t for t in self.tools.values() if t["transcripts"]]
        b.observe("EPT-01", "met", f"{len(self.tools)} AI tools, {len(self.mcp)} MCP server entries, {len(self.extensions)} AI browser extensions, {len(self.listeners)} local model listeners.", "endpoint-ai")
        edr = host.get("edr") or []
        if WIN:
            st = "met" if (host.get("process_audit") and host.get("cmdline") == 1) or host.get("sysmon") else "partial" if edr else "gap"
            det = f"Process Creation auditing {'on' if host.get('process_audit') else 'off or unreadable'}; command line {'on' if host.get('cmdline') == 1 else 'off'}; Sysmon {'present' if host.get('sysmon') else 'absent'}; EDR: {', '.join(edr) or 'none detected'}."
        else:
            st = "met" if host.get("process_audit") and host.get("cmdline") else "partial" if edr else "gap"
            det = f"auditd {'active' if host.get('process_audit') else 'inactive'}; execve rules {'present' if host.get('cmdline') else 'absent'}; EDR: {', '.join(edr) or 'none detected'}."
        b.observe("EPT-02", st, det, "endpoint-ai", data={"edr": edr})
        if WIN:
            b.observe("EPT-03", "met" if host.get("scriptblock") == 1 else "gap", "Script block logging " + ("enforced by policy." if host.get("scriptblock") == 1 else "not enforced."), "endpoint-ai")
        else:
            b.observe("EPT-03", "na", "Not a Windows endpoint.", "endpoint-ai")
        if tools_with_content:
            central = [t for t in tools_with_content if t["central_capture"]]
            st = "met" if len(central) == len(tools_with_content) else "partial" if central else "gap"
            b.observe("EPT-05", st, f"{len(central)} of {len(tools_with_content)} tools with local transcripts have central capture.", "endpoint-ai",
                      retention={"source": "ept-agents", "days": min([t["retention_days"] for t in tools_with_content if t["retention_days"]] or [30]), "oldest": min(t["oldest"] for t in tools_with_content)[:10]})
        exposed = [l for l in self.listeners if l["address"] not in ("127.0.0.1", "::1", "[::1]", "localhost")]
        oh = str(host.get("ollama_host") or "")
        if oh.startswith("0.0.0.0") or oh.startswith("[::]"):
            exposed.append({"port": 11434, "address": oh, "process": "Ollama (OLLAMA_HOST)"})
        b.observe("EPT-06", "gap" if exposed else ("met" if self.listeners or "ollama" in self.tools else "na"),
                  ("Model runtime reachable beyond localhost: " + ", ".join(f"{l['process']} {l['address']}:{l['port']}" for l in exposed)) if exposed else "Local model runtimes bound to localhost only." if self.listeners else "No local model runtime listening.", "endpoint-ai")
        if host.get("time_ok") is None:
            b.observe("EPT-07", "info", "Time synchronisation state could not be read.", "endpoint-ai")
        else:
            b.observe("EPT-07", "met" if host.get("time_ok") else "gap", "Time source: " + (host.get("time_source") or "unsynchronised"), "endpoint-ai")
        b.observe("EPT-08", "met", f"{len(self.extensions)} AI-related browser extensions; agentic browsers: {', '.join(self.agentic) or 'none'}.", "endpoint-ai")
        if WIN:
            ru = f.get("recall_users", [])
            pol = host.get("recall_policy")
            st = "met" if pol == 1 else "partial" if ru else "info"
            b.observe("EPT-10", st, ("Recall disabled by policy." if pol == 1 else f"Recall snapshot store present for: {', '.join(ru)}; no disabling policy." if ru else "No Recall store found; no policy set."), "endpoint-ai")
        if self.mcp:
            b.observe("AGT-05", "info", f"{len(self.mcp)} MCP server definitions found across {len({m['client'] for m in self.mcp})} clients.", "agents-mcp")

    def run(self):
        for home in user_homes(self.all_users):
            try:
                self.scan_user(home)
            except PermissionError:
                self.b.note(f"Permission denied scanning {home}; run elevated with --all-users for full coverage.")
        self.host()
        self.decide()
        inv = self.b.inventory
        inv["tools"] = [dict(t, paths=t["paths"][:6]) for t in self.tools.values()]
        inv["mcp_servers"] = self.mcp[:300]
        inv["extensions"] = self.extensions
        inv["agentic_browsers"] = self.agentic
        inv["listeners"] = self.listeners
        inv["local_models"] = self.flags.get("ollama_models", [])
        inv["telemetry"] = {k: v for k, v in (self.flags.get("host") or {}).items() if k != "ollama_host"}
        if self.preserve:
            man = self.preserve / "manifest.csv"
            with open(man, "w", encoding="utf-8") as fh:
                fh.write("sha256,bytes,mtime,role,source\n")
                for fl in self.b.doc["files"]:
                    fh.write(f"{fl['sha256']},{fl['bytes']},{fl['mtime']},{fl['role']},\"{fl['path']}\"\n")
            self.b.note(f"Preserved {len(self.b.doc['files'])} files ({self.preserved} bytes) to {self.preserve}; manifest.csv lists SHA-256 values.")
        return self.b
