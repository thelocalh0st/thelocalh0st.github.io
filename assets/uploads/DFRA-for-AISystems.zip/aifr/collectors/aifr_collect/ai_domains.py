"""AI service destinations for shadow-AI analysis of proxy and DNS logs.

Each entry: domain (suffix match), service name, category, account tier and,
where it exists, the knowledge-base platform the service belongs to. Tier is
what the destination usually indicates: "enterprise" endpoints serve managed
tenants, "consumer" endpoints serve personal accounts, "mixed" serve both,
"api" serves programmatic use.
"""
import re

SERVICES = [
    # OpenAI
    ("chatgpt.com", "ChatGPT", "assistant", "mixed", "chatgpt-enterprise"),
    ("chat.openai.com", "ChatGPT", "assistant", "mixed", "chatgpt-enterprise"),
    ("oaiusercontent.com", "ChatGPT file uploads", "assistant", "mixed", "chatgpt-enterprise"),
    ("api.openai.com", "OpenAI API", "api", "api", "openai-api"),
    ("sora.com", "OpenAI Sora", "media", "consumer", ""),
    # Anthropic
    ("claude.ai", "Claude", "assistant", "mixed", "claude-enterprise"),
    ("claude.com", "Claude", "assistant", "mixed", "claude-enterprise"),
    ("api.anthropic.com", "Anthropic API", "api", "api", "anthropic-api"),
    # Google
    ("gemini.google.com", "Gemini app", "assistant", "mixed", "gemini-workspace"),
    ("bard.google.com", "Gemini app", "assistant", "mixed", "gemini-workspace"),
    ("notebooklm.google.com", "NotebookLM", "assistant", "mixed", "gemini-workspace"),
    ("aistudio.google.com", "Google AI Studio", "api", "consumer", ""),
    ("generativelanguage.googleapis.com", "Gemini API", "api", "api", ""),
    ("cloudaicompanion.googleapis.com", "Gemini Code Assist", "coding", "enterprise", "google-code"),
    ("antigravity.google", "Google Antigravity", "coding", "mixed", "google-code"),
    # Microsoft
    ("copilot.cloud.microsoft", "Microsoft 365 Copilot Chat", "assistant", "enterprise", "m365-copilot"),
    ("m365copilot.com", "Microsoft 365 Copilot", "assistant", "enterprise", "m365-copilot"),
    ("copilot.microsoft.com", "Microsoft Copilot (consumer)", "assistant", "consumer", ""),
    ("copilotstudio.microsoft.com", "Copilot Studio", "assistant", "enterprise", "copilot-studio"),
    # GitHub and coding tools
    ("githubcopilot.com", "GitHub Copilot", "coding", "mixed", "github-copilot"),
    ("copilot-proxy.githubusercontent.com", "GitHub Copilot", "coding", "mixed", "github-copilot"),
    ("cursor.sh", "Cursor", "coding", "mixed", "cursor"),
    ("cursor.com", "Cursor", "coding", "mixed", "cursor"),
    ("cursorapi.com", "Cursor", "coding", "mixed", "cursor"),
    ("codeium.com", "Windsurf / Devin Desktop", "coding", "mixed", "devin-desktop"),
    ("windsurf.com", "Windsurf / Devin Desktop", "coding", "mixed", "devin-desktop"),
    ("devin.ai", "Devin", "coding", "mixed", "devin-desktop"),
    ("kiro.dev", "Kiro", "coding", "mixed", "amazon-q-kiro"),
    ("tabnine.com", "Tabnine", "coding", "mixed", ""),
    ("sourcegraph.com", "Sourcegraph Cody / Amp", "coding", "mixed", ""),
    ("ampcode.com", "Amp", "coding", "mixed", ""),
    ("replit.com", "Replit Agent", "coding", "consumer", ""),
    ("bolt.new", "Bolt", "coding", "consumer", ""),
    ("lovable.dev", "Lovable", "coding", "consumer", ""),
    ("v0.dev", "v0", "coding", "consumer", ""),
    ("v0.app", "v0", "coding", "consumer", ""),
    ("phind.com", "Phind", "coding", "consumer", ""),
    # Other assistants and search
    ("perplexity.ai", "Perplexity", "search", "mixed", ""),
    ("meta.ai", "Meta AI", "assistant", "consumer", ""),
    ("grok.com", "Grok", "assistant", "consumer", ""),
    ("x.ai", "xAI", "api", "api", ""),
    ("deepseek.com", "DeepSeek", "assistant", "consumer", ""),
    ("chat.mistral.ai", "Le Chat (Mistral)", "assistant", "mixed", ""),
    ("api.mistral.ai", "Mistral API", "api", "api", ""),
    ("poe.com", "Poe", "assistant", "consumer", ""),
    ("character.ai", "Character.AI", "assistant", "consumer", ""),
    ("pi.ai", "Pi", "assistant", "consumer", ""),
    ("you.com", "You.com", "search", "consumer", ""),
    ("kimi.com", "Kimi", "assistant", "consumer", ""),
    ("moonshot.cn", "Kimi (Moonshot)", "assistant", "consumer", ""),
    ("chat.qwen.ai", "Qwen Chat", "assistant", "consumer", ""),
    ("tongyi.aliyun.com", "Tongyi Qianwen", "assistant", "consumer", ""),
    ("yiyan.baidu.com", "ERNIE Bot", "assistant", "consumer", ""),
    ("doubao.com", "Doubao", "assistant", "consumer", ""),
    ("manus.im", "Manus", "agent", "consumer", ""),
    ("glean.com", "Glean", "assistant", "enterprise", "glean"),
    # Model APIs and aggregators
    ("openrouter.ai", "OpenRouter", "api", "api", ""),
    ("api.groq.com", "Groq API", "api", "api", ""),
    ("api.together.xyz", "Together AI", "api", "api", ""),
    ("together.ai", "Together AI", "api", "api", ""),
    ("api.cohere.com", "Cohere API", "api", "api", ""),
    ("api.cohere.ai", "Cohere API", "api", "api", ""),
    ("fireworks.ai", "Fireworks AI", "api", "api", ""),
    ("replicate.com", "Replicate", "api", "api", ""),
    ("api.perplexity.ai", "Perplexity API", "api", "api", ""),
    # Model hubs and local runtimes
    ("huggingface.co", "Hugging Face", "model hub", "mixed", "model-supply-chain"),
    ("hf.co", "Hugging Face", "model hub", "mixed", "model-supply-chain"),
    ("ollama.com", "Ollama registry", "model hub", "consumer", "endpoint-ai"),
    ("registry.ollama.ai", "Ollama registry", "model hub", "consumer", "endpoint-ai"),
    ("lmstudio.ai", "LM Studio", "model hub", "consumer", "endpoint-ai"),
    # Writing, meetings, documents, media
    ("grammarly.com", "Grammarly", "writing", "mixed", ""),
    ("grammarly.io", "Grammarly", "writing", "mixed", ""),
    ("quillbot.com", "QuillBot", "writing", "consumer", ""),
    ("jasper.ai", "Jasper", "writing", "mixed", ""),
    ("copy.ai", "Copy.ai", "writing", "consumer", ""),
    ("writesonic.com", "Writesonic", "writing", "consumer", ""),
    ("otter.ai", "Otter.ai", "meeting notes", "mixed", ""),
    ("fireflies.ai", "Fireflies.ai", "meeting notes", "mixed", ""),
    ("read.ai", "Read AI", "meeting notes", "mixed", ""),
    ("fathom.video", "Fathom", "meeting notes", "mixed", ""),
    ("tldv.io", "tl;dv", "meeting notes", "mixed", ""),
    ("gamma.app", "Gamma", "documents", "consumer", ""),
    ("chatpdf.com", "ChatPDF", "documents", "consumer", ""),
    ("humata.ai", "Humata", "documents", "consumer", ""),
    ("monica.im", "Monica", "browser assistant", "consumer", ""),
    ("getmerlin.in", "Merlin", "browser assistant", "consumer", ""),
    ("sider.ai", "Sider", "browser assistant", "consumer", ""),
    ("harpa.ai", "HARPA AI", "browser assistant", "consumer", ""),
    ("maxai.me", "MaxAI", "browser assistant", "consumer", ""),
    ("midjourney.com", "Midjourney", "media", "consumer", ""),
    ("leonardo.ai", "Leonardo", "media", "consumer", ""),
    ("ideogram.ai", "Ideogram", "media", "consumer", ""),
    ("runwayml.com", "Runway", "media", "consumer", ""),
    ("elevenlabs.io", "ElevenLabs", "media", "consumer", ""),
    ("suno.com", "Suno", "media", "consumer", ""),
]

# Cloud AI endpoints identified by pattern rather than a fixed domain.
PATTERNS = [
    (re.compile(r"(^|\.)bedrock(-runtime|-agent-runtime|-mantle)?[.-][a-z0-9-]+\.amazonaws\.com$"), "Amazon Bedrock", "api", "enterprise", "aws-bedrock"),
    (re.compile(r"(^|\.)q\.[a-z0-9-]+\.amazonaws\.com$|codewhisperer\.[a-z0-9-]+\.amazonaws\.com$"), "Amazon Q Developer", "coding", "enterprise", "amazon-q-kiro"),
    (re.compile(r"\.openai\.azure\.com$|\.cognitiveservices\.azure\.com$|\.services\.ai\.azure\.com$"), "Azure OpenAI / Foundry", "api", "enterprise", "azure-openai"),
    (re.compile(r"(^|-)aiplatform\.googleapis\.com$"), "Vertex AI", "api", "enterprise", "gcp-vertex"),
    (re.compile(r"\.cloud\.databricks\.com$|\.azuredatabricks\.net$"), "Databricks", "api", "enterprise", "databricks"),
]


def match(host):
    """Return (service, category, tier, kb, matched_domain) or None for a host name."""
    if not host:
        return None
    h = host.strip().strip(".").lower()
    if ":" in h and not h.startswith("["):
        h = h.split(":", 1)[0]
    for dom, name, cat, tier, kb in SERVICES:
        if h == dom or h.endswith("." + dom):
            return name, cat, tier, kb, dom
    for rx, name, cat, tier, kb in PATTERNS:
        if rx.search(h):
            return name, cat, tier, kb, h
    return None
