"""Shadow-AI analyser for proxy, firewall and DNS log exports.

Reads CSV/TSV exports with a header row (most SWG, SSE, firewall and SIEM
exports), Squid access logs, BIND query logs, Windows DNS debug logs and Zeek
dns/http logs (TSV or JSON lines). Matches destinations against the AI service
catalogue and reports services, account tiers, user and device counts, upload
volume and the time span the logs cover.

Privacy by design: user and device identifiers are counted, never listed. With
--pseudonymise-top the ten heaviest users are listed as salted hashes that the
client can resolve through its own approved process.
"""
import csv
import gzip
import hashlib
import io
import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path

from . import ai_domains
from .bundle import Bundle

COLS = {
    "time": ["timestamp", "time", "datetime", "date_time", "eventtime", "event_time", "ts", "_time", "receivetime", "date", "@timestamp", "generated"],
    "user": ["user", "username", "user_name", "login", "src_user", "suser", "userprincipalname", "user_id", "cs-username", "duser", "identity", "useridentity"],
    "host": ["src", "src_ip", "source", "client", "clientip", "client_ip", "c-ip", "source_ip", "device", "hostname", "src_host", "srcip", "computer", "deviceip", "id.orig_h"],
    "dest": ["url", "uri", "request", "domain", "query", "qname", "dest_host", "dst_host", "hostname_dest", "host", "sni", "servername", "server_name", "cs-host", "fqdn", "destinationhost", "dhost", "request_url", "requested_url", "dest", "destination", "site"],
    "bytes_out": ["bytes_out", "bytesout", "sent", "sent_bytes", "bytes_sent", "request_size", "requestsize", "cs-bytes", "out_bytes", "client_bytes", "reqsize", "upload"],
}
TIME_FORMATS = ["%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S", "%Y/%m/%d %H:%M:%S", "%d/%b/%Y:%H:%M:%S", "%m/%d/%Y %H:%M:%S", "%d-%m-%Y %H:%M:%S", "%a %b %d %H:%M:%S %Y", "%d-%b-%Y %H:%M:%S", "%Y-%m-%d"]
BIND = re.compile(r"^(\S+ \S+).*?client (?:@\S+ )?([0-9a-fA-F:.]+)#\d+ \(([^)]+)\): query:")
WINDNS = re.compile(r"^(\S+ \S+(?: [AP]M)?) .*?PACKET.*?\s(?:Rcv|Snd)\s+([0-9a-fA-F:.]+)\s.*?\s([A-Z]+)\s+(\([0-9]+\)\S+)\s*$")
SQUID = re.compile(r"^(\d{9,10}\.\d+)\s+\d+\s+(\S+)\s+\S+/\d+\s+(\d+)\s+(\S+)\s+(\S+)\s+(\S+)")
URLHOST = re.compile(r"^(?:[a-z]+://)?([^/:?#\s]+)", re.I)


def parse_time(v):
    if v is None:
        return None
    s = str(v).strip().strip('"')
    if not s:
        return None
    if re.fullmatch(r"\d{9,13}(\.\d+)?", s):
        x = float(s)
        if x > 1e12:
            x /= 1000.0
        return datetime.fromtimestamp(x, timezone.utc)
    s2 = s.replace("Z", "+00:00")
    try:
        d = datetime.fromisoformat(s2)
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
    except ValueError:
        pass
    s3 = re.sub(r"(\.\d+)?\s*([+-]\d{2}:?\d{2}|UTC|GMT)?$", "", s)
    for fmt in TIME_FORMATS:
        try:
            return datetime.strptime(s3, fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    return None


def host_of(v):
    if not v:
        return ""
    s = str(v).strip()
    if s.upper().startswith("CONNECT "):
        s = s.split(" ", 1)[1]
    m = URLHOST.match(s)
    return m.group(1).lower() if m else ""


def windns_name(enc):
    return ".".join(re.findall(r"\(\d+\)([^()]+)", enc)).lower()


def open_text(path):
    p = Path(path)
    raw = p.open("rb")
    if p.suffix == ".gz":
        raw = gzip.open(raw)
    return io.TextIOWrapper(raw, encoding="utf-8", errors="replace")


def pick(header, names):
    low = [h.strip().lower() for h in header]
    for n in names:
        if n in low:
            return low.index(n)
    return None


class Analyzer:
    def __init__(self, sanctioned=(), salt=None):
        self.sanctioned = {s.strip().lower() for s in sanctioned if s.strip()}
        self.salt = salt or os.urandom(8).hex()
        self.apps = {}
        self.first = self.last = None
        self.rows = 0
        self.matched = 0
        self.unparsed = 0
        self.sources = []
        self.user_load = {}

    def _span(self, t):
        if t is None:
            return
        if self.first is None or t < self.first:
            self.first = t
        if self.last is None or t > self.last:
            self.last = t

    def record(self, t, user, host, dest, bytes_out):
        self.rows += 1
        self._span(t)
        hit = ai_domains.match(host_of(dest))
        if not hit:
            return
        self.matched += 1
        name, cat, tier, kb, dom = hit
        a = self.apps.get(name)
        if not a:
            a = self.apps[name] = {"app": name, "category": cat, "tier": tier, "kb": kb, "domains": set(), "events": 0, "users": set(), "hosts": set(), "bytes_out": 0, "first": None, "last": None}
        a["events"] += 1
        a["domains"].add(dom)
        if user:
            a["users"].add(user)
            self.user_load[user] = self.user_load.get(user, 0) + 1
        if host:
            a["hosts"].add(host)
        try:
            a["bytes_out"] += int(float(bytes_out or 0))
        except ValueError:
            pass
        if t:
            a["first"] = t if a["first"] is None or t < a["first"] else a["first"]
            a["last"] = t if a["last"] is None or t > a["last"] else a["last"]

    def feed(self, path):
        self.sources.append(Path(path).name)
        with open_text(path) as fh:
            head = fh.read(4096)
            fh.seek(0)
            first = head.lstrip().splitlines()[0] if head.strip() else ""
            if first.startswith("#separator") or first.startswith("#fields"):
                return self._zeek_tsv(fh)
            if first.startswith("{"):
                return self._jsonl(fh)
            if SQUID.match(first):
                return self._squid(fh)
            if BIND.search(head) or WINDNS.search(head) or "PACKET" in head:
                return self._dns_text(fh)
            return self._csv(fh, head)

    def _csv(self, fh, head):
        try:
            dialect = csv.Sniffer().sniff(head.splitlines()[0] if head else ",", delimiters=",;\t|")
        except csv.Error:
            dialect = csv.excel
        reader = csv.reader(fh, dialect)
        header = next(reader, [])
        idx = {k: pick(header, v) for k, v in COLS.items()}
        if idx["dest"] is None:
            raise ValueError(f"no destination column found in header: {header[:12]}")
        for row in reader:
            g = lambda k: row[idx[k]] if idx[k] is not None and idx[k] < len(row) else ""
            self.record(parse_time(g("time")), g("user"), g("host"), g("dest"), g("bytes_out"))

    def _jsonl(self, fh):
        for line in fh:
            line = line.strip()
            if not line.startswith("{"):
                continue
            try:
                o = json.loads(line)
            except ValueError:
                self.unparsed += 1
                continue
            low = {k.lower(): v for k, v in o.items() if not isinstance(v, (dict, list))}
            g = lambda k: next((low[n] for n in COLS[k] if n in low and low[n] not in (None, "")), "")
            self.record(parse_time(g("time")), g("user"), g("host"), g("dest"), g("bytes_out"))

    def _zeek_tsv(self, fh):
        fields = []
        for line in fh:
            if line.startswith("#fields"):
                fields = line.rstrip("\n").split("\t")[1:]
                continue
            if line.startswith("#") or not fields:
                continue
            row = dict(zip(fields, line.rstrip("\n").split("\t")))
            dest = row.get("query") or row.get("host") or row.get("server_name") or ""
            self.record(parse_time(row.get("ts")), "", row.get("id.orig_h", ""), dest, row.get("request_body_len", 0))

    def _squid(self, fh):
        for line in fh:
            m = SQUID.match(line)
            if not m:
                self.unparsed += 1
                continue
            ts, client, size, method, url, user = m.groups()
            self.record(parse_time(ts), "" if user == "-" else user, client, url, size if method in ("POST", "PUT", "CONNECT") else 0)

    def _dns_text(self, fh):
        for line in fh:
            m = BIND.search(line)
            if m:
                self.record(parse_time(m.group(1)), "", m.group(2), m.group(3), 0)
                continue
            m = WINDNS.search(line)
            if m:
                self.record(parse_time(m.group(1)), "", m.group(2), windns_name(m.group(4)), 0)
                continue
            self.unparsed += 1

    def pseudonym(self, u):
        return "u-" + hashlib.sha256((self.salt + u).encode()).hexdigest()[:10]

    def result(self, top_users=False):
        apps = []
        for a in sorted(self.apps.values(), key=lambda x: -x["events"]):
            sanctioned = bool(a["kb"] and a["kb"] in self.sanctioned) or a["app"].lower() in self.sanctioned
            if a["tier"] == "consumer" and a["kb"] in self.sanctioned:
                sanctioned = False
            apps.append({"app": a["app"], "category": a["category"], "tier": a["tier"], "kb": a["kb"], "sanctioned": sanctioned,
                         "domains": sorted(a["domains"])[:6], "events": a["events"], "users": len(a["users"]) or None, "hosts": len(a["hosts"]) or None,
                         "bytes_out": a["bytes_out"], "first": a["first"].isoformat() if a["first"] else "", "last": a["last"].isoformat() if a["last"] else ""})
        span = (self.last - self.first).days + 1 if self.first and self.last else 0
        out = {"source": ", ".join(self.sources), "rows": self.rows, "events": self.matched, "unparsed": self.unparsed,
               "first": self.first.isoformat() if self.first else "", "last": self.last.isoformat() if self.last else "", "span_days": span, "apps": apps}
        if top_users:
            out["top_users"] = [{"user": self.pseudonym(u), "events": n} for u, n in sorted(self.user_load.items(), key=lambda x: -x[1])[:10]]
        return out


def analyse(paths, sanctioned=(), target_days=365, top_users=False):
    an = Analyzer(sanctioned)
    errors = []
    for p in paths:
        try:
            an.feed(p)
        except (OSError, ValueError) as e:
            errors.append(f"{p}: {e}")
    res = an.result(top_users)
    b = Bundle("aifr-shadow", "network", "network-logs", details={"files": [Path(p).name for p in paths], "sanctioned": sorted(an.sanctioned)})
    for e in errors:
        b.note("Skipped " + e)
    b.inventory["shadow"] = res
    span = res["span_days"]
    unsanct = [a for a in res["apps"] if not a["sanctioned"]]
    if res["rows"]:
        st = "met" if span >= target_days else "partial" if span >= 90 else "gap"
        b.observe("SHD-02", st, f"Logs supplied cover {span} days ({res['first'][:10]} to {res['last'][:10]}), {res['rows']:,} records. Target {target_days} days.", "shadow-ai",
                  retention={"source": "shd-proxy", "days": span, "oldest": res["first"][:10]})
        b.observe("SHD-06", "met", f"{len(res['apps'])} AI services matched in {res['events']:,} requests; {len(unsanct)} not sanctioned.", "shadow-ai",
                  data={"unsanctioned": [a["app"] for a in unsanct][:20]})
        consumer = [a for a in unsanct if a["tier"] in ("consumer", "mixed") and a["category"] in ("assistant", "coding", "search", "writing", "documents", "meeting notes", "browser assistant", "agent")]
        if consumer:
            b.observe("SHD-05", "gap", "Consumer or mixed-tier AI services reached: " + ", ".join(a["app"] for a in consumer[:8]) + ("…" if len(consumer) > 8 else "") + ".", "shadow-ai")
    else:
        b.observe("SHD-06", "error", "No log records could be parsed from the files supplied.", "shadow-ai")
    return b
