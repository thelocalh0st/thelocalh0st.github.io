"""Synthetic bundles for training and for the sample engagement.

Generates a deterministic fleet of endpoint bundles, a shadow-AI bundle and an
AWS bundle for the fictional client used in the sample engagement. Names,
hosts and figures are invented.
"""
import random
from datetime import datetime, timedelta, timezone

from .bundle import Bundle

NOW = datetime(2026, 10, 21, 9, 0, tzinfo=timezone.utc)
MCP_POOL = [
    ("github", "stdio", "npx -y @modelcontextprotocol/server-github", True),
    ("filesystem", "stdio", "npx -y @modelcontextprotocol/server-filesystem C:/src", True),
    ("postgres-reporting", "stdio", "npx -y @modelcontextprotocol/server-postgres postgresql://report-db/***", False),
    ("jira", "http", "https://mcp.atlassian.com/v1/sse", True),
    ("slack", "stdio", "npx -y slack-mcp-server", False),
    ("browser-use", "stdio", "uvx browser-use-mcp", False),
    ("internal-kb", "http", "http://10.20.4.17:8811/mcp", False),
    ("vendor-analytics", "http", "https://mcp.example-analytics.io/sse", False),
    ("playwright", "stdio", "npx @playwright/mcp@latest", False),
    ("aws-docs", "stdio", "uvx awslabs.aws-documentation-mcp-server", True),
]
EXT_POOL = [("Grammarly: AI Writing and Grammar Checker", "Chrome"), ("ChatGPT for Chrome", "Chrome"), ("Monica: ChatGPT AI Assistant", "Edge"),
            ("Sider: Chat with all AI", "Chrome"), ("Claude", "Chrome"), ("Perplexity: AI Companion", "Chrome"), ("MaxAI: AI Agent", "Edge")]


def iso(d):
    return d.replace(microsecond=0).isoformat().replace("+00:00", "Z")


def endpoint(rng, host, kind):
    b = Bundle("aifr-endpoint", "endpoint", host, details={"all_users": True, "os_family": "Windows" if not host.endswith("M") else "Darwin"})
    b.doc["target"]["os"] = "Windows-11-10.0.26100" if not host.endswith("M") else "macOS-15.6-arm64"
    b.doc["run"]["started"] = b.doc["run"]["finished"] = iso(NOW - timedelta(minutes=rng.randint(0, 600)))
    b.doc["run"]["operator"] = "SYSTEM@" + host
    tools, mcp, ext = [], [], []
    dev = kind == "dev"
    managed = dev and rng.random() < 0.6
    if dev and rng.random() < 0.65:
        n = rng.randint(15, 420)
        cleanup = 30 if rng.random() < 0.94 else 90
        tools.append({"id": "claude-code", "name": "Claude Code", "platform": "claude-code", "users": ["dev"], "transcripts": n, "bytes": n * rng.randint(90_000, 900_000),
                      "oldest": iso(NOW - timedelta(days=cleanup - rng.randint(0, 3))), "newest": iso(NOW - timedelta(hours=rng.randint(1, 60))), "retention_days": cleanup, "managed": managed, "central_capture": False})
        b.observe("CCD-01", "met" if managed else "gap", "Managed settings found." if managed else "No managed settings on this endpoint.", "claude-code")
        b.observe("CCD-02", "met" if cleanup >= 90 else "gap", f"Effective cleanupPeriodDays {cleanup}.", "claude-code", retention={"source": "ccd-local", "days": cleanup})
        b.observe("CCD-04", "gap", "No OpenTelemetry export configured.", "claude-code")
        b.observe("CCD-05", "gap", "No hook copies transcripts off the endpoint.", "claude-code")
        b.observe("CCD-06", "met", "No transcript or history suppression found.", "claude-code")
        byp = rng.random() < 0.08
        b.observe("CCD-07", "gap", "Bypass mode not disabled" + ("; default mode bypassPermissions." if byp else "."), "claude-code")
    if dev and rng.random() < 0.8:
        n = rng.randint(8, 260)
        tools.append({"id": "vscode-copilot", "name": "GitHub Copilot in VS Code", "platform": "github-copilot", "users": ["dev"], "transcripts": n, "bytes": n * rng.randint(20_000, 300_000),
                      "oldest": iso(NOW - timedelta(days=rng.randint(120, 420))), "newest": iso(NOW - timedelta(hours=rng.randint(1, 30))), "retention_days": None, "managed": False, "central_capture": False})
        b.observe("GHC-04", "gap", f"{n} Copilot chat session files held only on this endpoint.", "github-copilot")
    if dev and rng.random() < 0.22:
        tools.append({"id": "cursor", "name": "Cursor", "platform": "cursor", "users": ["dev"], "transcripts": 1, "bytes": rng.randint(60, 2400) * 1_048_576,
                      "oldest": iso(NOW - timedelta(days=rng.randint(40, 300))), "newest": iso(NOW - timedelta(hours=3)), "retention_days": None, "managed": False, "central_capture": False})
        b.observe("CUR-02", "gap", "No Cursor hooks configured; chat history stays in the local database.", "cursor")
    if dev and rng.random() < 0.15:
        n = rng.randint(5, 90)
        tools.append({"id": "codex", "name": "OpenAI Codex CLI", "platform": "openai-codex", "users": ["dev"], "transcripts": n, "bytes": n * 400_000,
                      "oldest": iso(NOW - timedelta(days=rng.randint(30, 200))), "newest": iso(NOW - timedelta(days=1)), "retention_days": None, "managed": False, "central_capture": False})
        api = rng.random() < 0.5
        b.observe("CDX-01", "gap" if api else "met", "API-key authentication." if api else "Codex signed in with ChatGPT.", "openai-codex")
        b.observe("CDX-04", "gap", "No [otel] exporter in Codex config.", "openai-codex")
    if dev and rng.random() < 0.1:
        tools.append({"id": "gemini-cli", "name": "Gemini CLI", "platform": "google-code", "users": ["dev"], "transcripts": rng.randint(3, 40), "bytes": 3_000_000,
                      "oldest": iso(NOW - timedelta(days=rng.randint(20, 90))), "newest": iso(NOW - timedelta(days=2)), "retention_days": None, "managed": False, "central_capture": False})
        b.observe("GCA-03", "gap", "Gemini CLI telemetry not configured.", "google-code")
    listeners = []
    if dev and (rng.random() < 0.09 or host in ("AFS-DEV-0117", "AFS-DEV-0342")):
        tools.append({"id": "ollama", "name": "Ollama", "platform": "endpoint-ai", "users": ["dev"], "transcripts": 1, "bytes": 40_000,
                      "oldest": iso(NOW - timedelta(days=rng.randint(30, 200))), "newest": iso(NOW - timedelta(days=4)), "retention_days": None, "managed": False, "central_capture": False})
        listeners.append({"port": 11434, "address": "0.0.0.0" if host in ("AFS-DEV-0117", "AFS-DEV-0342") else "127.0.0.1", "process": "Ollama"})
    if not dev and rng.random() < 0.35:
        tools.append({"id": "chatgpt-desktop", "name": "ChatGPT desktop", "platform": "chatgpt-enterprise", "users": ["user"], "transcripts": 0, "bytes": 0, "oldest": "", "newest": "", "retention_days": None, "managed": False, "central_capture": False})
    if rng.random() < 0.18:
        tools.append({"id": "claude-desktop", "name": "Claude Desktop", "platform": "claude-enterprise", "users": ["user"], "transcripts": rng.randint(2, 12), "bytes": 900_000,
                      "oldest": iso(NOW - timedelta(days=rng.randint(10, 60))), "newest": iso(NOW - timedelta(days=1)), "retention_days": None, "managed": False, "central_capture": False})
    if dev:
        for name, tr, tgt, appr in rng.sample(MCP_POOL, rng.randint(1, 5)):
            mcp.append({"name": name, "transport": tr, "target": tgt, "client": rng.choice(["Claude Code", "VS Code", "Cursor", "Claude Desktop"]), "source": "user config"})
    for name, br in rng.sample(EXT_POOL, rng.randint(0, 3)):
        ext.append({"name": name, "browser": br, "id": "x" * 32, "user": "user"})
    agentic = ["ChatGPT Atlas"] if host.endswith("M") and rng.random() < 0.5 else []
    edr = ["Microsoft Defender for Endpoint"] if rng.random() < 0.92 else []
    with_content = [t for t in tools if t["transcripts"]]
    b.observe("EPT-01", "met", f"{len(tools)} AI tools, {len(mcp)} MCP server entries, {len(ext)} AI browser extensions.", "endpoint-ai")
    b.observe("EPT-02", "partial" if edr else "gap", f"Process Creation auditing on; command line off; Sysmon absent; EDR: {', '.join(edr) or 'none detected'}.", "endpoint-ai")
    b.observe("EPT-03", "met", "Script block logging enforced by policy.", "endpoint-ai")
    if with_content:
        b.observe("EPT-05", "gap", f"0 of {len(with_content)} tools with local transcripts have central capture.", "endpoint-ai",
                  retention={"source": "ept-agents", "days": min([t["retention_days"] for t in with_content if t["retention_days"]] or [30])})
    exposed = [l for l in listeners if l["address"] != "127.0.0.1"]
    b.observe("EPT-06", "gap" if exposed else ("met" if listeners else "na"), "Ollama listening on 0.0.0.0:11434." if exposed else "Local model runtimes bound to localhost only." if listeners else "No local model runtime listening.", "endpoint-ai")
    b.observe("EPT-07", "met", "Time source: dc01.asterion.example", "endpoint-ai")
    b.observe("EPT-08", "met", f"{len(ext)} AI-related browser extensions; agentic browsers: {', '.join(agentic) or 'none'}.", "endpoint-ai")
    b.observe("EPT-10", "met", "Recall disabled by policy.", "endpoint-ai")
    b.inventory.update({"tools": tools, "mcp_servers": mcp, "extensions": ext, "agentic_browsers": agentic, "listeners": listeners, "local_models": ["llama3.1/8b", "qwen2.5-coder/14b"] if listeners else [],
                        "telemetry": {"edr": edr, "process_audit": True, "cmdline": 0, "sysmon": False, "scriptblock": 1, "time_ok": True}})
    return b


def shadow():
    b = Bundle("aifr-shadow", "network", "network-logs", details={"files": ["swg-export-2026-08-05_2026-10-03.csv.gz"], "sanctioned": ["m365-copilot", "github-copilot", "claude-enterprise", "chatgpt-enterprise", "aws-bedrock", "azure-openai"]})
    b.doc["run"]["started"] = b.doc["run"]["finished"] = iso(NOW - timedelta(days=12))
    apps = [
        ("ChatGPT", "assistant", "mixed", "chatgpt-enterprise", False, 18420, 312, 290, 2_640_000_000, ["chatgpt.com", "oaiusercontent.com"]),
        ("Microsoft 365 Copilot Chat", "assistant", "enterprise", "m365-copilot", True, 15310, 1904, 1850, 410_000_000, ["copilot.cloud.microsoft"]),
        ("GitHub Copilot", "coding", "mixed", "github-copilot", True, 22140, 141, 139, 1_200_000_000, ["githubcopilot.com"]),
        ("Grammarly", "writing", "mixed", "", False, 9840, 421, 400, 380_000_000, ["grammarly.com", "grammarly.io"]),
        ("Claude", "assistant", "mixed", "claude-enterprise", True, 6210, 640, 610, 920_000_000, ["claude.ai"]),
        ("OpenAI API", "api", "api", "openai-api", False, 5630, None, 12, 610_000_000, ["api.openai.com"]),
        ("Cursor", "coding", "mixed", "cursor", False, 3410, 31, 31, 540_000_000, ["cursor.sh", "cursor.com"]),
        ("Gemini app", "assistant", "mixed", "gemini-workspace", False, 2980, 141, 136, 95_000_000, ["gemini.google.com"]),
        ("Perplexity", "search", "mixed", "", False, 1530, 77, 75, 21_000_000, ["perplexity.ai"]),
        ("Hugging Face", "model hub", "mixed", "model-supply-chain", False, 1110, 25, 24, 12_000_000, ["huggingface.co"]),
        ("DeepSeek", "assistant", "consumer", "", False, 640, 22, 21, 48_000_000, ["deepseek.com"]),
        ("Otter.ai", "meeting notes", "mixed", "", False, 382, 14, 14, 1_900_000_000, ["otter.ai"]),
        ("Ollama registry", "model hub", "consumer", "endpoint-ai", False, 214, 6, 6, 0, ["registry.ollama.ai"]),
        ("Amazon Bedrock", "api", "enterprise", "aws-bedrock", True, 48200, None, 9, 3_100_000_000, ["bedrock-runtime.ap-south-1.amazonaws.com"]),
    ]
    out = []
    for name, cat, tier, kb, sanc, ev, users, hosts, bytes_out, doms in apps:
        out.append({"app": name, "category": cat, "tier": tier, "kb": kb, "sanctioned": sanc, "domains": doms, "events": ev, "users": users, "hosts": hosts, "bytes_out": bytes_out,
                    "first": "2026-08-05T00:03:11+00:00", "last": "2026-10-03T23:58:40+00:00"})
    res = {"source": "swg-export-2026-08-05_2026-10-03.csv.gz", "rows": 18_742_118, "events": sum(a[5] for a in apps), "unparsed": 0,
           "first": "2026-08-05T00:00:02+00:00", "last": "2026-10-03T23:59:59+00:00", "span_days": 60, "apps": out}
    b.inventory["shadow"] = res
    b.observe("SHD-02", "gap", "Logs supplied cover 60 days (2026-08-05 to 2026-10-03). Target 365 days.", "shadow-ai", retention={"source": "shd-proxy", "days": 90, "oldest": "2026-08-05"})
    b.observe("SHD-06", "met", f"{len(out)} AI services matched; {sum(1 for a in out if not a['sanctioned'])} not sanctioned.", "shadow-ai")
    b.observe("SHD-05", "gap", "Consumer or mixed-tier AI services reached: ChatGPT (personal accounts), Grammarly, Cursor, Gemini app, Perplexity, DeepSeek, Otter.ai.", "shadow-ai")
    return b


def aws():
    b = Bundle("aifr-aws", "cloud", "aws-111122223333", details={"regions": ["ap-south-1", "eu-west-1"]})
    b.doc["run"]["started"] = b.doc["run"]["finished"] = iso(NOW - timedelta(days=9))
    b.observe("BDR-01", "partial", "Invocation logging on in: ap-south-1; off in: eu-west-1.", "aws-bedrock")
    b.observe("BDR-02", "gap", "S3 delivery for large or binary payloads in 0 of 1 logging Regions.", "aws-bedrock")
    b.observe("BDR-03", "info", "Invocation log group retention: 400 days.", "aws-bedrock", retention={"source": "bdr-inv", "days": 400})
    b.observe("BDR-05", "met", "Logging multi-Region trail(s) with validation: org-trail.", "aws-bedrock")
    b.observe("BDR-06", "gap", "No trail selects AWS::Bedrock:: data events.", "aws-bedrock")
    b.observe("BDR-08", "partial", "2 guardrails defined across the Regions checked.", "aws-bedrock")
    b.inventory["cloud"] = {"account": "111122223333", "regions_logging": ["ap-south-1"], "regions_not_logging": ["eu-west-1"], "trails": ["org-trail"]}
    return b


def generate(out_dir, hosts=24, seed=14):
    rng = random.Random(seed)
    written = []
    names = [f"AFS-DEV-{n:04d}" for n in rng.sample(range(100, 999), int(hosts * 0.7))] + [f"AFS-BIZ-{n:04d}" for n in rng.sample(range(100, 999), hosts - int(hosts * 0.7))]
    names[0], names[1] = "AFS-DEV-0117", "AFS-DEV-0342"
    names[-2] = names[-2] + "M"
    for h in names:
        b = endpoint(rng, h, "dev" if "DEV" in h else "biz")
        written.append(b.write(out_dir))
    for b in (shadow(), aws()):
        written.append(b.write(out_dir))
    return written
