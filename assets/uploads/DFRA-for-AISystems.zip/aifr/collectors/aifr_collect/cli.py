"""Command line for the AIFR collectors.

    python -m aifr_collect endpoint [--all-users] [--preserve DIR] [--out DIR]
    python -m aifr_collect shadow --logs FILE [FILE ...] [--sanctioned IDS] [--out DIR]
    python -m aifr_collect selfhosted [--config FILE ...] [--probe URL ...] [--out DIR]
    python -m aifr_collect aws --regions R [R ...] [--profile P] [--out DIR]
    python -m aifr_collect azure [--subscription ID] [--out DIR]
    python -m aifr_collect gcp --project ID [--out DIR]
    python -m aifr_collect github (--enterprise SLUG | --org ORG) [--out DIR]
    python -m aifr_collect anthropic [--out DIR]
    python -m aifr_collect openai [--out DIR]
    python -m aifr_collect verify BUNDLE [BUNDLE ...]
    python -m aifr_collect demo [--out DIR]

All collectors are read-only. Each writes <bundle>.json and <bundle>.json.sha256.
"""
import argparse
import hashlib
import json
import sys
from pathlib import Path

from . import __version__
from .bundle import summarise


def _out(p):
    return Path(p or "./evidence")


def cmd_endpoint(a):
    from .endpoint import EndpointScan
    if a.preserve:
        print("Preserve mode copies AI transcripts and databases, which contain sensitive content. Use only under an authorised investigation.", file=sys.stderr)
    b = EndpointScan(all_users=a.all_users, preserve=a.preserve, expect_claude_org=a.expect_claude_org, max_preserve_mb=a.max_preserve_mb).run()
    path, digest = b.write(_out(a.out))
    summarise(path, digest, b)
    inv = b.inventory
    for t in inv.get("tools", []):
        print(f"  {t['name']:<28} transcripts {t['transcripts']:>6}  retention {t['retention_days'] if t['retention_days'] is not None else '-':>4}  managed {'yes' if t['managed'] else 'no':<3}  central {'yes' if t['central_capture'] else 'no'}")


def cmd_shadow(a):
    from .shadow import analyse
    b = analyse(a.logs, sanctioned=(a.sanctioned or "").split(","), target_days=a.target_days, top_users=a.pseudonymise_top)
    path, digest = b.write(_out(a.out))
    summarise(path, digest, b)
    for app in b.inventory["shadow"]["apps"][:15]:
        print(f"  {app['app']:<30} {app['tier']:<10} {'sanctioned' if app['sanctioned'] else 'UNSANCTIONED':<13} requests {app['events']:>8}  users {app['users'] or '-'}")


def cmd_selfhosted(a):
    from .selfhosted import collect
    b = collect(configs=a.config or [], probes=a.probe or [], docker=not a.no_docker)
    path, digest = b.write(_out(a.out))
    summarise(path, digest, b)


def cmd_aws(a):
    from .cloud import aws
    b = aws(a.regions, a.profile)
    path, digest = b.write(_out(a.out))
    summarise(path, digest, b)


def cmd_azure(a):
    from .cloud import azure
    b = azure(a.subscription)
    path, digest = b.write(_out(a.out))
    summarise(path, digest, b)


def cmd_gcp(a):
    from .cloud import gcp
    b = gcp(a.project)
    path, digest = b.write(_out(a.out))
    summarise(path, digest, b)


def cmd_github(a):
    from .saas import github
    if not (a.enterprise or a.org):
        raise SystemExit("Give --enterprise SLUG or --org ORG")
    b = github(a.enterprise, a.org, a.api)
    path, digest = b.write(_out(a.out))
    summarise(path, digest, b)


def cmd_anthropic(a):
    from .saas import anthropic
    b = anthropic()
    path, digest = b.write(_out(a.out))
    summarise(path, digest, b)


def cmd_openai(a):
    from .saas import openai
    b = openai()
    path, digest = b.write(_out(a.out))
    summarise(path, digest, b)


def cmd_verify(a):
    bad = 0
    for f in a.bundles:
        p = Path(f)
        data = p.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        side = p.with_name(p.name + ".sha256")
        expected = side.read_text().split()[0].lower() if side.exists() else None
        try:
            doc = json.loads(data.decode("utf-8-sig"))
            ok_schema = str(doc.get("schema", "")).startswith("aifr.bundle/")
        except ValueError:
            ok_schema = False
        state = "NO SIDECAR" if expected is None else ("OK" if expected == digest else "MISMATCH")
        if state == "MISMATCH" or not ok_schema:
            bad += 1
        print(f"{state:<10} {'schema ok' if ok_schema else 'NOT A BUNDLE':<12} {digest}  {p.name}")
    return 1 if bad else 0


def cmd_demo(a):
    from .demo import generate
    out = _out(a.out)
    files = generate(out, hosts=a.hosts)
    print(f"Wrote {len(files)} synthetic bundles to {out} (fictional client, for training).")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="aifr_collect", description="Read-only evidence collectors for AI forensic readiness assessments.")
    ap.add_argument("--version", action="version", version=__version__)
    sp = ap.add_subparsers(dest="cmd", required=True)

    def add(name, fn, help_):
        p = sp.add_parser(name, help=help_)
        p.add_argument("--out", help="output directory (default ./evidence)")
        p.set_defaults(fn=fn)
        return p

    p = add("endpoint", cmd_endpoint, "AI tools, transcripts, MCP servers and telemetry on this host")
    p.add_argument("--all-users", action="store_true", help="scan every user profile (run elevated)")
    p.add_argument("--preserve", metavar="DIR", help="copy artefacts to DIR with SHA-256 manifest (incident triage only)")
    p.add_argument("--max-preserve-mb", type=int, default=2048)
    p.add_argument("--expect-claude-org", metavar="UUID", help="Claude Enterprise organisation UUID users should be signed in to")
    p = add("shadow", cmd_shadow, "AI destinations in proxy, firewall or DNS logs")
    p.add_argument("--logs", nargs="+", required=True)
    p.add_argument("--sanctioned", help="comma-separated platform IDs or service names that are approved")
    p.add_argument("--target-days", type=int, default=365)
    p.add_argument("--pseudonymise-top", action="store_true", help="list the ten heaviest users as salted hashes")
    p = add("selfhosted", cmd_selfhosted, "gateways, inference servers and chat front-ends")
    p.add_argument("--config", nargs="*", help="LiteLLM / Kong / Open WebUI config, .env or compose files")
    p.add_argument("--probe", nargs="*", help="base URLs of model endpoints to test for unauthenticated access")
    p.add_argument("--no-docker", action="store_true")
    p = add("aws", cmd_aws, "Amazon Bedrock and CloudTrail via the AWS CLI")
    p.add_argument("--regions", nargs="+", required=True)
    p.add_argument("--profile")
    p = add("azure", cmd_azure, "Azure OpenAI, APIM, Defender and Entra ID via the Azure CLI")
    p.add_argument("--subscription")
    p = add("gcp", cmd_gcp, "Vertex AI audit configuration and log buckets via gcloud")
    p.add_argument("--project", required=True)
    p = add("github", cmd_github, "GitHub Copilot audit log, streams and usage records")
    p.add_argument("--enterprise")
    p.add_argument("--org")
    p.add_argument("--api", default="https://api.github.com", help="API base, for example https://api.SUBDOMAIN.ghe.com")
    add("anthropic", cmd_anthropic, "Claude Compliance API reachability and local-session capture")
    add("openai", cmd_openai, "OpenAI API organisation audit logging and key ownership")
    p = sp.add_parser("verify", help="recompute and compare bundle hashes")
    p.add_argument("bundles", nargs="+")
    p.set_defaults(fn=cmd_verify)
    p = add("demo", cmd_demo, "write synthetic bundles for training")
    p.add_argument("--hosts", type=int, default=24)
    a = ap.parse_args(argv)
    return a.fn(a) or 0
