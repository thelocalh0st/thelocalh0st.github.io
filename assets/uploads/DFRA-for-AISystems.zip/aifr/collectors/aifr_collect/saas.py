"""SaaS AI control-plane collectors: GitHub Copilot, Anthropic (Claude) and OpenAI.

Uses documented read-only REST endpoints with credentials supplied through
environment variables. Nothing is written to the services. Response bodies
are summarised; no conversation content is stored in the bundle.
"""
import json
import os
import urllib.error
import urllib.request
from datetime import datetime, timezone

from .bundle import Bundle


def get(url, headers, timeout=20):
    req = urllib.request.Request(url, headers=dict({"User-Agent": "aifr-collect/1.0"}, **headers))
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode("utf-8", "replace")
            return r.status, json.loads(raw) if raw.strip() else {}
    except urllib.error.HTTPError as e:
        try:
            body = json.loads(e.read().decode("utf-8", "replace"))
        except (ValueError, OSError):
            body = {}
        return e.code, body
    except (urllib.error.URLError, OSError, ValueError) as e:
        return 0, {"error": str(e)}


def _days_since(iso_or_ms):
    try:
        if isinstance(iso_or_ms, (int, float)):
            t = datetime.fromtimestamp(iso_or_ms / 1000.0, timezone.utc)
        else:
            t = datetime.fromisoformat(str(iso_or_ms).replace("Z", "+00:00"))
        return (datetime.now(timezone.utc) - t).days
    except (ValueError, OverflowError, OSError):
        return None


# ------------------------------------------------------------------ GitHub
def github(enterprise=None, org=None, api="https://api.github.com"):
    token = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
    scope = f"enterprises/{enterprise}" if enterprise else f"orgs/{org}"
    b = Bundle("aifr-github", "saas", scope.replace("/", "-"))
    if not token:
        b.observe("GHC-02", "error", "Set GITHUB_TOKEN (classic PAT with read:audit_log, read:enterprise).", "github-copilot")
        return b
    h = {"Authorization": "Bearer " + token, "Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"}
    if enterprise:
        code, body = get(f"{api}/enterprises/{enterprise}/audit-log/streams", h)
        if code == 200:
            enabled = [s for s in (body if isinstance(body, list) else []) if s.get("enabled")]
            b.observe("GHC-01", "met" if enabled else "gap", f"{len(enabled)} enabled audit log stream(s)." if enabled else "No enabled audit log stream; history beyond 180 days is lost.", "github-copilot",
                      data={"streams": [s.get("stream_type") for s in enabled]})
        else:
            b.note(f"Audit log streams not readable (HTTP {code}).")
    code, body = get(f"{api}/{scope}/audit-log?phrase=action:copilot&per_page=100", h)
    if code == 200:
        ev = body if isinstance(body, list) else []
        b.observe("GHC-02", "met" if ev else "partial", f"{len(ev)} recent Copilot audit events returned.", "github-copilot")
        code2, old = get(f"{api}/{scope}/audit-log?phrase=action:copilot&per_page=1&order=asc", h)
        if code2 == 200 and old:
            d = _days_since(old[0].get("@timestamp") or old[0].get("created_at"))
            if d is not None:
                b.observe("GHC-02", "info", f"Oldest Copilot event available through the API is {d} days old.", "github-copilot", retention={"source": "ghc-audit", "days": d})
    else:
        b.observe("GHC-02", "error", f"Audit log query failed (HTTP {code}).", "github-copilot")
    code, body = get(f"{api}/{scope}/audit-log?phrase=action:mcp_registry&per_page=5", h)
    if code == 200:
        b.observe("GHC-06", "info", f"{len(body) if isinstance(body, list) else 0} recent MCP registry events.", "github-copilot")
    if enterprise:
        code, body = get(f"{api}/enterprises/{enterprise}/copilot/usage-records", h)
        if code == 200:
            b.observe("GHC-03", "met", "Copilot usage-records API enabled and returning data (48-hour window).", "github-copilot")
        elif code in (403, 404):
            b.observe("GHC-03", "gap", f"Usage-records API not available (HTTP {code}): not enabled, not an EMU enterprise, or insufficient rights.", "github-copilot")
    return b


# ------------------------------------------------------------------ Anthropic
def anthropic(api="https://api.anthropic.com"):
    key = os.environ.get("ANTHROPIC_COMPLIANCE_KEY") or os.environ.get("ANTHROPIC_ADMIN_KEY")
    b = Bundle("aifr-anthropic", "saas", "anthropic")
    if not key:
        b.observe("CLE-02", "error", "Set ANTHROPIC_COMPLIANCE_KEY (read scopes) or ANTHROPIC_ADMIN_KEY.", "claude-enterprise")
        return b
    h = {"x-api-key": key, "anthropic-version": "2023-06-01"}
    admin_only = key.startswith("sk-ant-admin")
    code, body = get(f"{api}/v1/compliance/activities?limit=1", h)
    if code == 200:
        data = body.get("data", [])
        newest = data[0].get("created_at", "") if data else ""
        b.observe("CLE-02" if not admin_only else "ANT-01", "met", f"Activity Feed reachable; newest event {newest or 'none'}.", "claude-enterprise" if not admin_only else "anthropic-api")
    else:
        b.observe("CLE-02" if not admin_only else "ANT-01", "gap", f"Activity Feed not reachable (HTTP {code}): {json.dumps(body)[:160]}", "claude-enterprise" if not admin_only else "anthropic-api")
    if not admin_only:
        code, body = get(f"{api}/v1/compliance/apps/sessions/local?limit=5", h)
        if code == 200:
            n = len(body.get("data", []))
            b.observe("CLE-03", "met" if n else "partial", f"Local session endpoint returned {n} recent sessions (Claude Code, Cowork and add-ins).", "claude-enterprise")
        elif code == 404:
            b.observe("CLE-03", "gap", "Local sessions are not available to this organisation.", "claude-enterprise")
        else:
            b.observe("CLE-03", "error", f"Local session endpoint returned HTTP {code}.", "claude-enterprise")
    return b


# ------------------------------------------------------------------ OpenAI
def openai(api="https://api.openai.com"):
    key = os.environ.get("OPENAI_ADMIN_KEY")
    b = Bundle("aifr-openai", "saas", "openai-org")
    if not key:
        b.observe("OAI-01", "error", "Set OPENAI_ADMIN_KEY (organisation owner admin key).", "openai-api")
        return b
    h = {"Authorization": "Bearer " + key}
    code, body = get(f"{api}/v1/organization/audit_logs?limit=1", h)
    if code == 200:
        b.observe("OAI-01", "met", f"Audit logs enabled; {len(body.get('data', []))} event returned.", "openai-api")
    else:
        b.observe("OAI-01", "gap", f"Audit logs not available (HTTP {code}): {str(body.get('error', body))[:160]}", "openai-api")
    code, projects = get(f"{api}/v1/organization/projects?limit=100", h)
    user_keys = svc_keys = 0
    for p in projects.get("data", []) if code == 200 else []:
        c2, keys = get(f"{api}/v1/organization/projects/{p['id']}/api_keys?limit=100", h)
        for k in keys.get("data", []) if c2 == 200 else []:
            owner = (k.get("owner") or {}).get("type")
            if owner == "service_account":
                svc_keys += 1
            else:
                user_keys += 1
    if code == 200:
        b.observe("OAI-02", "met" if user_keys == 0 and svc_keys else "partial" if svc_keys else "gap",
                  f"{svc_keys} service-account keys and {user_keys} user-owned keys across {len(projects.get('data', []))} projects.", "openai-api")
    return b
