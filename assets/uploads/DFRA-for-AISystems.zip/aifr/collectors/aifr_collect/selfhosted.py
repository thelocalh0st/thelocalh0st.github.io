"""Self-hosted AI collector: gateways, inference servers and chat front-ends.

Reads gateway and front-end configuration (LiteLLM, Kong, Open WebUI env and
compose files), inspects running inference containers and processes, and
probes model endpoints for unauthenticated access. Probes are plain GET
requests without credentials; nothing is changed on any host.
"""
import json
import platform
import re
import shutil
import subprocess
import urllib.error
import urllib.request
from pathlib import Path

from .bundle import Bundle

AI_IMAGE = re.compile(r"vllm|ollama|open-webui|litellm|text-generation-inference|\btgi\b|llama\.?cpp|localai|nvcr\.io/nim|tritonserver|langfuse|librechat|anythingllm|dify|lmdeploy|sglang", re.I)
PROBES = [("/api/tags", "Ollama model list"), ("/v1/models", "OpenAI-compatible model list"), ("/api/config", "Open WebUI configuration"), ("/health", "health")]


def sh(cmd, timeout=20):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, errors="replace")
        return r.returncode, r.stdout or "", r.stderr or ""
    except (OSError, subprocess.SubprocessError) as e:
        return -1, "", str(e)


def yaml_flags(text):
    """Line-level YAML reader for the handful of keys that matter. Values are taken verbatim."""
    flags = {}
    for line in text.splitlines():
        s = line.split("#", 1)[0].rstrip()
        m = re.match(r"^\s*([A-Za-z0-9_\-]+)\s*:\s*(.*)$", s)
        if m:
            flags.setdefault(m.group(1), m.group(2).strip().strip('"').strip("'"))
    return flags


def env_flags(text):
    flags = {}
    for line in text.splitlines():
        m = re.match(r"^\s*(?:-\s*)?([A-Z][A-Z0-9_]+)\s*[=:]\s*\"?([^\"#]*)", line)
        if m:
            flags[m.group(1)] = m.group(2).strip()
    return flags


def truthy(v):
    return str(v).strip().lower() in ("true", "1", "yes", "on")


def probe(url):
    req = urllib.request.Request(url, headers={"User-Agent": "aifr-collect/1.0 (read-only assessment probe)"})
    try:
        with urllib.request.urlopen(req, timeout=6) as r:
            return r.status
    except urllib.error.HTTPError as e:
        return e.code
    except (urllib.error.URLError, OSError, ValueError):
        return 0


def collect(configs=(), probes=(), docker=True):
    b = Bundle("aifr-selfhosted", "server", platform.node() or "host", details={"configs": [Path(c).name for c in configs], "probes": list(probes)})
    inv = b.inventory.setdefault("cloud", {})
    # ---- configuration files ----
    lite, kong, webui = [], [], []
    for c in configs:
        p = Path(c)
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except OSError as e:
            b.note(f"Could not read {p}: {e}")
            continue
        b.add_file(p, "config", None, p.stat().st_size)
        y = yaml_flags(text)
        e = env_flags(text)
        if "model_list" in text or "litellm_settings" in text or "general_settings" in text:
            lite.append((p, y, text))
        if re.search(r"\bai-proxy(-advanced)?\b", text):
            kong.append((p, text))
        if any(k in e for k in ("AUDIT_LOG_LEVEL", "WEBUI_AUTH", "ENABLE_SIGNUP", "ENABLE_OAUTH_SIGNUP", "OAUTH_CLIENT_ID")) or "open-webui" in text:
            webui.append((p, e))
    for p, y, text in lite:
        store = truthy(y.get("store_prompts_in_spend_logs", "false"))
        disabled = truthy(y.get("disable_spend_logs", "false"))
        redacted = truthy(y.get("turn_off_message_logging", "false"))
        ret = y.get("maximum_spend_logs_retention_period", "")
        b.observe("GW-03", "met" if store and not disabled else "gap",
                  f"{p.name}: store_prompts_in_spend_logs {'true' if store else 'false/unset'}" + ("; spend logs disabled" if disabled else "") + ("; turn_off_message_logging true (callbacks receive no message content)" if redacted else "") + ".", "ai-gateway")
        has_master = "master_key" in y
        has_db = "database_url" in y
        b.observe("GW-02", "partial" if has_master and has_db else "gap",
                  f"{p.name}: master key {'set' if has_master else 'not set'}, database {'configured' if has_db else 'not configured'}. Virtual keys per user or app need the database; confirm clients do not share the master key.", "ai-gateway")
        days = None
        m = re.match(r"^(\d+)\s*([dhms])$", ret)
        if m:
            n, u = int(m.group(1)), m.group(2)
            days = n if u == "d" else max(1, n // 24) if u == "h" else 1
        cb = re.findall(r"(?:success_callback|callbacks)\s*:\s*\[([^\]]*)\]", text)
        b.observe("GW-04", "partial" if (days or cb) else "gap",
                  f"{p.name}: spend-log retention {ret or 'not set (kept until deleted)'}; callbacks {', '.join(c.strip() for c in cb) or 'none'}. Confirm export to the archive.", "ai-gateway",
                  retention={"source": "gw-requests", "days": days} if days else None)
    for p, text in kong:
        lp = re.search(r"log_payloads\s*:\s*(true|false)", text)
        b.observe("GW-03", "met" if lp and lp.group(1) == "true" else "gap", f"{p.name}: Kong AI plugin log_payloads {lp.group(1) if lp else 'not set (default off)'}.", "ai-gateway")
    for p, e in webui:
        auth = e.get("WEBUI_AUTH", "true")
        signup = e.get("ENABLE_SIGNUP", "")
        oauth = any(k.startswith("OAUTH_") or k == "ENABLE_OAUTH_SIGNUP" for k in e)
        if not truthy(auth) and auth != "":
            b.observe("CHT-01", "gap", f"{p.name}: WEBUI_AUTH=false: no authentication, every chat is anonymous.", "chat-frontend")
        else:
            b.observe("CHT-01", "met" if oauth and not truthy(signup) else "partial", f"{p.name}: OAuth {'configured' if oauth else 'not configured'}; local sign-up {'enabled' if truthy(signup) else 'disabled or unset'}.", "chat-frontend")
        lvl = e.get("AUDIT_LOG_LEVEL", "NONE").upper()
        b.observe("CHT-03", "met" if lvl in ("METADATA", "REQUEST", "REQUEST_RESPONSE") else "gap", f"{p.name}: AUDIT_LOG_LEVEL={lvl}.", "chat-frontend")
    # ---- probes ----
    open_eps, closed = [], []
    for base in probes:
        base = base.rstrip("/")
        for path, label in PROBES:
            code = probe(base + path)
            if code == 0:
                continue
            (open_eps if code == 200 and path != "/health" else closed).append(f"{base}{path} → {code}")
            if code == 200 and path != "/health":
                break
    if probes:
        if open_eps:
            b.observe("INF-01", "gap", "Answered without credentials: " + "; ".join(open_eps[:6]), "selfhosted-inference")
        elif closed:
            b.observe("INF-01", "met", "Endpoints required credentials or refused: " + "; ".join(closed[:6]), "selfhosted-inference")
        else:
            b.observe("INF-01", "info", "No probed endpoint answered.", "selfhosted-inference")
    # ---- containers ----
    if docker and shutil.which("docker"):
        rc, out, err = sh(["docker", "ps", "--format", "{{.ID}} {{.Image}} {{.Names}}"])
        rows = [l.split(" ", 2) for l in out.splitlines() if l.strip()]
        ai = [r for r in rows if len(r) >= 2 and AI_IMAGE.search(r[1])]
        drivers = []
        for cid, image, *name in ai:
            rc, js, _ = sh(["docker", "inspect", cid])
            try:
                d = json.loads(js)[0]
            except (ValueError, IndexError):
                continue
            lc = (d.get("HostConfig") or {}).get("LogConfig") or {}
            args = " ".join((d.get("Config") or {}).get("Cmd") or []) + " " + " ".join(d.get("Args") or [])
            env = {e.split("=", 1)[0]: e.split("=", 1)[1] if "=" in e else "" for e in (d.get("Config") or {}).get("Env") or []}
            drivers.append({"container": (name[0] if name else cid), "image": image, "log_driver": lc.get("Type", ""), "log_opts": lc.get("Config") or {}})
            if "vllm" in image.lower() or "vllm" in args:
                key = "--api-key" in args or "VLLM_API_KEY" in env
                logreq = "--enable-log-requests" in args
                b.observe("INF-05", "info", f"{image}: --api-key {'set' if key else 'not set'}; request logging {'on' if logreq else 'off'}.", "selfhosted-inference")
            if "open-webui" in image.lower():
                lvl = env.get("AUDIT_LOG_LEVEL", "NONE").upper()
                b.observe("CHT-03", "met" if lvl != "NONE" else "gap", f"Container {name[0] if name else cid}: AUDIT_LOG_LEVEL={lvl}.", "chat-frontend")
        if drivers:
            local_only = [d for d in drivers if d["log_driver"] in ("json-file", "local", "")]
            b.observe("INF-02", "gap" if local_only else "met",
                      (f"{len(local_only)} of {len(drivers)} AI containers log only to local rotating files: " + ", ".join(f"{d['container']} ({d['log_driver'] or 'default'} {d['log_opts'].get('max-size', '')})" for d in local_only[:6])) if local_only else "AI containers use a forwarding log driver.", "selfhosted-inference",
                      retention={"source": "inf-server", "days": 7} if local_only else None)
            inv["containers"] = drivers
    # ---- host ----
    if platform.system() == "Linux":
        rc, out, _ = sh(["systemctl", "is-active", "auditd"])
        b.observe("INF-04", "met" if out.strip() == "active" else "gap", f"auditd {out.strip() or 'not installed'} on this host.", "selfhosted-inference")
        if not Path("/var/log/journal").exists():
            b.note("journald is volatile on this host (/var/log/journal absent): logs are lost on reboot unless forwarded.")
        rc, out, _ = sh(["ps", "-eo", "args"])
        for line in out.splitlines():
            if "vllm" in line and ("serve" in line or "api_server" in line):
                b.observe("INF-05", "info", f"vLLM process: --api-key {'set' if '--api-key' in line else 'not set'}; --enable-log-requests {'set' if '--enable-log-requests' in line else 'not set'}.", "selfhosted-inference")
                break
    return b
