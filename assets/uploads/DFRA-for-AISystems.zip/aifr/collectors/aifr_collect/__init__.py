"""AIFR collectors: read-only evidence collection for AI forensic readiness assessments.

Standard library only, so the package can be copied onto a client host and run
with any Python 3.8+ interpreter. Every collector writes an evidence bundle
(JSON) plus a sha256sum-compatible sidecar, ready to import into the Workbench.
"""

__version__ = "1.0.0"
