"""Cloud AI collectors: AWS Bedrock, Azure OpenAI / Entra ID, Google Cloud Vertex AI.

Each uses the provider's own CLI under the assessor's read-only identity
(AWS SecurityAudit, Azure Reader + Monitoring Reader, GCP Viewer + Private
Logs Viewer). Only read calls are made. Missing CLIs or permissions are
recorded as errors, not guessed.
"""
import json
import re
import shutil
import subprocess

from .bundle import Bundle


def cli(cmd, timeout=60):
    """Run a CLI and return (ok, parsed JSON or text, stderr)."""
    exe = shutil.which(cmd[0]) or shutil.which(cmd[0] + ".cmd")
    if not exe:
        return False, None, f"{cmd[0]} CLI not found on PATH"
    try:
        r = subprocess.run([exe] + cmd[1:], capture_output=True, text=True, timeout=timeout, errors="replace")
    except (OSError, subprocess.SubprocessError) as e:
        return False, None, str(e)
    if r.returncode != 0:
        return False, None, (r.stderr or r.stdout).strip()[:400]
    out = r.stdout.strip()
    try:
        return True, json.loads(out) if out else {}, ""
    except ValueError:
        return True, out, ""


# ------------------------------------------------------------------ AWS
def aws(regions, profile=None):
    base = ["aws"] + (["--profile", profile] if profile else []) + ["--output", "json"]
    ok, ident, err = cli(base + ["sts", "get-caller-identity"])
    acct = ident.get("Account", "unknown") if ok and isinstance(ident, dict) else "unknown"
    b = Bundle("aifr-aws", "cloud", f"aws-{acct}", details={"regions": regions, "caller": (ident or {}).get("Arn", "") if ok else ""})
    if not ok:
        b.observe("BDR-01", "error", "Could not call AWS: " + err, "aws-bedrock")
        return b
    on, off, groups, buckets, large = [], [], set(), set(), []
    for r in regions:
        ok, cfg, err = cli(base + ["--region", r, "bedrock", "get-model-invocation-logging-configuration"])
        if not ok:
            b.note(f"{r}: {err}")
            continue
        lc = (cfg or {}).get("loggingConfig") if isinstance(cfg, dict) else None
        if lc and lc.get("textDataDeliveryEnabled"):
            on.append(r)
            if (lc.get("cloudWatchConfig") or {}).get("logGroupName"):
                groups.add((r, lc["cloudWatchConfig"]["logGroupName"]))
            if (lc.get("s3Config") or {}).get("bucketName"):
                buckets.add(lc["s3Config"]["bucketName"])
            lg = (lc.get("cloudWatchConfig") or {}).get("largeDataDeliveryS3Config") or {}
            if lc.get("s3Config") or lg.get("bucketName"):
                large.append(r)
                if lg.get("bucketName"):
                    buckets.add(lg["bucketName"])
        else:
            off.append(r)
    if on or off:
        b.observe("BDR-01", "met" if on and not off else "partial" if on else "gap",
                  f"Invocation logging on in: {', '.join(on) or 'none'}; off in: {', '.join(off) or 'none'}.", "aws-bedrock", data={"on": on, "off": off})
        if on:
            b.observe("BDR-02", "met" if len(large) == len(on) else "partial" if large else "gap",
                      f"S3 delivery for large or binary payloads in {len(large)} of {len(on)} logging Regions.", "aws-bedrock")
    days_seen = []
    for r, g in sorted(groups):
        ok, res, err = cli(base + ["--region", r, "logs", "describe-log-groups", "--log-group-name-prefix", g])
        for lg in (res or {}).get("logGroups", []) if ok else []:
            if lg.get("logGroupName") == g:
                days_seen.append(lg.get("retentionInDays") or 3650)
    if days_seen:
        d = min(days_seen)
        b.observe("BDR-03", "info", f"Invocation log group retention: {', '.join(str(x) + ' days' for x in days_seen)} (never-expire counted as 3650).", "aws-bedrock",
                  retention={"source": "bdr-inv", "days": d})
    locked, unlocked = [], []
    for bk in sorted(buckets):
        ok, res, err = cli(base + ["s3api", "get-object-lock-configuration", "--bucket", bk])
        if ok and ((res or {}).get("ObjectLockConfiguration") or {}).get("ObjectLockEnabled") == "Enabled":
            locked.append(bk)
        else:
            unlocked.append(bk)
    if buckets:
        b.observe("BDR-04", "met" if not unlocked else "partial" if locked else "gap", f"Object Lock enabled on {len(locked)} of {len(buckets)} invocation-log buckets.", "aws-bedrock")
    ok, trails, err = cli(base + ["cloudtrail", "describe-trails"])
    tl = (trails or {}).get("trailList", []) if ok else []
    good, sel_hits = [], []
    for t in tl:
        ok2, st, _ = cli(base + ["--region", t.get("HomeRegion", regions[0] if regions else "us-east-1"), "cloudtrail", "get-trail-status", "--name", t["TrailARN"]])
        logging = ok2 and (st or {}).get("IsLogging")
        if logging and t.get("IsMultiRegionTrail") and t.get("LogFileValidationEnabled"):
            good.append(t["Name"])
        ok3, sel, _ = cli(base + ["--region", t.get("HomeRegion", "us-east-1"), "cloudtrail", "get-event-selectors", "--trail-name", t["TrailARN"]])
        if ok3 and "AWS::Bedrock::" in json.dumps(sel):
            sel_hits.append(t["Name"])
    if ok:
        b.observe("BDR-05", "met" if good else "gap", (f"Logging multi-Region trail(s) with validation: {', '.join(good)}.") if good else f"{len(tl)} trails found; none is logging, multi-Region and validated.", "aws-bedrock")
        b.observe("BDR-06", "met" if sel_hits else "gap", (f"Bedrock data events selected on: {', '.join(sel_hits)}.") if sel_hits else "No trail selects AWS::Bedrock:: data events.", "aws-bedrock")
    gr = 0
    for r in regions:
        ok, res, _ = cli(base + ["--region", r, "bedrock", "list-guardrails"])
        if ok:
            gr += len((res or {}).get("guardrails", []))
    b.observe("BDR-08", "partial" if gr else "gap", f"{gr} guardrails defined across the Regions checked. Confirm they are attached to production calls.", "aws-bedrock")
    b.inventory["cloud"] = {"account": acct, "regions_logging": on, "regions_not_logging": off, "trails": [t.get("Name") for t in tl]}
    return b


# ------------------------------------------------------------------ Azure
def azure(subscription=None):
    base = ["az"]
    sub = ["--subscription", subscription] if subscription else []
    ok, acct, err = cli(base + ["account", "show"] + sub + ["-o", "json"])
    sid = (acct or {}).get("id", subscription or "unknown") if ok and isinstance(acct, dict) else (subscription or "unknown")
    b = Bundle("aifr-azure", "cloud", f"azure-{sid}", details={"tenant": (acct or {}).get("tenantId", "") if ok else ""})
    if not ok:
        b.observe("AOA-01", "error", "Could not call Azure CLI: " + err, "azure-openai")
        return b
    ok, accts, err = cli(base + ["cognitiveservices", "account", "list"] + sub + ["-o", "json"])
    res = [a for a in (accts or []) if a.get("kind") in ("OpenAI", "AIServices")] if ok else []
    diag_ok, keyless, workspaces = [], [], set()
    for a in res:
        okd, ds, _ = cli(base + ["monitor", "diagnostic-settings", "list", "--resource", a["id"], "-o", "json"])
        items = ds.get("value", ds) if isinstance(ds, dict) else (ds or [])
        cats = set()
        for d in items or []:
            for lg in d.get("logs") or []:
                if lg.get("enabled"):
                    cats.add(lg.get("category") or lg.get("categoryGroup"))
            if d.get("workspaceId"):
                workspaces.add(d["workspaceId"])
        if {"RequestResponse", "Audit"} <= cats or "allLogs" in cats or "audit" in cats and "RequestResponse" in cats:
            diag_ok.append(a["name"])
        if (a.get("properties") or {}).get("disableLocalAuth"):
            keyless.append(a["name"])
    if res:
        b.observe("AOA-01", "met" if len(diag_ok) == len(res) else "partial" if diag_ok else "gap", f"Diagnostic settings with Audit and RequestResponse on {len(diag_ok)} of {len(res)} AI resources.", "azure-openai",
                  data={"resources": [a["name"] for a in res], "with_diagnostics": diag_ok})
        b.observe("AOA-02", "met" if len(keyless) == len(res) else "partial" if keyless else "gap", f"Key authentication disabled on {len(keyless)} of {len(res)} AI resources.", "azure-openai")
    else:
        b.note("No Azure OpenAI or AI Services resources found in this subscription.")
    rets = []
    for w in sorted(workspaces):
        okw, ws, _ = cli(base + ["monitor", "log-analytics", "workspace", "show", "--ids", w, "-o", "json"])
        if okw and isinstance(ws, dict):
            rets.append(ws.get("retentionInDays") or 30)
    if rets:
        d = min(rets)
        b.observe("AOA-04", "info", f"Workspace retention for AI diagnostics: {', '.join(str(x) for x in rets)} days.", "azure-openai", retention={"source": "aoa-diag", "days": d})
    okp, pr, err = cli(base + ["security", "pricing", "show", "-n", "AI"] + sub + ["-o", "json"])
    if okp and isinstance(pr, dict):
        b.observe("AOA-07", "met" if pr.get("pricingTier") == "Standard" else "gap", f"Defender for Cloud AI plan: {pr.get('pricingTier')}.", "azure-openai")
    okg, apims, _ = cli(base + ["apim", "list"] + sub + ["-o", "json"])
    llm = []
    for ap in (apims or []) if okg else []:
        okd, ds, _ = cli(base + ["monitor", "diagnostic-settings", "list", "--resource", ap["id"], "-o", "json"])
        if okd and re.search(r"GatewayLlmLog", json.dumps(ds), re.I):
            llm.append(ap["name"])
    if okg and apims:
        b.observe("AOA-03", "partial" if llm else "gap", (f"APIM generative AI gateway logs exported from: {', '.join(llm)}. Confirm 'Log LLM messages' per API.") if llm else f"{len(apims)} API Management instances; none exports generative AI gateway logs.", "azure-openai")
    oke, ent, err = cli(base + ["rest", "--method", "get", "--url", "https://management.azure.com/providers/microsoft.aadiam/diagnosticSettings?api-version=2017-04-01-preview", "-o", "json"])
    if oke:
        txt = json.dumps(ent)
        exported = bool(re.search(r'"category":\s*"SignInLogs"[^}]*"enabled":\s*true', txt))
        b.observe("IDN-01", "met" if exported else "gap", "Entra ID SignInLogs exported by diagnostic setting." if exported else "Entra ID sign-in logs are not exported (native retention 30 days on P1/P2).", "identity")
    else:
        b.note("Entra ID diagnostic settings not readable: " + err)
    b.inventory["cloud"] = {"subscription": sid, "ai_resources": [a["name"] for a in res]}
    return b


# ------------------------------------------------------------------ Google Cloud
def gcp(project):
    b = Bundle("aifr-gcp", "cloud", f"gcp-{project}")
    ok, pol, err = cli(["gcloud", "projects", "get-iam-policy", project, "--format=json"])
    if not ok:
        b.observe("VTX-01", "error", "Could not read IAM policy: " + err, "gcp-vertex")
        return b
    ac = (pol or {}).get("auditConfigs", []) if isinstance(pol, dict) else []
    hit = [a for a in ac if a.get("service") in ("aiplatform.googleapis.com", "allServices") and any(c.get("logType") == "DATA_READ" for c in a.get("auditLogConfigs", []))]
    b.observe("VTX-01", "met" if hit else "gap", "DATA_READ audit logs enabled for " + ", ".join(a["service"] for a in hit) if hit else "Data Access (DATA_READ) logs are not enabled for aiplatform.googleapis.com at project level (check folder and organisation too).", "gcp-vertex")
    ok, buckets, err = cli(["gcloud", "logging", "buckets", "list", "--project", project, "--format=json"])
    if ok:
        default = next((x for x in buckets or [] if x.get("name", "").endswith("/_Default")), None)
        days = (default or {}).get("retentionDays", 30)
        locked = [x["name"].split("/")[-1] for x in buckets or [] if x.get("locked")]
        b.observe("VTX-03", "partial" if locked else "gap", f"_Default bucket keeps {days} days; locked buckets: {', '.join(locked) or 'none'}.", "gcp-vertex", retention={"source": "vtx-data", "days": days})
    ok, sinks, err = cli(["gcloud", "logging", "sinks", "list", "--project", project, "--format=json"])
    if ok:
        rel = [s["name"] for s in sinks or [] if not s.get("filter") or "aiplatform" in s.get("filter", "") or "cloudaudit" in s.get("filter", "")]
        b.observe("VTX-05", "met" if rel else "gap", ("Sinks that can carry AI audit logs: " + ", ".join(rel)) if rel else "No sink exports AI audit logs from this project (check organisation-level aggregated sinks).", "gcp-vertex")
    ok, tok, err = cli(["gcloud", "auth", "print-access-token"])
    if ok and isinstance(tok, str) and tok:
        import urllib.request
        import urllib.error
        url = f"https://cloudaicompanion.googleapis.com/v1/projects/{project}/locations/global/loggingSettings"
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={"Authorization": "Bearer " + tok.strip()}), timeout=15) as r:
                body = json.loads(r.read().decode("utf-8", "replace"))
            items = body.get("loggingSettings", [])
            pr = any(i.get("logPromptsAndResponses") for i in items)
            md = any(i.get("logMetadata") for i in items)
            b.observe("GCA-01", "met" if pr else "partial" if md else "gap", f"Gemini Code Assist logging: prompts and responses {'on' if pr else 'off'}, metadata {'on' if md else 'off'}.", "google-code")
        except (urllib.error.URLError, OSError, ValueError) as e:
            b.note(f"Gemini Code Assist logging settings not readable: {e}")
    b.inventory["cloud"] = {"project": project}
    return b
