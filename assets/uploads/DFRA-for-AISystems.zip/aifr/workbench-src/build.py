"""Build the AIFR Workbench into one self-contained HTML file.

Validates the knowledge base, merges it, and inlines CSS, JS and KB data so the
Workbench runs offline from a single file with no network access.

    python build.py            # validate + build ../AIFR-Workbench.html
    python build.py --check    # validate only
"""
import json
import re
import sys
from pathlib import Path

SRC = Path(__file__).resolve().parent
KB_DIR = SRC / "kb"
APP_DIR = SRC / "app"
OUT_HTML = SRC.parent / "AIFR-Workbench.html"
OUT_KB = SRC / "dist" / "kb.json"

PLATFORM_FILES = [
    "platforms-workplace.json",
    "platforms-coding.json",
    "platforms-cloud.json",
    "platforms-internal.json",
    "platforms-foundation.json",
]
JS_ORDER = [
    "util.js", "engine.js", "store.js", "importer.js", "charts.js",
    "views/overview.js", "views/scope.js", "views/runbook.js", "views/collect.js",
    "views/assess.js", "views/results.js", "views/report.js", "views/library.js",
    "app.js",
]

CAPS = {"native", "config", "partial", "none", "na"}
METHODS = {"auto", "guided", "interview"}
EFFORTS = {"S", "M", "L"}
LANGS = {"powershell", "bash", "kql", "sql", "text"}


def load(name):
    with open(KB_DIR / name, encoding="utf-8") as fh:
        return json.load(fh)


def build_kb():
    model = load("model.json")
    fw = load("frameworks.json")
    sc = load("scenarios.json")
    platforms = []
    for f in PLATFORM_FILES:
        platforms.extend(load(f)["platforms"])
    kb = dict(model)
    kb["frameworks"] = fw["frameworks"]
    kb["refs"] = fw["refs"]
    kb["scenarios"] = sc["scenarios"]
    kb["platforms"] = platforms
    return kb


def validate(kb):
    errs = []
    ev = {e["id"] for e in kb["evidence"]}
    domains = {d["id"] for d in kb["domains"]}
    aspects = {a["id"] for a in kb["aspects"]}
    keys = {k["id"] for k in kb["keys"]}
    cats = {c["id"] for c in kb["categories"]}
    fws = {f["id"] for f in kb["frameworks"]}
    refs = set()
    for r in kb["refs"]:
        if r["fw"] not in fws:
            errs.append(f"ref {r['id']}: unknown framework {r['fw']}")
        if r["id"] in refs:
            errs.append(f"duplicate ref {r['id']}")
        refs.add(r["id"])

    pids, cids, srcids = set(), set(), set()
    for p in kb["platforms"]:
        pid = p["id"]
        if pid in pids:
            errs.append(f"duplicate platform {pid}")
        pids.add(pid)
        if p["category"] not in cats:
            errs.append(f"{pid}: bad category {p['category']}")
        missing = ev - set(p["evidence"])
        if missing:
            errs.append(f"{pid}: evidence map missing {sorted(missing)}")
        for k, v in p["evidence"].items():
            if k not in ev or v not in CAPS:
                errs.append(f"{pid}: bad evidence entry {k}={v}")
        for s in p.get("sources", []):
            if s["id"] in srcids:
                errs.append(f"duplicate source {s['id']}")
            srcids.add(s["id"])
            if s.get("days") is not None and not isinstance(s["days"], int):
                errs.append(f"source {s['id']}: days must be int or null")
        variants = {v["id"] for v in p.get("variants", [])}
        for c in p["controls"]:
            cid = c["id"]
            where = f"{pid}/{cid}"
            if cid in cids:
                errs.append(f"duplicate control {cid}")
            cids.add(cid)
            for fld in ("title", "aspect", "domain", "weight", "method", "how", "expect", "impact", "fix", "effort", "owner"):
                if fld not in c:
                    errs.append(f"{where}: missing {fld}")
            if c.get("aspect") not in aspects:
                errs.append(f"{where}: bad aspect {c.get('aspect')}")
            if c.get("domain") not in domains:
                errs.append(f"{where}: bad domain {c.get('domain')}")
            if c.get("key") and c["key"] not in keys:
                errs.append(f"{where}: bad key {c['key']}")
            if c.get("weight") not in (1, 2, 3):
                errs.append(f"{where}: weight must be 1-3")
            if c.get("method") not in METHODS:
                errs.append(f"{where}: bad method")
            if c.get("effort") not in EFFORTS:
                errs.append(f"{where}: bad effort")
            for e in c.get("provides", []):
                if e not in ev:
                    errs.append(f"{where}: provides unknown {e}")
            for r in c.get("refs", []):
                if r not in refs:
                    errs.append(f"{where}: unknown ref {r}")
            for v in c.get("variants", []):
                if v not in variants:
                    errs.append(f"{where}: unknown variant {v}")
            for cmd in c.get("cmd", []):
                if cmd.get("lang") not in LANGS:
                    errs.append(f"{where}: bad cmd lang {cmd.get('lang')}")
            for rule in c.get("eval", []):
                if rule.get("s") not in ("met", "partial", "gap"):
                    errs.append(f"{where}: bad eval status")
                try:
                    re.compile(rule["re"])
                except re.error as ex:
                    errs.append(f"{where}: eval regex error {ex}")

    for s in kb["scenarios"]:
        for cat in s["scope"].get("categories", []):
            if cat not in cats:
                errs.append(f"{s['id']}: bad category {cat}")
        for pid in s["scope"].get("platforms", []):
            if pid not in pids:
                errs.append(f"{s['id']}: unknown platform {pid}")
        for r in s.get("refs", []):
            if r not in refs:
                errs.append(f"{s['id']}: unknown ref {r}")
        for q in s["questions"]:
            for e in q["needs"]:
                if e not in ev:
                    errs.append(f"{q['id']}: unknown evidence {e}")
            for a in q.get("alt", []):
                if a not in pids:
                    errs.append(f"{q['id']}: unknown alt platform {a}")
    return errs


def stats(kb):
    n_c = sum(len(p["controls"]) for p in kb["platforms"])
    auto = sum(1 for p in kb["platforms"] for c in p["controls"] if c["method"] == "auto")
    return f"{len(kb['platforms'])} platforms, {n_c} controls ({auto} automated), {len(kb['scenarios'])} scenarios, {len(kb['refs'])} references"


def build(kb):
    template = (APP_DIR / "index.html").read_text(encoding="utf-8")
    css = (APP_DIR / "app.css").read_text(encoding="utf-8")
    js = "\n".join(
        f"/* ---- {name} ---- */\n" + (APP_DIR / "js" / name).read_text(encoding="utf-8")
        for name in JS_ORDER
    )
    kb_json = json.dumps(kb, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    sample_path = SRC.parent / "samples" / "sample-engagement.json"
    sample = sample_path.read_text(encoding="utf-8") if sample_path.exists() else "null"
    sample_json = json.dumps(json.loads(sample), ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    for marker in ("/*__CSS__*/", "/*__JS__*/", "__KB_JSON__", "__SAMPLE_JSON__"):
        if template.count(marker) != 1:
            raise SystemExit(f"template must contain {marker} exactly once")
    html = (template.replace("/*__CSS__*/", css)
            .replace("__KB_JSON__", kb_json)
            .replace("__SAMPLE_JSON__", sample_json)
            .replace("/*__JS__*/", js.replace("</script", "<\\/script")))
    OUT_HTML.write_text(html, encoding="utf-8")
    OUT_KB.parent.mkdir(exist_ok=True)
    OUT_KB.write_text(json.dumps(kb, ensure_ascii=False, indent=1), encoding="utf-8")
    return len(html)


def main():
    kb = build_kb()
    errs = validate(kb)
    if errs:
        print("Knowledge base errors:")
        for e in errs:
            print("  -", e)
        sys.exit(1)
    print("KB OK:", stats(kb))
    if "--check" in sys.argv:
        OUT_KB.parent.mkdir(exist_ok=True)
        OUT_KB.write_text(json.dumps(kb, ensure_ascii=False, indent=1), encoding="utf-8")
        return
    size = build(kb)
    print(f"Built {OUT_HTML.name} ({size/1024:.0f} KB)")


if __name__ == "__main__":
    main()
