/* Collector bundle intake: hashing on receipt, sidecar verification, fleet aggregation,
   and translating observations into check results (manual decisions always win). */
(function (root) {
  'use strict';
  const U = root.AIFR.util;
  const S = root.AIFR.store;
  const I = {};

  function compactObs(b) {
    return (b.observations || []).filter(o => o && o.control).map(o => {
      const row = [o.control, o.status || 'info'];
      if ((o.status === 'gap' || o.status === 'partial' || o.status === 'error' || o.status === 'info') && o.detail) row.push(String(o.detail).slice(0, 160));
      return row;
    });
  }

  function compactInventory(b) {
    const inv = b.inventory || {};
    const tools = (inv.tools || []).map(t => ({
      id: t.id, name: t.name, users: (t.users || []).length,
      transcripts: t.transcripts || 0, bytes: t.bytes || 0, oldest: t.oldest || '', newest: t.newest || '',
      retentionDays: t.retention_days == null ? null : t.retention_days,
      managed: !!t.managed, central: !!t.central_capture
    }));
    const mcp = (inv.mcp_servers || []).slice(0, 80).map(m => ({ name: m.name, transport: m.transport || '', target: m.target || '', client: m.client || '' }));
    const ext = (inv.extensions || []).slice(0, 60).map(x => ({ name: x.name, browser: x.browser || '' }));
    const listeners = (inv.listeners || []).slice(0, 20).map(l => ({ port: l.port, addr: l.address, proc: l.process || '' }));
    const agentic = (inv.agentic_browsers || []).slice(0, 10);
    return { tools, mcp, ext, listeners, agentic, telemetry: inv.telemetry || null };
  }

  function parseSidecars(texts) {
    const map = {};
    texts.forEach(t => t.split(/\r?\n/).forEach(line => {
      const m = line.trim().match(/^([a-fA-F0-9]{64})\s+\*?(.+)$/);
      if (m) map[m[2].trim().split(/[\\/]/).pop()] = m[1].toLowerCase();
    }));
    return map;
  }

  I.importFiles = async function (fileList) {
    const files = Array.prototype.slice.call(fileList);
    const sideTexts = [];
    for (const f of files) if (/\.sha256$/i.test(f.name)) sideTexts.push(U.decode(await U.readFile(f)));
    const sidecars = parseSidecars(sideTexts);
    const out = { added: 0, replaced: 0, skipped: 0, errors: [], engagement: null };
    for (const f of files) {
      if (/\.sha256$/i.test(f.name)) continue;
      try {
        const buf = await U.readFile(f);
        const sha = await U.sha256(buf);
        let obj;
        try { obj = JSON.parse(U.decode(buf)); } catch (e) { throw new Error('not valid JSON'); }
        if (obj && typeof obj.schema === 'string' && obj.schema.indexOf('aifr.engagement/') === 0) { out.engagement = obj; continue; }
        if (!obj || typeof obj.schema !== 'string' || obj.schema.indexOf('aifr.bundle/') !== 0) throw new Error('not an AIFR collector bundle');
        if (S.eng.bundles.some(x => x.sha256 === sha)) { out.skipped++; continue; }
        const rec = {
          id: obj.bundle_id || U.uid('bdl'), file: f.name, sha256: sha, bytes: buf.byteLength,
          verified: sidecars[f.name] ? sidecars[f.name] === sha : null,
          collector: (obj.collector && obj.collector.name) || 'unknown', version: (obj.collector && obj.collector.version) || '',
          impl: (obj.collector && obj.collector.impl) || '',
          targetType: (obj.target && obj.target.type) || '', target: (obj.target && obj.target.id) || '', os: (obj.target && obj.target.os) || '',
          collectedAt: (obj.run && (obj.run.finished || obj.run.started)) || '', operator: (obj.run && obj.run.operator) || '',
          importedAt: U.now(), obs: compactObs(obj),
          ret: (obj.observations || []).filter(o => o.retention && o.retention.source).map(o => ({ source: o.retention.source, days: o.retention.days, oldest: o.retention.oldest || '' }))
        };
        if (rec.targetType === 'endpoint') rec.inv = compactInventory(obj);
        if (obj.inventory && obj.inventory.shadow) rec.shadow = obj.inventory.shadow;
        if (obj.inventory && obj.inventory.cloud) rec.cloud = obj.inventory.cloud;
        // a newer bundle from the same collector and target replaces the older one
        const prev = S.eng.bundles.findIndex(x => x.collector === rec.collector && x.target === rec.target && x.targetType === rec.targetType);
        if (prev >= 0) {
          if ((S.eng.bundles[prev].collectedAt || '') > (rec.collectedAt || '')) { out.skipped++; continue; }
          S.eng.bundles.splice(prev, 1); out.replaced++;
        } else out.added++;
        S.eng.bundles.push(rec);
        S.log('Bundle imported: ' + rec.collector + ' / ' + (rec.target || 'unknown target') + ' (SHA-256 ' + sha.slice(0, 12) + '…' + (rec.verified === true ? ', sidecar verified' : rec.verified === false ? ', SIDECAR MISMATCH' : '') + ')');
      } catch (e) {
        out.errors.push(f.name + ': ' + e.message);
      }
    }
    if (out.added || out.replaced) I.apply();
    return out;
  };

  I.removeBundle = function (id) {
    const i = S.eng.bundles.findIndex(b => b.id === id);
    if (i < 0) return;
    const b = S.eng.bundles.splice(i, 1)[0];
    S.log('Bundle removed: ' + b.collector + ' / ' + b.target);
    I.apply();
  };

  /* Aggregate observations per check across all bundles. */
  I.collected = function () {
    const agg = {};
    (S.eng ? S.eng.bundles : []).forEach(b => b.obs.forEach(o => {
      const a = agg[o[0]] || (agg[o[0]] = { met: 0, partial: 0, gap: 0, na: 0, info: 0, error: 0, targets: 0, endpoint: 0, details: [] });
      const st = o[1] in a ? o[1] : 'info';
      a[st]++; a.targets++;
      if (b.targetType === 'endpoint') a.endpoint++;
      if (o[2] && (st === 'gap' || st === 'partial') && a.details.length < 6) a.details.push((b.target ? b.target + ': ' : '') + o[2]);
    }));
    return agg;
  };

  I.statusFrom = function (a) {
    const decided = a.met + a.partial + a.gap;
    if (!decided) return a.na && !a.info ? 'na' : null;
    if (!a.gap && !a.partial) return 'met';
    if (!a.met && !a.partial) return 'gap';
    return 'partial';
  };

  I.noteFrom = function (a) {
    const decided = a.met + a.partial + a.gap;
    const unit = a.endpoint ? 'endpoints' : 'targets';
    return 'Collector: ' + a.met + ' of ' + decided + ' ' + unit + ' met' + (a.partial ? ', ' + a.partial + ' partial' : '') + (a.gap ? ', ' + a.gap + ' gap' : '') + '.' + (a.details.length ? ' ' + a.details.slice(0, 3).join(' | ') : '');
  };

  I.apply = function () {
    const agg = I.collected();
    Object.keys(S.eng.results).forEach(cid => {
      const r = S.eng.results[cid];
      if (r.source === 'collector' && !agg[cid]) { r.status = 'open'; r.note = ''; r.source = ''; }
    });
    Object.keys(agg).forEach(cid => {
      if (!S.idx.controls[cid]) return;
      const st = I.statusFrom(agg[cid]);
      if (!st) return;
      const r = S.ensureResult(cid);
      if (r.source === 'manual' && r.status !== 'open') return;
      r.status = st; r.source = 'collector'; r.note = I.noteFrom(agg[cid]); r.at = U.now(); r.by = 'Collector';
    });
    // retention observed by collectors: the shortest value wins (weakest endpoint or source)
    const ret = {};
    S.eng.bundles.forEach(b => (b.ret || []).forEach(x => {
      if (x.days == null) return;
      if (!ret[x.source] || x.days < ret[x.source].days) ret[x.source] = { days: x.days, oldest: x.oldest };
    }));
    Object.keys(ret).forEach(sid => {
      const cur = S.eng.retention[sid];
      if (cur && cur.src === 'manual') return;
      S.eng.retention[sid] = { days: ret[sid].days, oldest: ret[sid].oldest || '', src: 'collector' };
    });
    S.commit();
  };

  /* Fleet view built from endpoint bundles. */
  I.fleet = function () {
    const eps = (S.eng ? S.eng.bundles : []).filter(b => b.targetType === 'endpoint' && b.inv);
    if (!eps.length) return null;
    const tools = {}, mcp = {}, ext = {}, agentic = {};
    let exposed = 0, withAI = 0, transcripts = 0;
    eps.forEach(b => {
      if (b.inv.tools.length) withAI++;
      if ((b.inv.listeners || []).some(l => l.addr && l.addr !== '127.0.0.1' && l.addr !== '::1' && l.addr !== 'localhost')) exposed++;
      b.inv.tools.forEach(t => {
        const x = tools[t.id] || (tools[t.id] = { id: t.id, name: t.name, hosts: 0, withTranscripts: 0, transcripts: 0, bytes: 0, managed: 0, central: 0, retention: [], oldest: '' });
        x.hosts++; x.transcripts += t.transcripts; x.bytes += t.bytes;
        if (t.transcripts) { x.withTranscripts++; transcripts += t.transcripts; }
        if (t.managed) x.managed++;
        if (t.central) x.central++;
        if (t.retentionDays != null) x.retention.push(t.retentionDays);
        if (t.oldest && (!x.oldest || t.oldest < x.oldest)) x.oldest = t.oldest;
      });
      b.inv.mcp.forEach(m => {
        const k = (m.name || '') + '|' + (m.target || '');
        const x = mcp[k] || (mcp[k] = { name: m.name, target: m.target, transport: m.transport, hosts: 0, clients: {} });
        x.hosts++; if (m.client) x.clients[m.client] = 1;
      });
      b.inv.ext.forEach(e => { ext[e.name] = (ext[e.name] || 0) + 1; });
      (b.inv.agentic || []).forEach(a => { agentic[a] = (agentic[a] || 0) + 1; });
    });
    const med = arr => { if (!arr.length) return null; const s = arr.slice().sort((a, b) => a - b); return s[Math.floor(s.length / 2)]; };
    return {
      endpoints: eps.length, withAI, exposed, transcripts,
      tools: Object.values(tools).map(t => Object.assign(t, { medianRetention: med(t.retention) })).sort((a, b) => b.hosts - a.hosts),
      mcp: Object.values(mcp).map(m => Object.assign(m, { clients: Object.keys(m.clients) })).sort((a, b) => b.hosts - a.hosts),
      extensions: Object.keys(ext).map(k => ({ name: k, hosts: ext[k] })).sort((a, b) => b.hosts - a.hosts),
      agentic: Object.keys(agentic).map(k => ({ name: k, hosts: agentic[k] }))
    };
  };

  I.shadow = function () {
    const b = (S.eng ? S.eng.bundles : []).filter(x => x.shadow).sort((a, b2) => (b2.collectedAt || '').localeCompare(a.collectedAt || ''))[0];
    return b ? Object.assign({ bundle: b.file }, b.shadow) : null;
  };

  /* Every hashed artefact in the engagement: bundles plus evidence attached to checks. */
  I.register = function () {
    if (!S.eng) return [];
    const rows = S.eng.bundles.map(b => ({ kind: 'Collector bundle', ref: b.collector + ' / ' + (b.target || ''), label: b.file, sha256: b.sha256, bytes: b.bytes, at: b.importedAt, verified: b.verified }));
    Object.keys(S.eng.results).forEach(cid => (S.eng.results[cid].evidence || []).forEach(ev => rows.push({ kind: ev.kind === 'file' ? 'File' : 'Command output', ref: cid, label: ev.label + (ev.name ? ' (' + ev.name + ')' : ''), sha256: ev.sha256, bytes: ev.bytes, at: ev.addedAt, verified: null })));
    return rows.sort((a, b) => (a.at || '').localeCompare(b.at || ''));
  };

  root.AIFR.importer = I;
})(typeof window !== 'undefined' ? window : globalThis);
