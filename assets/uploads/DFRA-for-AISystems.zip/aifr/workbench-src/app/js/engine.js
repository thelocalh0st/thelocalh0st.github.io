/* AIFR scoring engine. Pure functions over (KB index, engagement).
   Runs in the browser (window.AIFR.engine) and in Node (module.exports) for tests. */
(function (root) {
  'use strict';

  const RANK = { met: 5, partial: 4, unverified: 3, open: 2, gap: 1 };
  const VALUE = { met: 1, partial: 0.5, unverified: 0.25, gap: 0 };
  const AI_CATEGORIES = ['workplace', 'coding', 'cloud', 'internal'];
  const LADDER_EXTRA = ['shadow-ai'];
  const SEV = ['low', 'medium', 'high', 'critical'];
  const PHASES = [
    { id: 'P1', label: 'First 30 days' },
    { id: 'P2', label: '31 to 90 days' },
    { id: 'P3', label: 'After 90 days' }
  ];

  function indexKB(kb) {
    const idx = {
      kb, platforms: {}, controls: {}, refs: {}, frameworks: {}, sources: {},
      evidenceIds: kb.evidence.map(e => e.id), order: []
    };
    kb.platforms.forEach(p => {
      idx.platforms[p.id] = p;
      idx.order.push(p.id);
      p.controls.forEach(c => { c.platform = p.id; idx.controls[c.id] = c; });
      (p.sources || []).forEach(s => { idx.sources[s.id] = Object.assign({ platform: p.id }, s); });
    });
    kb.refs.forEach(r => { idx.refs[r.id] = r; });
    kb.frameworks.forEach(f => { idx.frameworks[f.id] = f; });
    return idx;
  }

  /* ---------- scope & status ---------- */

  function inScope(eng, pid) { return !!(eng.scope && eng.scope.platforms && eng.scope.platforms[pid]); }
  function scopedIds(idx, eng) { return idx.order.filter(pid => inScope(eng, pid)); }
  function variantOf(eng, pid) { const s = eng.scope.platforms[pid]; return s && s.variant || ''; }

  function applies(eng, c) {
    if (!inScope(eng, c.platform)) return false;
    if (!c.variants || !c.variants.length) return true;
    const v = variantOf(eng, c.platform);
    return !v || c.variants.indexOf(v) >= 0;
  }

  function applicable(idx, eng, pid) {
    return idx.platforms[pid].controls.filter(c => applies(eng, c));
  }

  // mode: 'actual' (assessed results), 'ideal' (everything met), 'native' (nothing assessed)
  function statusOf(eng, c, mode) {
    if (!applies(eng, c)) return 'na';
    if (mode === 'ideal') return 'met';
    if (mode === 'native') return 'open';
    const r = eng.results && eng.results[c.id];
    return (r && r.status) || 'open';
  }

  /* ---------- evidence states ---------- */
  // ok | assumed | partial | claimed | off | none | unknown | na
  function evidenceState(idx, eng, pid, E, mode) {
    const p = idx.platforms[pid];
    const cap = p.evidence[E] || 'na';
    if (cap === 'na') return 'na';
    let best = null;
    applicable(idx, eng, pid).forEach(c => {
      if ((c.provides || []).indexOf(E) < 0) return;
      const s = statusOf(eng, c, mode);
      if (s === 'na') return;
      if (!best || RANK[s] > RANK[best.s]) best = { s, c };
    });
    const fromCap = cap === 'native' ? 'assumed' : cap === 'partial' ? 'partial' : cap === 'none' ? 'none' : 'unknown';
    if (!best || best.s === 'open') return fromCap;
    if (best.s === 'met') return (cap === 'partial' && !best.c.comp) ? 'partial' : 'ok';
    if (best.s === 'partial') return 'partial';
    if (best.s === 'unverified') return 'claimed';
    return cap === 'none' ? 'none' : 'off';
  }

  const avail = s => s === 'ok' || s === 'assumed';
  const partly = s => avail(s) || s === 'partial' || s === 'claimed';

  function evidenceRow(idx, eng, pid, mode) {
    const row = {};
    idx.evidenceIds.forEach(E => { row[E] = evidenceState(idx, eng, pid, E, mode); });
    return row;
  }

  /* ---------- aspects (retention, integrity, retrieval) ---------- */

  const FALLBACK = { retention: 'central-logging', integrity: 'central-logging', retrieval: 'governance-ir' };

  function aggregate(statuses) {
    const s = statuses.filter(x => x !== 'na');
    if (!s.length) return 'none';
    if (s.every(x => x === 'met')) return 'met';
    if (s.some(x => x === 'gap')) return 'gap';
    if (s.some(x => x === 'open')) return 'open';
    return 'partial';
  }

  function aspectState(idx, eng, pid, aspect, mode) {
    let ctrls = applicable(idx, eng, pid).filter(c => c.aspect === aspect);
    let via = pid;
    if (!ctrls.length && FALLBACK[aspect] && inScope(eng, FALLBACK[aspect])) {
      via = FALLBACK[aspect];
      ctrls = applicable(idx, eng, via).filter(c => c.aspect === aspect);
    }
    return { state: aggregate(ctrls.map(c => statusOf(eng, c, mode))), via, controls: ctrls.map(c => c.id) };
  }

  /* ---------- platform maturity level ---------- */

  // Content needed for Level 2: input and output; tool calls where the platform can capture them;
  // retrieved context stands in when the platform holds no prompts or responses itself (RAG stores).
  function contentGate(p) {
    const cap = E => p.evidence[E] || 'na';
    const gate = ['E3', 'E6'];
    if (cap('E5') === 'native' || cap('E5') === 'config') gate.push('E5');
    if (cap('E3') === 'na' && cap('E6') === 'na') gate.push('E4');
    return gate;
  }

  function levelFor(idx, eng, pid, mode) {
    const p = idx.platforms[pid];
    const ev = evidenceRow(idx, eng, pid, mode);
    const ok = list => list.every(E => ev[E] === 'na' || avail(ev[E]));
    const missing = list => list.filter(E => ev[E] !== 'na' && !avail(ev[E]));
    const content = contentGate(p);
    if (!ok(['E1', 'E2'])) return { level: 0, ev, why: 'No reliable record of who used it and when (' + missing(['E1', 'E2']).join(', ') + ').' };
    if (!ok(content)) return { level: 1, ev, why: 'Content not available: ' + missing(content).join(', ') + '.' };
    const retrieval = aspectState(idx, eng, pid, 'retrieval', mode);
    if (retrieval.state === 'gap' && retrieval.via === pid) return { level: 1, ev, capped: true, why: 'Capped at Level 1: a retrieval test was attempted and failed.' };
    const retention = aspectState(idx, eng, pid, 'retention', mode);
    const integrity = aspectState(idx, eng, pid, 'integrity', mode);
    const weak = [];
    if (retention.state !== 'met') weak.push('retention');
    if (integrity.state !== 'met') weak.push('protection from deletion');
    if (retrieval.state !== 'met') weak.push('proven retrieval');
    if (weak.length) return { level: 2, ev, why: 'Content exists but lacks ' + weak.join(', ') + '.' };
    const L4 = ['E4', 'E5', 'E7', 'E8', 'E9', 'E10', 'E11', 'E12'];
    if (!ok(L4)) return { level: 3, ev, why: 'Missing for full reconstruction: ' + missing(L4).join(', ') + '.' };
    return { level: 4, ev, why: 'Content, context, authorisation, safeguards and integrity are all available.' };
  }

  function ladder(idx, eng) {
    return scopedIds(idx, eng)
      .filter(pid => AI_CATEGORIES.indexOf(idx.platforms[pid].category) >= 0 || LADDER_EXTRA.indexOf(pid) >= 0)
      .map(pid => {
        const cur = levelFor(idx, eng, pid, 'actual');
        const best = levelFor(idx, eng, pid, 'ideal');
        return { pid, name: idx.platforms[pid].short, category: idx.platforms[pid].category, level: cur.level, why: cur.why, capped: !!cur.capped, ev: cur.ev, achievable: best.level, ceilingWhy: best.level < 4 ? best.why : '' };
      });
  }

  /* ---------- domain scores ---------- */

  function domains(idx, eng) {
    return idx.kb.domains.map(d => {
      let total = 0, assessed = 0, wsum = 0, wval = 0;
      scopedIds(idx, eng).forEach(pid => applicable(idx, eng, pid).forEach(c => {
        if (c.domain !== d.id) return;
        const s = statusOf(eng, c, 'actual');
        total++;
        if (s === 'open') return;
        assessed++; wsum += c.weight; wval += c.weight * VALUE[s];
      }));
      const score = wsum ? wval / wsum : null;
      return { id: d.id, label: d.label, total, assessed, score, level: score == null ? null : Math.round(score * 4 * 10) / 10 };
    });
  }

  /* ---------- key questions K1-K4 ---------- */

  function keyGrid(idx, eng) {
    const rows = scopedIds(idx, eng).map(pid => {
      const cells = {};
      idx.kb.keys.forEach(k => {
        const st = applicable(idx, eng, pid).filter(c => c.key === k.id).map(c => statusOf(eng, c, 'actual'));
        cells[k.id] = st.length ? aggregate(st) : 'na';
      });
      return { pid, name: idx.platforms[pid].short, cells };
    }).filter(r => Object.keys(r.cells).some(k => r.cells[k] !== 'na'));
    const totals = {};
    idx.kb.keys.forEach(k => {
      const vals = rows.map(r => r.cells[k.id]).filter(v => v !== 'na');
      totals[k.id] = { total: vals.length, met: vals.filter(v => v === 'met').length, gap: vals.filter(v => v === 'gap').length, open: vals.filter(v => v === 'open').length };
    });
    return { rows, totals };
  }

  /* ---------- scenarios ---------- */

  function bestState(idx, eng, pids, E) {
    let best = 0;
    pids.forEach(pid => {
      const s = evidenceState(idx, eng, pid, E, 'actual');
      const v = avail(s) ? 2 : partly(s) ? 1 : 0;
      if (v > best) best = v;
    });
    return best;
  }

  function scenarios(idx, eng) {
    const scoped = scopedIds(idx, eng);
    return idx.kb.scenarios.map(s => {
      const relevant = scoped.filter(pid => {
        const p = idx.platforms[pid];
        return (s.scope.categories.indexOf(p.category) >= 0) || (s.scope.platforms.indexOf(pid) >= 0);
      });
      if (!relevant.length) return { id: s.id, title: s.title, applicable: false, questions: [], yes: 0, partial: 0, total: s.questions.length, platforms: [] };
      const questions = s.questions.map(q => {
        const alts = (q.alt || []).filter(a => scoped.indexOf(a) >= 0);
        const per = [];
        relevant.forEach(pid => {
          const p = idx.platforms[pid];
          const needs = q.needs.filter(E => (p.evidence[E] || 'na') !== 'na');
          if (!needs.length) return;
          let worst = 2; const gaps = [];
          needs.forEach(E => {
            const v = Math.max(bestState(idx, eng, [pid], E), bestState(idx, eng, alts, E));
            if (v < 2) gaps.push(E);
            if (v < worst) worst = v;
          });
          per.push({ pid, name: p.short, v: worst, gaps });
        });
        let status = 'na';
        if (per.length) {
          if (per.every(x => x.v === 2)) status = 'yes';
          else if (per.every(x => x.v === 0)) status = 'no';
          else status = 'partial';
        }
        return { id: q.id, q: q.q, needs: q.needs, alts, status, per };
      });
      return {
        id: s.id, title: s.title, narrative: s.narrative, refs: s.refs, applicable: true,
        platforms: relevant.map(pid => idx.platforms[pid].short),
        questions,
        yes: questions.filter(q => q.status === 'yes').length,
        partial: questions.filter(q => q.status === 'partial').length,
        total: questions.filter(q => q.status !== 'na').length
      };
    });
  }

  /* ---------- evidence horizon ---------- */

  function floorsFor(idx, eng) {
    const j = (eng.meta && eng.meta.jurisdictions) || [];
    const sector = eng.meta && eng.meta.sector;
    return idx.kb.floors.filter(f => (f.jur === '*' || j.indexOf(f.jur) >= 0) && (!f.sector || f.sector === sector) && f.id !== 'cis');
  }

  function targetDays(eng) {
    const t = eng.meta && Number(eng.meta.targetDays);
    return t > 0 ? t : 365;
  }

  function horizon(idx, eng) {
    const rows = [];
    scopedIds(idx, eng).forEach(pid => {
      const v = variantOf(eng, pid);
      (idx.platforms[pid].sources || []).forEach(s => {
        if (s.variants && v && s.variants.indexOf(v) < 0) return;
        const ov = (eng.retention && eng.retention[s.id]) || {};
        const days = (ov.days != null && ov.days !== '') ? Number(ov.days) : s.days;
        rows.push({
          pid, platform: idx.platforms[pid].short, id: s.id, name: s.name, layer: s.layer, content: s.content,
          days: (days == null || isNaN(days)) ? null : days, assessed: ov.days != null && ov.days !== '',
          oldest: ov.oldest || '', defaultText: s.retention
        });
      });
    });
    return { rows, target: targetDays(eng), floors: floorsFor(idx, eng) };
  }

  /* ---------- findings & roadmap ---------- */

  function severity(c, status) {
    const penalty = status === 'gap' ? 0 : status === 'partial' ? 1 : 2;
    const n = Math.max(1, Math.min(4, c.weight + (c.key ? 1 : 0) - penalty));
    return { n, id: SEV[n - 1] };
  }

  function phaseFor(sevN, effort) {
    if (sevN >= 3 && effort === 'S') return 'P1';
    if ((sevN >= 3 && effort === 'M') || (sevN === 2 && effort === 'S') || sevN === 4) return 'P2';
    return 'P3';
  }

  function findings(idx, eng) {
    const out = [];
    scopedIds(idx, eng).forEach(pid => applicable(idx, eng, pid).forEach(c => {
      const s = statusOf(eng, c, 'actual');
      if (s !== 'gap' && s !== 'partial' && s !== 'unverified') return;
      const sev = severity(c, s);
      const r = eng.results[c.id] || {};
      out.push({
        id: c.id, pid, platform: idx.platforms[pid].short, title: c.title, status: s, severity: sev.id, sevN: sev.n,
        key: c.key || '', impact: c.impact, fix: c.fix, effort: c.effort, owner: c.owner, refs: c.refs || [],
        note: r.note || '', phase: phaseFor(sev.n, c.effort), component: componentOf(idx, c)
      });
    }));
    const effortRank = { S: 0, M: 1, L: 2 };
    out.sort((a, b) => (b.sevN - a.sevN) || (effortRank[a.effort] - effortRank[b.effort]) || a.id.localeCompare(b.id));
    return out;
  }

  function roadmap(idx, eng) {
    const f = findings(idx, eng);
    return PHASES.map(ph => ({ id: ph.id, label: ph.label, items: f.filter(x => x.phase === ph.id) }));
  }

  /* ---------- target-state components ---------- */

  function componentOf(idx, c) {
    if (c.comp_id) return c.comp_id;
    const p = idx.platforms[c.platform];
    if (p.id === 'governance-ir' || ['access', 'retrieval', 'process'].indexOf(c.aspect) >= 0) return 'C8';
    if (c.aspect === 'integrity') return 'C7';
    if (c.aspect === 'retention' || c.aspect === 'central' || p.id === 'central-logging') return 'C6';
    if (p.id === 'shadow-ai') return 'C5';
    if (p.id === 'identity' || c.domain === 'identity') return 'C4';
    if (p.id === 'endpoint-ai' || c.domain === 'endpoint') return 'C3';
    if (p.category === 'workplace' || p.category === 'coding') return 'C1';
    return 'C2';
  }

  function components(idx, eng) {
    return idx.kb.components.map(comp => {
      let total = 0, assessed = 0, wsum = 0, wval = 0, gaps = 0;
      scopedIds(idx, eng).forEach(pid => applicable(idx, eng, pid).forEach(c => {
        if (componentOf(idx, c) !== comp.id) return;
        total++;
        const s = statusOf(eng, c, 'actual');
        if (s === 'open') return;
        assessed++; wsum += c.weight; wval += c.weight * VALUE[s];
        if (s === 'gap') gaps++;
      }));
      const score = wsum ? wval / wsum : null;
      let state = 'open';
      if (total === 0) state = 'na';
      else if (score != null) state = score >= 0.85 ? 'met' : score >= 0.4 ? 'partial' : 'gap';
      return Object.assign({}, comp, { total, assessed, score, gaps, state });
    });
  }

  /* ---------- progress & summary ---------- */

  function progress(idx, eng) {
    let total = 0, assessed = 0;
    const by = { met: 0, partial: 0, gap: 0, unverified: 0, open: 0 };
    scopedIds(idx, eng).forEach(pid => applicable(idx, eng, pid).forEach(c => {
      const s = statusOf(eng, c, 'actual');
      total++; by[s] = (by[s] || 0) + 1;
      if (s !== 'open') assessed++;
    }));
    return { total, assessed, by, pct: total ? Math.round(assessed / total * 100) : 0 };
  }

  function median(arr) {
    if (!arr.length) return null;
    const s = arr.slice().sort((a, b) => a - b);
    const m = Math.floor(s.length / 2);
    return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
  }

  function summary(idx, eng) {
    const lad = ladder(idx, eng);
    const lv = lad.map(r => r.level);
    const f = findings(idx, eng);
    const sc = scenarios(idx, eng).filter(s => s.applicable);
    const bySev = { critical: 0, high: 0, medium: 0, low: 0 };
    f.forEach(x => { bySev[x.severity]++; });
    return {
      platforms: lad.length,
      atLeast: [0, 1, 2, 3, 4].map(n => lv.filter(l => l >= n).length),
      distribution: [0, 1, 2, 3, 4].map(n => lv.filter(l => l === n).length),
      median: median(lv), min: lv.length ? Math.min.apply(null, lv) : null,
      achievableMedian: median(lad.map(r => r.achievable)),
      findings: f.length, bySev,
      scenarios: sc.length,
      scenariosFull: sc.filter(s => s.total && s.yes === s.total).length,
      questions: sc.reduce((a, s) => a + s.total, 0),
      questionsYes: sc.reduce((a, s) => a + s.yes, 0),
      progress: progress(idx, eng),
      weakest: lad.filter(r => r.level === (lv.length ? Math.min.apply(null, lv) : -1)).map(r => r.name)
    };
  }

  /* ---------- pasted-evidence evaluation ---------- */

  function evaluateText(c, text) {
    if (!c.eval || !text) return null;
    for (let i = 0; i < c.eval.length; i++) {
      const rule = c.eval[i];
      try { if (new RegExp(rule.re, 'm').test(text)) return { status: rule.s, rule: rule.re }; } catch (e) { /* bad rule */ }
    }
    return null;
  }

  const api = {
    indexKB, inScope, scopedIds, applies, applicable, statusOf, evidenceState, evidenceRow, aspectState,
    levelFor, ladder, domains, keyGrid, scenarios, horizon, floorsFor, targetDays, findings, roadmap,
    componentOf, components, progress, summary, evaluateText, severity, PHASES, AI_CATEGORIES
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.AIFR = root.AIFR || {};
  root.AIFR.engine = api;
})(typeof window !== 'undefined' ? window : globalThis);
