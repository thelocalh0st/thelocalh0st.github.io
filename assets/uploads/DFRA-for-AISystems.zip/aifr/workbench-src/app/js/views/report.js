/* Client report: A4 pages, print to PDF or export as a standalone HTML file. */
(function (root) {
  'use strict';
  const A = root.AIFR;

  function chunk(arr, n) { const out = []; for (let i = 0; i < arr.length; i += n) out.push(arr.slice(i, i + n)); return out; }

  function implications(ctx) {
    const { E, idx, eng, U, I } = ctx;
    const kg = E.keyGrid(idx, eng).totals;
    const hz = E.horizon(idx, eng);
    const floorObj = hz.floors.length ? hz.floors.slice().sort((a, b) => a.days - b.days)[0] : null;
    const floor = floorObj ? floorObj.days : null;
    const known = hz.rows.filter(r => r.days != null);
    const below = known.filter(r => r.days < hz.target).length;
    const belowFloor = floor ? known.filter(r => r.days < floor).length : 0;
    const out = [];
    if (kg.K1.total) out.push(['Content', kg.K1.met + ' of ' + kg.K1.total + ' platforms capture prompts, responses and tool activity where an investigator can retrieve them. Elsewhere the organisation can prove an AI tool was used, but not what was said or done.']);
    if (kg.K3.total) out.push(['Deletion', (kg.K3.total - kg.K3.met) + ' of ' + kg.K3.total + ' platforms keep records that the users or administrators under investigation could delete or shorten.']);
    if (known.length) out.push(['Lookback', below + ' of ' + known.length + ' evidence sources reach back less than the ' + hz.target + '-day target' + (floor ? '; ' + belowFloor + ' fall below the ' + floor + '-day floor in ' + floorObj.label : '') + '. Capture is not retroactive, so these gaps cannot be closed for past events.']);
    if (kg.K4.total) out.push(['Privacy settings', kg.K4.met + ' of ' + kg.K4.total + ' platforms with zero-retention or privacy modes have a documented decision and compensating capture.']);
    const sh = I.shadow();
    if (sh && sh.apps) {
      const un = sh.apps.filter(a => !a.sanctioned);
      const users = un.reduce((a, x) => a + (x.users || 0), 0);
      if (un.length) out.push(['Shadow AI', un.length + ' unsanctioned AI services were reached from the network in ' + U.plural(sh.span_days || 0, 'day') + ' of logs' + (users ? ', by at least ' + users + ' user accounts' : '') + '. None of this activity is visible in any vendor console the organisation controls.']);
    }
    return out;
  }

  function pages(ctx) {
    const { U, E, C, idx, eng, I } = ctx;
    const m = eng.meta;
    const R = A.views.results;
    const v = R.verdict(ctx), s = v.s;
    const opts = ctx.S.ui.report || {};
    const P = [];
    const today = new Date().toISOString();
    // cover
    P.push({ cover: true, html: '<div class="cover" style="min-height:259mm"><div class="cv-band"><div class="cv-mark">AI<br>FR</div><span class="eyebrow">Digital forensics · Readiness assessment</span><h1>AI Forensic Readiness Assessment</h1><p>Whether ' + U.esc(m.client || 'the organisation') + ' can reconstruct an incident involving its AI systems, and what must change.</p></div>' +
      '<dl class="cv-meta"><dt>Client</dt><dd>' + U.esc(m.client) + '</dd><dt>Reference</dt><dd class="mono">' + U.esc(m.ref) + '</dd><dt>Fieldwork</dt><dd>' + U.fmtDate(m.start) + (m.end ? ' to ' + U.fmtDate(m.end) : '') + '</dd><dt>Prepared by</dt><dd>' + U.esc(m.firm || '') + '</dd><dt>Engagement lead</dt><dd>' + U.esc(m.lead || '') + '</dd><dt>Report date</dt><dd>' + U.fmtDate(today) + '</dd><dt>Scope</dt><dd>' + U.plural(E.scopedIds(idx, eng).length, 'platform') + '; target lookback ' + E.targetDays(eng) + ' days' + (m.jurisdictions.length ? '; ' + m.jurisdictions.join(', ') : '') + '</dd></dl>' +
      (eng.sample ? '<p style="margin-top:8mm;color:#8f5300;font-weight:600">Sample report. The client, people and figures are fictional.</p>' : '') +
      '<div class="cv-class"><b>' + U.esc(m.classification || 'Confidential') + '</b><br>This report describes logging and evidence gaps that could help an adversary. Distribute on a need-to-know basis.</div></div>' });
    // executive summary
    const top = E.findings(idx, eng).filter(f => f.sevN >= 3).slice(0, 6);
    P.push({ title: 'Executive summary', html: '<h2>Executive summary</h2><div class="verdict">' + U.esc(v.text) + '</div>' +
      '<div class="kpis"><div><div class="l">Median readiness</div><div class="v">L' + (s.median == null ? '–' : (Math.round(s.median * 10) / 10)) + '</div><div class="n">Reachable by configuration: L' + (s.achievableMedian == null ? '–' : (Math.round(s.achievableMedian * 10) / 10)) + '</div></div>' +
      '<div><div class="l">Content retrievable</div><div class="v">' + s.atLeast[2] + ' / ' + s.platforms + '</div><div class="n">Platforms at Level 2+</div></div>' +
      '<div><div class="l">Scenarios answerable</div><div class="v">' + s.scenariosFull + ' / ' + s.scenarios + '</div><div class="n">' + s.questionsYes + ' of ' + s.questions + ' questions</div></div>' +
      '<div><div class="l">Critical and high</div><div class="v">' + (s.bySev.critical + s.bySev.high) + '</div><div class="n">of ' + s.findings + ' findings</div></div></div>' +
      '<h3>What this means</h3><table class="tbl"><tbody>' + implications(ctx).map(x => '<tr><td style="width:28mm;font-weight:700">' + U.esc(x[0]) + '</td><td>' + U.esc(x[1]) + '</td></tr>').join('') + '</tbody></table>' +
      '<h3>Priorities</h3><table class="tbl"><thead><tr><th>Severity</th><th>Outcome to reach, and how</th><th>Platform</th><th>Window</th></tr></thead><tbody>' + top.map(f => '<tr><td>' + U.sevTag(f.severity) + '</td><td><b>' + U.esc(f.title) + '</b><div class="small" style="color:var(--ink-2)">' + U.esc(f.fix) + '</div></td><td>' + U.esc(f.platform) + '</td><td style="white-space:nowrap">' + ({ P1: '0-30 days', P2: '31-90 days', P3: '90+ days' }[f.phase]) + '</td></tr>').join('') + '</tbody></table>' });
    // readiness
    P.push({ title: 'Readiness by platform', html: '<h2>Readiness by platform</h2><p>Each platform is scored 0 to 4 by its weakest in-scope surface: 1 activity only, 2 content retrievable, 3 content preserved (retained to target, protected from deletion, retrieval proven), 4 reconstructable (adds context, authorisation, safeguard decisions and integrity proof). Dashed cells show the level reachable by configuration alone.</p>' + C.ladder(E.ladder(idx, eng)) +
      '<h3 style="margin-top:7mm">Capability domains</h3><div class="dgrid">' + C.domainBars(E.domains(idx, eng)) + '</div>' });
    // four questions + scenarios
    const sc = E.scenarios(idx, eng).filter(x => x.applicable);
    P.push({ title: 'The four questions', html: '<h2>The four questions</h2><p>Every platform answers the same four questions first. Together they decide most of the score: is content captured, how far back it reaches, who can delete it, and whether a privacy setting has voided it.</p>' + C.keyGrid(idx, E.keyGrid(idx, eng)) + (function () { const kg = E.keyGrid(idx, eng); return '<table class="tbl" style="margin-top:6mm"><thead><tr><th>Question</th><th>Passing</th><th>Failing</th><th>What failure means</th></tr></thead><tbody>' + idx.kb.keys.map(k => { const t = kg.totals[k.id]; return '<tr><td><b>' + k.id + '</b> ' + U.esc(k.label) + '</td><td class="num">' + t.met + ' of ' + t.total + '</td><td class="num">' + t.gap + '</td><td class="small">' + U.esc(k.desc) + '</td></tr>'; }).join('') + '</tbody></table>'; })() });
    P.push({ title: 'Incident scenarios', html: '<h2>Incident scenarios</h2><p>For each scenario, the questions an investigator must answer and whether the evidence exists on every platform where the incident could happen.</p><table class="tbl"><thead><tr><th>Scenario</th><th>Answerable</th><th>Weakest points</th></tr></thead><tbody>' +
      sc.map(x => {
        const weak = {};
        x.questions.forEach(q => q.per.forEach(p => { if (p.v < 2) weak[p.name] = (weak[p.name] || 0) + 1; }));
        const w = Object.keys(weak).sort((a, b) => weak[b] - weak[a]).slice(0, 4);
        return '<tr><td><b>' + x.id + '</b> ' + U.esc(x.title) + '</td><td class="num" style="white-space:nowrap"><b>' + x.yes + '</b> of ' + x.total + (x.partial ? ' (' + x.partial + ' in part)' : '') + '</td><td>' + U.esc(w.join(', ')) + '</td></tr>';
      }).join('') + '</tbody></table>' });
    // coverage
    P.push({ title: 'Evidence coverage', html: '<h2>Evidence coverage</h2><p>The twelve evidence items an investigator needs, as configured in this estate. Hatched cells are items the vendor cannot provide at any configuration.</p>' + C.matrix(idx, R.matrixRows(ctx)) });
    const hz = E.horizon(idx, eng);
    const hzRows = hz.rows.filter(r => r.days != null).sort((a, b) => a.days - b.days);
    const hzTrim = Object.assign({}, hz, { rows: hzRows.slice(0, 30) });
    P.push({ title: 'Lookback', html: '<h2>Lookback</h2><p>How far back each evidence source reaches, against the ' + hz.target + '-day target and the legal floors for this scope. Coverage also begins only on the day capture was switched on.</p>' + C.horizon(hzTrim, { width: 760, labelW: 270, rowH: 19, hideUnset: true }) + (hzRows.length > 30 ? '<p class="small">Showing the 30 shortest of ' + hzRows.length + ' sources.</p>' : '') });
    // target state + roadmap
    const rm = E.roadmap(idx, eng);
    const comps = E.components(idx, eng);
    P.push({ title: 'Target state', html: '<h2>Target state</h2><p>The evidence architecture this estate needs, and how much of each part is in place today.</p>' + C.architecture(idx, eng, comps, E.scopedIds(idx, eng)) +
      '<table class="tbl" style="margin-top:5mm"><thead><tr><th>Component</th><th>What it provides</th><th>In place</th><th>Gaps</th></tr></thead><tbody>' + comps.filter(c => c.total).map(c => '<tr><td><b>' + U.esc(c.label) + '</b></td><td class="small">' + U.esc(c.desc) + '</td><td class="num">' + (c.score == null ? '–' : Math.round(c.score * 100) + '%') + '</td><td class="num">' + c.gaps + ' of ' + c.total + '</td></tr>').join('') + '</tbody></table>' });
    P.push({ title: 'Roadmap', html: '<h2>Remediation roadmap</h2><p>Ordered by forensic value and effort. Capture is not retroactive, so each week a gap stays open is a week that can never be investigated.</p><table class="tbl"><thead><tr><th style="width:24mm">Window</th><th>Actions (highest value first)</th></tr></thead><tbody>' +
      rm.map(ph => '<tr><td><b>' + U.esc(ph.label) + '</b><div class="small muted">' + ph.items.length + ' actions</div></td><td>' + ph.items.slice(0, 6).map(f => '<div style="margin-bottom:1.4mm"><b>' + U.esc(f.title) + '</b> <span class="muted">(' + U.esc(f.platform) + ', ' + f.id + ')</span><div class="small" style="color:var(--ink-2)">' + U.esc(f.fix) + '</div></div>').join('') + (ph.items.length > 6 ? '<div class="muted">and ' + (ph.items.length - 6) + ' more in Appendix B</div>' : '') + '</td></tr>').join('') + '</tbody></table>' });
    // findings
    const keyF = E.findings(idx, eng).filter(f => f.sevN >= 3);
    chunk(keyF, 4).forEach((grp, gi) => {
      P.push({ title: 'Key findings', html: (gi === 0 ? '<h2>Key findings</h2><p>Critical and high findings. The full register is in Appendix B.</p>' : '<h2 style="font-size:13pt">Key findings (continued)</h2>') + grp.map(f => '<div class="finding"><div class="fh"><span class="ft">' + U.esc(f.title) + '</span>' + U.sevTag(f.severity) + '</div><div class="small muted"><span class="mono">' + f.id + '</span> · ' + U.esc(f.platform) + (f.key ? ' · ' + f.key + ' ' + U.esc(idx.kb.keys.find(k => k.id === f.key).label) : '') + '</div><dl class="fb">' +
        (f.note ? '<dt>Observed</dt><dd>' + U.esc(f.note) + '</dd>' : '') + '<dt>Impact</dt><dd>' + U.esc(f.impact) + '</dd><dt>Action</dt><dd>' + U.esc(f.fix) + ' <span class="muted">Effort ' + f.effort + ', ' + U.esc(f.owner) + '.</span></dd>' +
        (f.refs.length ? '<dt>References</dt><dd class="small">' + f.refs.map(r => U.esc(idx.frameworks[idx.refs[r].fw].name.split(' (')[0] + ' ' + idx.refs[r].ref)).join(' · ') + '</dd>' : '') + '</dl></div>').join('') });
    });
    // appendix A: scope and method
    P.push({ title: 'Appendix A', html: '<h2>Appendix A: Scope and method</h2><table class="tbl"><thead><tr><th>Platform</th><th>Variant</th><th>Client owner</th><th>Checks</th></tr></thead><tbody>' +
      E.scopedIds(idx, eng).map(pid => { const p = idx.platforms[pid], sp = eng.scope.platforms[pid]; const vv = p.variants.find(x => x.id === sp.variant); return '<tr><td>' + U.esc(p.name) + '</td><td>' + U.esc(vv ? vv.label : '–') + '</td><td>' + U.esc(sp.owner || '') + '</td><td class="num">' + E.applicable(idx, eng, pid).length + '</td></tr>'; }).join('') + '</tbody></table>' +
      '<h3>Method</h3><p>Six phases: mobilise, discover (automated collectors on endpoints, cloud and SaaS control planes, and network logs), verify configuration, prove retrieval (retrieve real records at set ages and hash them), readiness interviews and scenario tabletop, then scoring. Verdicts: Met (verified with evidence), Partial, Gap, Claimed (asserted but not evidenced, scored below Met), Not applicable. A failed retrieval test caps a platform at Level 1. Logging is never retroactive, so coverage start dates are reported as findings.</p>' +
      '' });
    P.push({ title: 'Appendix A', html: '<h2 style="font-size:13pt">Appendix A: Evidence model and readiness levels</h2><table class="tbl"><tbody>' + idx.kb.evidence.map(e => '<tr><td class="mono" style="width:12mm">' + e.id + '</td><td style="width:32mm"><b>' + U.esc(e.label) + '</b></td><td>' + U.esc(e.desc) + '</td></tr>').join('') + '</tbody></table><h3>Readiness levels</h3><table class="tbl"><tbody>' + idx.kb.levels.map(l => '<tr><td style="width:12mm">' + U.lvl(l.n) + '</td><td style="width:38mm"><b>' + U.esc(l.label) + '</b></td><td>' + U.esc(l.desc) + '</td></tr>').join('') + '</tbody></table>' });
    // appendix B: register of checks
    if (opts.appendix !== false) {
      const rows = [];
      E.scopedIds(idx, eng).forEach(pid => E.applicable(idx, eng, pid).forEach(c => rows.push([c, ctx.S.result(c.id)])));
      chunk(rows, 25).forEach((grp, gi) => P.push({ title: 'Appendix B', html: '<h2' + (gi ? ' style="font-size:13pt"' : '') + '>Appendix B: Check results' + (gi ? ' (continued)' : '') + '</h2><table class="tbl"><thead><tr><th>Check</th><th>Platform</th><th>Check</th><th>Verdict</th></tr></thead><tbody>' +
        grp.map(x => '<tr><td class="id">' + x[0].id + '</td><td>' + U.esc(idx.platforms[x[0].platform].short) + '</td><td>' + U.esc(x[0].title) + '</td><td>' + U.statusChip(x[1].status) + '</td></tr>').join('') + '</tbody></table>' }));
    }
    // appendix C: evidence register
    if (opts.register !== false) {
      const reg = I.register();
      if (reg.length) chunk(reg, 15).forEach((grp, gi) => P.push({ title: 'Appendix C', html: '<h2' + (gi ? ' style="font-size:13pt"' : '') + '>Appendix C: Evidence register' + (gi ? ' (continued)' : '') + '</h2>' + (gi ? '' : '<p>SHA-256 values computed on receipt. Content of samples is held in the engagement case folder, not in this report.</p>') + '<table class="tbl"><thead><tr><th>Received</th><th>Reference</th><th>Item</th><th>SHA-256</th></tr></thead><tbody>' +
        grp.map(r => '<tr><td class="small" style="white-space:nowrap">' + U.fmtDate(r.at) + '</td><td class="mono small">' + U.esc(r.ref) + '</td><td class="small">' + U.esc(r.label) + '</td><td class="hash" style="font-size:7pt">' + r.sha256 + '</td></tr>').join('') + '</tbody></table>' }));
    }
    // appendix D: limitations
    const secondary = E.scopedIds(idx, eng).filter(pid => idx.platforms[pid].confidence !== 'vendor').map(pid => idx.platforms[pid].short);
    P.push({ title: 'Appendix D', html: '<h2>Appendix D: Limitations</h2><ul class="bul"><li>This is a readiness assessment, not an investigation. No incident was investigated, and samples were retrieved only to prove that retrieval works.</li><li>Results reflect configuration and samples observed between ' + U.fmtDate(m.start) + ' and ' + U.fmtDate(m.end || today) + '. Settings can change after fieldwork; re-run the collectors to detect drift.</li><li>Vendor logging behaviour is drawn from the AIFR knowledge base ' + U.esc(idx.kb.kb_version) + ' (research current to ' + U.fmtDate(idx.kb.kb_date) + ').' + (secondary.length ? ' For ' + U.esc(secondary.join(', ')) + ' some vendor details rest on secondary sources and were confirmed in fieldwork where possible.' : '') + '</li><li>Checks marked Claimed were asserted by the client and not evidenced; they score below Met.</li><li>Legal floors cited are a summary for planning, not legal advice. Confirm obligations with counsel.</li></ul>' });
    return P;
  }

  function renderPages(ctx, fit) {
    const { U, eng } = ctx;
    const m = eng.meta;
    const P = pages(ctx);
    const mode = fit || 'auto';
    return '<div class="paper-scroll scroll-' + mode + '"><div class="paper-stack fit-' + mode + '" data-fit="' + mode + '">' + P.map((p, i) => '<section class="paper">' +
      (p.cover ? '' : '<div class="phead"><span>' + U.esc(m.client) + '</span><span>' + U.esc(String(m.classification || 'Confidential').split('.')[0]) + '</span></div>') + p.html +
      '<div class="pfoot"><span>' + U.esc(m.firm || '') + (m.firm ? ' · ' : '') + U.esc(m.ref || '') + '</span><span>' + (eng.sample ? 'SAMPLE · ' : '') + 'Page ' + (i + 1) + ' of ' + P.length + '</span></div></section>').join('') + '</div></div>';
  }

  /* Scale the A4 sheets to the space available. CSS zoom (not transform) so the layout and scroll height scale too;
     print resets it to 100%. The same function ships inside the exported report. */
  function fitPages() {
    const stack = document.querySelector('.paper-stack');
    if (!stack) return;
    const mode = stack.getAttribute('data-fit') || 'auto';
    const host = stack.parentElement.parentElement;
    const cs = getComputedStyle(host);
    const avail = host.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight) - 2;
    const page = 210 * 96 / 25.4, gap = 24;
    const spreadZ = avail / (2 * page + gap);
    // auto: two sheets side by side when both fit at close to full size, otherwise one sheet across the width
    const spread = mode === 'spread' || (mode === 'auto' && spreadZ >= 0.95);
    stack.classList.toggle('fit-spread', spread);
    let z = 1;
    if (spread) z = spreadZ;
    else if (mode === 'width' || mode === 'auto') z = avail / page;
    stack.style.zoom = String(Math.max(0.3, Math.min(z, 3)).toFixed(4));
  }

  let resizeBound = false;
  function bindResize() {
    if (resizeBound) return;
    resizeBound = true;
    let t;
    window.addEventListener('resize', () => { clearTimeout(t); t = setTimeout(fitPages, 60); });
    document.addEventListener('fullscreenchange', () => {
      if (!document.fullscreenElement && document.documentElement.classList.contains('reading')) setReading(false);
      else fitPages();
    });
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && document.documentElement.classList.contains('reading')) setReading(false);
    });
  }

  function setReading(on) {
    const root = document.documentElement;
    root.classList.toggle('reading', on);
    try {
      if (on && root.requestFullscreen && !document.fullscreenElement) root.requestFullscreen().catch(() => {});
      if (!on && document.fullscreenElement && document.exitFullscreen) document.exitFullscreen().catch(() => {});
    } catch (e) { /* fullscreen not allowed here; the reading layout still applies */ }
    A.app.render({ keepScroll: true });
  }

  A.views.report = {
    fitPages,
    render(ctx) {
      const { U, eng, S } = ctx;
      if (!eng) return '<div class="sheet empty">Start or open an engagement first.</div>';
      if (!Object.keys(eng.scope.platforms).length) return '<div class="sheet empty">Select the AI estate in Scope first.</div>';
      const o = S.ui.report || {};
      const fit = o.fit || 'auto';
      const reading = document.documentElement.classList.contains('reading');
      const modes = [['auto', 'Auto'], ['width', 'Fit width'], ['spread', 'Two pages'], ['actual', '100%']];
      return '<div class="page-head no-print"><div><span class="eyebrow">Step 6</span><h1>Client report</h1><p>Generated from the assessed results. Print it to PDF, or export a standalone HTML copy for the case file.</p></div></div>' +
        '<div class="report-tools"><button class="btn primary" data-action="print">' + U.icon('print') + 'Print or save as PDF</button><button class="btn" data-action="export-report">' + U.icon('download') + 'Export report (HTML)</button>' +
        '<button class="toggle' + (o.appendix !== false ? ' on' : '') + '" data-action="report-opt" data-opt="appendix">Check register</button><button class="toggle' + (o.register !== false ? ' on' : '') + '" data-action="report-opt" data-opt="register">Evidence register</button>' +
        '<span class="spacer"></span><div class="seg zoom" role="radiogroup" aria-label="Page size">' + modes.map(m => '<button role="radio" aria-checked="' + (fit === m[0]) + '" class="' + (fit === m[0] ? 'on' : '') + '" data-action="report-fit" data-fit="' + m[0] + '">' + m[1] + '</button>').join('') + '</div>' +
        '<button class="btn" data-action="report-full">' + U.icon(reading ? 'x' : 'expand') + (reading ? 'Exit full screen' : 'Full screen') + '</button></div>' +
        renderPages(ctx, fit);
    },
    mount() { bindResize(); fitPages(); }
  };

  A.actions['report-fit'] = (el, ev, ctx) => { const o = ctx.S.ui.report || (ctx.S.ui.report = {}); o.fit = el.dataset.fit; ctx.S.saveUI(); ctx.render({ keepScroll: true }); };
  A.actions['report-full'] = () => { setReading(!document.documentElement.classList.contains('reading')); };
  A.actions['print'] = (el, ev, ctx) => { ctx.S.log('Report printed'); ctx.S.commit({ quiet: true }); window.print(); };
  A.actions['report-opt'] = (el, ev, ctx) => { const o = ctx.S.ui.report || (ctx.S.ui.report = {}); o[el.dataset.opt] = o[el.dataset.opt] === false; ctx.S.saveUI(); ctx.render({ keepScroll: true }); };
  A.actions['export-report'] = async (el, ev, ctx) => {
    const css = Array.prototype.map.call(document.querySelectorAll('style'), s => s.textContent).join('\n');
    const bar = '<div class="report-tools export-bar"><div class="seg zoom" role="radiogroup" aria-label="Page size"><button class="on" data-fit="auto">Auto</button><button data-fit="width">Fit width</button><button data-fit="spread">Two pages</button><button data-fit="actual">100%</button></div></div>';
    const script = '<script>(function(){var fit=' + fitPages.toString() + ';var bar=document.querySelector(".export-bar");bar.addEventListener("click",function(e){var b=e.target.closest("[data-fit]");if(!b)return;var s=document.querySelector(".paper-stack");s.setAttribute("data-fit",b.getAttribute("data-fit"));s.className="paper-stack fit-"+b.getAttribute("data-fit");Array.prototype.forEach.call(bar.querySelectorAll("button"),function(x){x.classList.toggle("on",x===b);});fit();});window.addEventListener("resize",fit);fit();})();<\/script>';
    const html = '<!doctype html><html lang="en" data-theme="light"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>' + ctx.U.esc((ctx.eng.meta.client || 'Client') + ' AI forensic readiness report') + '</title><style>' + css + '\n@media screen{body{background:#e6e9ef}.view{max-width:none;padding-block:12px 24px}}</style></head><body><div class="view view-report">' + bar + renderPages(ctx, 'auto') + '</div>' + script + '</body></html>';
    const sha = await ctx.U.sha256(html);
    ctx.U.download(ctx.S.fileName('_report.html'), html, 'text/html');
    ctx.S.log('Report exported (SHA-256 ' + sha + ')');
    ctx.S.commit({ quiet: true });
    ctx.U.toast('Report exported. SHA-256 recorded in the activity log.');
  };
})(typeof window !== 'undefined' ? window : globalThis);
