/* Overview: welcome screen without an engagement; engagement dashboard with one. */
(function (root) {
  'use strict';
  const A = root.AIFR;
  A.views = A.views || {};
  A.actions = A.actions || {};

  function welcome(ctx) {
    const U = ctx.U, kb = ctx.idx.kb;
    const nC = kb.platforms.reduce((a, p) => a + p.controls.length, 0);
    const nAuto = kb.platforms.reduce((a, p) => a + p.controls.filter(c => c.method === 'auto').length, 0);
    const steps = [
      ['Scope', 'Select the AI estate, jurisdictions and evidence target.'],
      ['Runbook', 'Get a tailored field plan: access, collectors, checks, sampling.'],
      ['Evidence', 'Import collector bundles. Every file is hashed on receipt.'],
      ['Assess', 'Decide each check with evidence. Paste output for a suggested verdict.'],
      ['Results', 'Readiness levels, scenarios, coverage, lookback and roadmap.'],
      ['Report', 'Issue the client report and the engagement file.']
    ];
    return '<div class="sheet hero"><span class="eyebrow">AI Forensic Readiness Assessment</span>' +
      '<h1>If an AI system is misused tomorrow, can you prove what happened?</h1>' +
      '<p>The Workbench runs the assessment end to end. It covers what each AI platform records, what is switched off, how long it lasts, who can delete it, and what an investigator could actually retrieve. Everything stays on this machine. Nothing is sent anywhere.</p>' +
      '<div class="row"><button class="btn primary" data-action="new-engagement">' + U.icon('plus') + 'Start a new engagement</button>' +
      '<button class="btn" data-action="load-sample">Open the sample engagement</button>' +
      '<label class="btn">' + U.icon('upload') + 'Open an engagement file<input type="file" accept=".json" data-action-change="open-file" hidden></label></div></div>' +
      '<div class="sheet section steps-strip">' + steps.map((s, i) => '<div><div class="n">0' + (i + 1) + '</div><div class="t">' + s[0] + '</div><div class="d">' + s[1] + '</div></div>').join('') + '</div>' +
      '<div class="section"><h2>Four questions decide every platform</h2><p class="lede">Each AI system in the estate is tested against the same four questions before anything else.</p>' +
      '<div class="sheet questions">' + kb.keys.map(k => '<div><div class="kid">' + k.id + '</div><div class="kq">' + U.esc(k.label) + '</div><div class="kd">' + U.esc(k.desc) + '</div></div>').join('') + '</div></div>' +
      '<div class="section grid g4">' +
      tile('Platforms covered', kb.platforms.length, 'Workplace, coding, cloud, internal and foundations') +
      tile('Checks', nC, nAuto + ' automated by collectors') +
      tile('Incident scenarios', kb.scenarios.length, 'Investigator questions tested against the estate') +
      tile('Framework references', kb.refs.length, 'ISO 27001/42001, NIST, EU AI Act, CERT-In, DPDP, BSA') + '</div>' +
      '<p class="xs muted" style="margin-top:14px">Knowledge base ' + U.esc(kb.kb_version) + ', research current to ' + U.fmtDate(kb.kb_date) + '. Vendor behaviour changes quickly: each platform in the Library shows its sources and how confident the research is.</p>';
  }

  function tile(label, value, note) {
    return '<div class="sheet kpi"><span class="k-label">' + label + '</span><span class="k-value num">' + value + '</span><span class="k-note">' + note + '</span></div>';
  }

  function dashboard(ctx) {
    const { U, E, idx, eng, C } = ctx;
    const sum = E.summary(idx, eng);
    const kg = E.keyGrid(idx, eng);
    const lad = E.ladder(idx, eng);
    const f = E.findings(idx, eng).slice(0, 6);
    const pr = sum.progress;
    const m = eng.meta;
    const by = pr.by;
    const bar = ['met', 'partial', 'unverified', 'gap'].map(s => '<span style="width:' + (pr.total ? by[s] / pr.total * 100 : 0) + '%;background:var(--' + ({ met: 'good-mark', partial: 'warn-mark', unverified: 'warn-mark', gap: 'bad-mark' }[s]) + ')"></span>').join('');
    let h = '<div class="page-head"><div><span class="eyebrow">' + U.esc(m.ref || 'Engagement') + '</span><h1>' + U.esc(m.client || 'Untitled engagement') + '</h1>' +
      (m.objective ? '<p>' + U.esc(m.objective) + '</p>' : '') + '</div>' +
      '<div class="row"><button class="btn" data-action="go" data-view="assess">Continue assessing</button><button class="btn primary" data-action="go" data-view="report">Open report</button></div></div>';
    if (!Object.keys(eng.scope.platforms).length) {
      return h + '<div class="sheet empty"><p>No platforms are in scope yet.</p><p style="margin-top:10px"><button class="btn primary" data-action="go" data-view="scope">Define the scope</button></p></div>';
    }
    h += '<div class="grid g4">' +
      '<div class="sheet kpi"><span class="k-label">Checks assessed</span><span class="k-value num">' + pr.assessed + '<small> / ' + pr.total + '</small></span><div class="progress-bar" style="margin-top:6px">' + bar + '</div><span class="k-note">' + by.met + ' met · ' + by.partial + ' partial · ' + by.gap + ' gaps</span></div>' +
      '<div class="sheet kpi"><span class="k-label">Median readiness</span><span class="k-value">' + (sum.median == null ? '–' : 'L' + fmtL(sum.median)) + '<small> → L' + fmtL(sum.achievableMedian) + '</small></span><span class="k-note">Now, and reachable by configuration alone</span></div>' +
      '<div class="sheet kpi"><span class="k-label">Scenarios fully answerable</span><span class="k-value num">' + sum.scenariosFull + '<small> / ' + sum.scenarios + '</small></span><span class="k-note">' + sum.questionsYes + ' of ' + sum.questions + ' investigator questions answerable</span></div>' +
      '<div class="sheet kpi"><span class="k-label">Critical and high findings</span><span class="k-value num">' + (sum.bySev.critical + sum.bySev.high) + '</span><span class="k-note">' + sum.bySev.critical + ' critical · ' + sum.bySev.high + ' high · ' + sum.findings + ' in total</span></div></div>';
    h += '<div class="section"><h2>The four questions</h2><p class="lede">Platforms in scope that pass each question today.</p><div class="sheet questions">' +
      idx.kb.keys.map(k => { const t = kg.totals[k.id]; return '<div><div class="kid">' + k.id + '</div><div class="kq">' + U.esc(k.label) + '</div><div class="kval"><b class="num" style="font-size:22px">' + t.met + '</b> <span class="muted">of ' + t.total + ' platforms</span></div><div class="kd">' + (t.gap ? U.plural(t.gap, 'platform') + ' failing' : 'No failures recorded') + (t.open ? ', ' + t.open + ' open' : '') + '</div></div>'; }).join('') + '</div></div>';
    h += '<div class="section grid g2"><div class="sheet"><div class="sheet-head"><h3>Readiness by platform</h3><button class="btn ghost sm" data-action="go" data-view="results">Full results</button></div><div class="sheet-body">' +
      '<table class="tbl"><tbody>' + lad.map(r => '<tr class="click" data-action="go-platform" data-pid="' + r.pid + '"><td style="width:46px">' + U.lvl(r.level) + '</td><td><b>' + U.esc(r.name) + '</b><div class="xs muted">' + U.esc(C.LEVEL_SHORT[r.level]) + (r.achievable > r.level ? ' · reachable L' + r.achievable : '') + '</div></td></tr>').join('') + '</tbody></table></div></div>' +
      '<div class="sheet"><div class="sheet-head"><h3>Highest-priority findings</h3><button class="btn ghost sm" data-action="go" data-view="results" data-anchor="findings">All findings</button></div><div class="sheet-body" style="padding-top:4px">' +
      (f.length ? f.map(x => '<div class="rm-item click" data-action="open-control" data-cid="' + x.id + '" style="cursor:pointer;padding-left:0;padding-right:0"><span class="rmt">' + U.esc(x.title) + '</span><span class="rmm">' + U.sevTag(x.severity) + '<span class="mono">' + x.id + '</span><span>' + U.esc(x.platform) + '</span></span></div>').join('') : '<div class="empty">No findings yet.</div>') + '</div></div></div>';
    const nextSteps = [];
    if (pr.total - pr.assessed) nextSteps.push(['assess', U.plural(pr.total - pr.assessed, 'check') + ' not yet assessed']);
    if (!eng.bundles.length) nextSteps.push(['collect', 'No collector bundles imported yet']);
    const rbOpen = ctx.A.views.runbook.openCount(ctx);
    if (rbOpen) nextSteps.push(['runbook', U.plural(rbOpen, 'runbook step') + ' still open']);
    if (!nextSteps.length) nextSteps.push(['report', 'Assessment complete. Review and issue the report.']);
    h += '<div class="section grid g2"><div class="sheet"><div class="sheet-head"><h3>Next steps</h3></div><div class="sheet-body"><ul class="bul">' + nextSteps.map(n => '<li><a href="#" data-action="go" data-view="' + n[0] + '">' + U.esc(n[1]) + '</a></li>').join('') + '</ul></div></div>' +
      '<div class="sheet"><div class="sheet-head"><h3>Engagement activity</h3><span class="sub">Kept in the engagement file</span></div><div class="sheet-body" style="max-height:220px;overflow:auto"><table class="tbl"><tbody>' +
      eng.log.slice(-10).reverse().map(l => '<tr><td class="xs muted num" style="white-space:nowrap">' + U.fmtDateTime(l.at) + '</td><td class="small">' + U.esc(l.action) + '<div class="xs muted">' + U.esc(l.by) + '</div></td></tr>').join('') + '</tbody></table></div></div></div>';
    return h;
  }

  function fmtL(n) { return n == null ? '–' : (Math.round(n * 10) / 10).toString(); }

  A.views.overview = {
    render(ctx) { return ctx.eng ? dashboard(ctx) : welcome(ctx); }
  };
})(typeof window !== 'undefined' ? window : globalThis);
