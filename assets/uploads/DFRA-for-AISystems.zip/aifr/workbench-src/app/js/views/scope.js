/* Scope: engagement details, context that sets the evidence target, and the AI estate. */
(function (root) {
  'use strict';
  const A = root.AIFR;

  function field(id, label, value, opts) {
    opts = opts || {};
    const U = A.util;
    const input = opts.type === 'textarea'
      ? '<textarea class="input" id="m-' + id + '" data-bind="meta.' + id + '" rows="3">' + U.esc(value) + '</textarea>'
      : '<input class="input" id="m-' + id + '" data-bind="meta.' + id + '" type="' + (opts.type || 'text') + '" value="' + U.esc(value) + '"' + (opts.ph ? ' placeholder="' + U.esc(opts.ph) + '"' : '') + '>';
    return '<div class="field' + (opts.cls ? ' ' + opts.cls : '') + '"><label for="m-' + id + '">' + label + '</label>' + input + (opts.hint ? '<span class="hint">' + opts.hint + '</span>' : '') + '</div>';
  }

  function capbar(p, idx) {
    return '<div class="capbar" title="Evidence the vendor provides: green native, blue needs configuration, amber partial, red not available">' + idx.evidenceIds.map(e => '<span class="cap-' + (p.evidence[e] || 'na') + '" data-tip="' + e + ' ' + idx.kb.evidence.find(x => x.id === e).label + ': ' + (p.evidence[e] || 'na') + '"></span>').join('') + '</div>';
  }

  A.views.scope = {
    render(ctx) {
      const { U, E, idx, eng } = ctx;
      if (!eng) return '<div class="sheet empty">Start or open an engagement first.<p style="margin-top:10px"><button class="btn primary" data-action="new-engagement">Start a new engagement</button></p></div>';
      const m = eng.meta;
      const floors = E.floorsFor(idx, eng);
      const floorMax = floors.length ? Math.max.apply(null, floors.map(f => f.days)) : 0;
      let h = '<div class="page-head"><div><span class="eyebrow">Step 1</span><h1>Scope the engagement</h1><p>Engagement details appear on the report cover. The AI estate you select drives the runbook, the checks and the scoring.</p></div></div>';
      h += '<div class="sheet"><div class="sheet-head"><h2>Engagement</h2></div><div class="sheet-body grid g3">' +
        field('client', 'Client', m.client, { ph: 'Organisation name' }) +
        field('ref', 'Engagement reference', m.ref) +
        field('firm', 'Prepared by', m.firm, { ph: 'Your practice or firm', hint: 'Shown on the report cover and footer.' }) +
        field('lead', 'Engagement lead', m.lead) +
        field('team', 'Team', m.team) +
        field('classification', 'Classification', m.classification) +
        field('start', 'Fieldwork start', m.start, { type: 'date' }) +
        field('end', 'Fieldwork end', m.end, { type: 'date' }) +
        '<div class="field"><label for="m-sector">Sector</label><select class="input" id="m-sector" data-bind-change="meta.sector"><option value="">Select…</option>' + idx.kb.sectors.map(s => '<option value="' + s.id + '"' + (m.sector === s.id ? ' selected' : '') + '>' + U.esc(s.label) + '</option>').join('') + '</select></div>' +
        field('objective', 'Objective', m.objective, { type: 'textarea', cls: 'full', ph: 'What the client needs to know at the end of this engagement' }) +
        '</div></div>';
      h += '<div class="sheet section"><div class="sheet-head"><h2>Evidence target</h2><span class="sub">Sets the lookback each source is measured against</span></div><div class="sheet-body grid g3">' +
        '<div class="field"><span class="flabel">Jurisdictions</span><div class="toggle-set">' + idx.kb.jurisdictions.map(j => '<button class="toggle' + (m.jurisdictions.indexOf(j.id) >= 0 ? ' on' : '') + '" data-action="toggle-jur" data-id="' + j.id + '">' + U.esc(j.label) + '</button>').join('') + '</div></div>' +
        field('targetDays', 'Target lookback (days)', m.targetDays, { type: 'number', hint: floorMax ? 'Legal floors for this scope reach ' + floorMax + ' days. One year (365) is the recommended working target.' : 'One year (365) is the recommended working target.' }) +
        '<div class="field"><span class="flabel">Floors that apply</span>' + (floors.length ? '<ul class="bul">' + floors.map(f => '<li><b>' + U.esc(f.label) + '</b>: ' + f.days + ' days. <span class="muted">' + U.esc(f.note) + '</span></li>').join('') + '</ul>' : '<span class="muted small">Select jurisdictions and sector to list them.</span>') + '</div>' +
        field('employees', 'Employees', m.employees, { type: 'number' }) +
        field('endpoints', 'Endpoints', m.endpoints, { type: 'number', hint: 'Used to size the endpoint collection sample.' }) +
        '</div></div>';
      const n = Object.keys(eng.scope.platforms).length;
      h += '<div class="section"><div class="page-head" style="margin-bottom:0"><div><h2 style="font-size:var(--fs-xl)">AI estate</h2><p>' + U.plural(n, 'platform') + ' in scope. Select what the organisation runs, including tools in pilot or found through discovery. Pick the licence or deployment variant where it changes what can be logged.</p></div>' +
        '<div class="row"><button class="btn sm" data-action="scope-foundations">Add all foundations</button></div></div>';
      idx.kb.categories.forEach(cat => {
        const ps = idx.kb.platforms.filter(p => p.category === cat.id);
        const on = ps.filter(p => eng.scope.platforms[p.id]).length;
        h += '<div class="cat-head"><h3>' + U.esc(cat.label) + '</h3><span class="xs muted">' + on + ' of ' + ps.length + ' selected</span></div><div class="pcards">';
        ps.forEach(p => {
          const sp = eng.scope.platforms[p.id];
          h += '<div class="pcard' + (sp ? ' on' : '') + '" data-action="toggle-platform" data-pid="' + p.id + '" role="checkbox" aria-checked="' + (sp ? 'true' : 'false') + '" tabindex="0">' +
            '<div class="top"><span class="check"></span><div style="min-width:0"><div class="pn">' + U.esc(p.name) + '</div><div class="pv">' + U.esc(p.vendor) + ' · ' + p.controls.length + ' checks · <span class="conf conf-' + p.confidence + '">' + ({ vendor: 'vendor-sourced', mixed: 'mixed sources', secondary: 'verify' }[p.confidence]) + '</span></div></div></div>' +
            '<div class="ps">' + U.esc(p.summary) + '</div>' + capbar(p, idx);
          if (sp) {
            h += '<div class="opts" data-stop="1">' +
              (p.variants.length ? '<select class="input" data-scope="' + p.id + '" data-field="variant" aria-label="Variant"><option value="">Variant not known</option>' + p.variants.map(v => '<option value="' + v.id + '"' + (sp.variant === v.id ? ' selected' : '') + '>' + U.esc(v.label) + '</option>').join('') + '</select>' : '<span class="xs muted" style="align-self:center">No variants</span>') +
              '<input class="input" data-scope="' + p.id + '" data-field="owner" placeholder="Client owner" value="' + U.esc(sp.owner || '') + '" aria-label="Client owner"></div>';
          }
          h += '</div>';
        });
        h += '</div>';
      });
      h += '</div>';
      return h;
    }
  };

  A.actions['toggle-platform'] = (el, ev, ctx) => {
    if (ev.target.closest('[data-stop]')) return;
    ctx.S.toggleScope(el.dataset.pid);
  };
  A.actions['toggle-jur'] = (el, ev, ctx) => {
    const j = ctx.eng.meta.jurisdictions, id = el.dataset.id;
    const i = j.indexOf(id);
    if (i >= 0) j.splice(i, 1); else j.push(id);
    ctx.S.commit();
  };
  A.actions['scope-foundations'] = (el, ev, ctx) => {
    ctx.idx.kb.platforms.filter(p => p.category === 'foundation').forEach(p => { if (!ctx.eng.scope.platforms[p.id]) ctx.eng.scope.platforms[p.id] = { variant: '', owner: '', notes: '' }; });
    ctx.S.log('Added all foundations to scope');
    ctx.S.commit();
  };
})(typeof window !== 'undefined' ? window : globalThis);
