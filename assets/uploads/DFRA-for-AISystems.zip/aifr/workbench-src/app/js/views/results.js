/* Results: the analytical picture, summary first. */
(function (root) {
  'use strict';
  const A = root.AIFR;

  /* Plain-language verdict built from the numbers, used here and in the report. */
  function verdict(ctx) {
    const { E, idx, eng } = ctx;
    const s = E.summary(idx, eng);
    const n = s.platforms;
    if (!n) return { text: 'No AI platforms are in scope yet.', s };
    const who = s.atLeast[1], what = s.atLeast[2], keep = s.atLeast[3];
    let text = 'Of ' + n + ' AI platforms assessed, ' + who + ' can show who used them and when, ' + what + ' can show what was asked and answered, and ' + keep + ' keep that content long enough and safely enough to rely on in an investigation.';
    if (s.scenarios) text += ' ' + s.scenariosFull + ' of ' + s.scenarios + ' incident scenarios can be fully investigated today.';
    if (s.achievableMedian != null && s.median != null && s.achievableMedian > s.median) text += ' Configuration changes alone would lift the median platform from Level ' + fmt(s.median) + ' to Level ' + fmt(s.achievableMedian) + '.';
    return { text, s };
  }
  function fmt(n) { return (Math.round(n * 10) / 10).toString(); }

  function matrixRows(ctx) {
    const { E, idx, eng } = ctx;
    return E.scopedIds(idx, eng).filter(pid => ['governance-ir', 'central-logging', 'identity'].indexOf(pid) < 0)
      .map(pid => ({ pid, name: idx.platforms[pid].short, ev: E.evidenceRow(idx, eng, pid, 'actual') }));
  }

  A.views.results = {
    verdict, matrixRows,
    render(ctx) {
      const { U, E, C, idx, eng } = ctx;
      if (!eng) return '<div class="sheet empty">Start or open an engagement first.</div>';
      if (!Object.keys(eng.scope.platforms).length) return '<div class="sheet empty">Select the AI estate in Scope first.</div>';
      const v = verdict(ctx), s = v.s;
      const lad = E.ladder(idx, eng);
      const sc = E.scenarios(idx, eng);
      const f = E.findings(idx, eng);
      const sevF = ctx.S.ui.sevFilter || '';
      let h = '<div class="page-head"><div><span class="eyebrow">Step 5</span><h1>Results</h1><p>Scores follow the assessed results live. Every number links back to the checks behind it.</p></div>' +
        '<div class="row"><button class="btn" data-action="export-findings">' + U.icon('download') + 'Findings (CSV)</button><button class="btn primary" data-action="go" data-view="report">Open report</button></div></div>';
      h += '<div class="sheet" style="padding:18px 22px;margin-bottom:16px"><span class="eyebrow">Verdict</span><p style="font-family:var(--font-display);font-size:19px;line-height:1.45;margin-top:6px;max-width:95ch">' + U.esc(v.text) + '</p></div>';
      h += '<div class="grid g4">' +
        '<div class="sheet kpi"><span class="k-label">Median level</span><span class="k-value">L' + (s.median == null ? '–' : fmt(s.median)) + '<small> → L' + (s.achievableMedian == null ? '–' : fmt(s.achievableMedian)) + '</small></span><span class="k-note">Lowest: L' + (s.min == null ? '–' : s.min) + ' (' + U.esc(s.weakest.slice(0, 3).join(', ')) + ')</span></div>' +
        '<div class="sheet kpi"><span class="k-label">Content retrievable</span><span class="k-value num">' + s.atLeast[2] + '<small> / ' + s.platforms + '</small></span><span class="k-note">Platforms at Level 2 or above</span></div>' +
        '<div class="sheet kpi"><span class="k-label">Scenarios answerable</span><span class="k-value num">' + s.scenariosFull + '<small> / ' + s.scenarios + '</small></span><span class="k-note">' + s.questionsYes + ' of ' + s.questions + ' investigator questions</span></div>' +
        '<div class="sheet kpi"><span class="k-label">Findings</span><span class="k-value num">' + s.findings + '</span><span class="k-note">' + s.bySev.critical + ' critical · ' + s.bySev.high + ' high · ' + s.bySev.medium + ' medium · ' + s.bySev.low + ' low</span></div></div>';
      h += '<div class="section"><h2>Readiness by platform</h2><p class="lede">Each platform is scored by its weakest in-scope surface. Filled cells show the level reached; dashed cells show what configuration changes alone would reach.</p><div class="sheet sheet-body">' + C.ladder(lad, { link: true }) + '</div></div>';
      h += '<div class="section"><h2>The four questions</h2><p class="lede">Every platform answers the same four questions. These decide most of the score.</p><div class="sheet sheet-body">' + C.keyGrid(idx, E.keyGrid(idx, eng)) + '</div></div>';
      h += '<div class="section"><h2>Investigation scenarios</h2><p class="lede">Could investigators answer these questions today, on every platform where the incident could happen? Endpoint, identity and network sources count where they can stand in.</p><div class="grid g2">' + C.scenarioCards(sc, { expand: true }) + '</div></div>';
      h += '<div class="section"><h2>Evidence coverage</h2><p class="lede">The twelve evidence items an investigator needs, per platform, as configured in this estate (not as the vendor advertises).</p><div class="sheet sheet-body">' + C.matrix(idx, matrixRows(ctx)) + '</div></div>';
      h += '<div class="section"><h2>Lookback</h2><p class="lede">How far back each evidence source reaches, against the engagement target and the legal floors that apply. Logging is never retroactive: coverage also starts on the day it was switched on.</p><div class="sheet sheet-body">' + C.horizon(E.horizon(idx, eng)) + '</div></div>';
      h += '<div class="section"><h2>Target state</h2><p class="lede">The evidence architecture this estate needs, and how much of each part is in place. Hover a component for detail.</p><div class="sheet sheet-body">' + C.architecture(idx, eng, E.components(idx, eng), E.scopedIds(idx, eng)) + '</div></div>';
      h += '<div class="section"><h2>Capability domains</h2><p class="lede">Weighted share of checks met in each domain.</p><div class="sheet sheet-body dgrid">' + C.domainBars(E.domains(idx, eng)) + '</div></div>';
      h += '<div class="section"><h2>Remediation roadmap</h2><p class="lede">Ordered by forensic value and effort. Logging is not retroactive: each week a gap stays open is a week that can never be investigated.</p>' + C.roadmap(E.roadmap(idx, eng), { link: true, limit: 10 }) + '</div>';
      const shown = sevF ? f.filter(x => x.severity === sevF) : f;
      h += '<div class="section" id="findings"><div class="row" style="justify-content:space-between"><h2>Findings</h2><div class="toggle-set">' + ['', 'critical', 'high', 'medium', 'low'].map(x => '<button class="toggle' + (sevF === x ? ' on' : '') + '" data-action="sev-filter" data-sev="' + x + '">' + (x ? x[0].toUpperCase() + x.slice(1) + ' (' + s.bySev[x] + ')' : 'All (' + f.length + ')') + '</button>').join('') + '</div></div><div class="sheet" style="margin-top:10px">' + C.findingsTable(shown) + '</div></div>';
      return h;
    }
  };

  A.actions['sev-filter'] = (el, ev, ctx) => { ctx.S.ui.sevFilter = el.dataset.sev; ctx.S.saveUI(); ctx.render({ keepScroll: true }); };
  A.actions['export-findings'] = (el, ev, ctx) => {
    const f = ctx.E.findings(ctx.idx, ctx.eng);
    const q = v => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"';
    const rows = [['Severity', 'Check', 'Platform', 'Key question', 'Finding', 'Status', 'Observation', 'Forensic impact', 'Remediation', 'Effort', 'Owner', 'Window', 'References']];
    f.forEach(x => rows.push([x.severity, x.id, x.platform, x.key, x.title, x.status, x.note, x.impact, x.fix, x.effort, x.owner, { P1: '0-30 days', P2: '31-90 days', P3: '90+ days' }[x.phase], x.refs.map(r => ctx.idx.refs[r].fw + ' ' + ctx.idx.refs[r].ref).join('; ')]));
    ctx.U.download(ctx.S.fileName('_findings.csv'), '﻿' + rows.map(r => r.map(q).join(',')).join('\r\n'), 'text/csv');
    ctx.U.toast('Findings exported');
  };
})(typeof window !== 'undefined' ? window : globalThis);
