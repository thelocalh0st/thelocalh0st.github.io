/* Library: platform research reference, evidence model, scenarios, references and method. */
(function (root) {
  'use strict';
  const A = root.AIFR;
  const CAP_LABEL = { native: 'Native', config: 'Needs configuration', partial: 'Partial', none: 'Not available', na: 'Not applicable' };
  const LAYER = { server: 'Server / cloud', endpoint: 'Endpoint', network: 'Network', identity: 'Identity' };

  function platformDetail(ctx, p) {
    const { U, idx } = ctx;
    const ev = idx.kb.evidence;
    let h = '<div class="sheet"><div class="detail-head"><span class="eyebrow">' + U.esc(idx.kb.categories.find(c => c.id === p.category).label) + ' · ' + U.esc(p.vendor) + '</span><h2>' + U.esc(p.name) + '</h2>' +
      '<div class="row" style="margin-top:8px"><span class="conf conf-' + p.confidence + '">' + ({ vendor: 'Vendor documentation', mixed: 'Vendor and practitioner sources', secondary: 'Secondary sources: verify in fieldwork' }[p.confidence]) + '</span><span class="xs muted">Research current to ' + U.fmtDate(idx.kb.kb_date) + '</span></div></div><div class="detail-body">';
    h += '<p style="font-size:15px;line-height:1.55">' + U.esc(p.summary) + '</p>';
    h += '<div><div class="block-title">What the vendor can provide</div><div class="tbl-wrap"><table class="matrix"><tr>' + ev.map(e => '<th data-tip="' + U.esc(e.q) + '">' + e.id + '<br><span style="font-weight:500">' + U.esc(e.label) + '</span></th>').join('') + '</tr><tr>' +
      ev.map(e => { const c = p.evidence[e.id]; const cls = { native: 'ok', config: 'unknown', partial: 'partial', none: 'none', na: 'na' }[c]; return '<td class="cell ev-' + cls + '" data-tip="' + U.esc(e.label + ': ' + CAP_LABEL[c]) + '">' + ({ native: '✓', config: '◇', partial: '◐', none: '', na: '·' }[c]) + '</td>'; }).join('') + '</tr></table></div>' +
      '<div class="legend" style="margin-top:6px"><span>✓ native</span><span>◇ needs configuration</span><span>◐ partial</span><span>hatched: not available at any configuration</span></div></div>';
    if ((p.sources || []).length) h += '<div><div class="block-title">What is recorded, where, and for how long</div><div class="tbl-wrap"><table class="tbl"><thead><tr><th>Source</th><th>Layer</th><th>Holds</th><th>Default</th><th>Retention</th><th>Access</th></tr></thead><tbody>' +
      p.sources.map(s => '<tr><td><b>' + U.esc(s.name) + '</b></td><td class="small">' + U.esc(LAYER[s.layer] || s.layer) + '</td><td class="small">' + U.esc({ content: 'Content', metadata: 'Metadata only', mixed: 'Mixed' }[s.content] || s.content) + '</td><td>' + ({ on: U.statusChip('met', 'On'), off: U.statusChip('gap', 'Off'), 'opt-in': U.statusChip('partial', 'Opt-in'), mixed: U.statusChip('na', 'Varies'), 'n/a': U.statusChip('na', 'n/a') }[s.default] || U.esc(s.default)) + '</td><td class="small">' + U.esc(s.retention) + '</td><td class="small muted">' + U.esc(s.where || '') + '</td></tr>').join('') + '</tbody></table></div></div>';
    h += '<div class="grid g2"><div><div class="block-title">Known gaps</div><ul class="bul">' + p.gaps.map(g => '<li>' + U.esc(g) + '</li>').join('') + '</ul></div><div><div class="block-title">What good looks like</div><ul class="bul">' + p.target.map(g => '<li>' + U.esc(g) + '</li>').join('') + '</ul></div></div>';
    if ((p.access || []).length) h += '<div><div class="block-title">Access the assessor needs</div><table class="tbl"><tbody>' + p.access.map(a => '<tr><td><b>' + U.esc(a.role) + '</b></td><td class="muted">' + U.esc(a.purpose) + '</td></tr>').join('') + '</tbody></table></div>';
    h += '<div><div class="block-title">Checks (' + p.controls.length + ')</div><table class="tbl"><tbody>' + p.controls.map(c => '<tr><td class="id">' + c.id + '</td><td>' + U.esc(c.title) + ' ' + (c.key ? '<span class="tag key">' + c.key + '</span>' : '') + '</td><td>' + U.method(c.method) + '</td></tr>').join('') + '</tbody></table></div>';
    h += '<div><div class="block-title">Sources</div><div class="src-list">' + (p.refs_src || []).map(r => '<div><span class="conf conf-' + (r.k === 'vendor' ? 'vendor' : 'secondary') + '">' + (r.k === 'vendor' ? 'Vendor' : 'Secondary') + '</span> <a href="' + U.esc(r.u) + '" target="_blank" rel="noopener noreferrer">' + U.esc(r.t) + '</a></div>').join('') + '</div></div>';
    return h + '</div></div>';
  }

  function platformsTab(ctx) {
    const { U, idx, S } = ctx;
    const q = (S.ui.libQ || '').toLowerCase();
    const list = idx.kb.platforms.filter(p => !q || (p.name + ' ' + p.vendor + ' ' + p.summary).toLowerCase().indexOf(q) >= 0);
    const cur = idx.platforms[S.ui.libSel] || list[0];
    let h = '<div class="lib"><div class="sheet" style="overflow:hidden"><div style="padding:10px"><input class="input" type="search" placeholder="Search platforms" value="' + U.esc(S.ui.libQ || '') + '" data-libq="1" aria-label="Search platforms"></div><div class="lib-list">';
    idx.kb.categories.forEach(cat => {
      const ps = list.filter(p => p.category === cat.id);
      if (!ps.length) return;
      h += '<div class="cgroup"><span>' + U.esc(cat.label) + '</span><span>' + ps.length + '</span></div>';
      ps.forEach(p => { h += '<button class="' + (cur && cur.id === p.id ? 'sel' : '') + '" data-action="lib-select" data-pid="' + p.id + '"><div class="ln1">' + U.esc(p.name) + '</div><div class="ln2">' + U.esc(p.vendor) + ' · ' + p.controls.length + ' checks</div></button>'; });
    });
    h += '</div></div>' + (cur ? platformDetail(ctx, cur) : '<div class="sheet empty">No platform matches.</div>') + '</div>';
    return h;
  }

  function evidenceTab(ctx) {
    const { U, idx } = ctx;
    return '<div class="sheet"><table class="tbl"><thead><tr><th>Item</th><th>Question</th><th>What it is</th><th>Natively available on</th></tr></thead><tbody>' +
      idx.kb.evidence.map(e => {
        const nat = idx.kb.platforms.filter(p => p.category !== 'foundation' && p.evidence[e.id] === 'native').length;
        const tot = idx.kb.platforms.filter(p => p.category !== 'foundation' && p.evidence[e.id] !== 'na').length;
        return '<tr><td class="mono"><b>' + e.id + '</b> ' + U.esc(e.label) + '</td><td>' + U.esc(e.q) + '</td><td class="muted">' + U.esc(e.desc) + '</td><td class="num">' + nat + ' of ' + tot + ' AI platforms</td></tr>';
      }).join('') + '</tbody></table></div><p class="xs muted" style="margin-top:8px">Counts are vendor defaults across the knowledge base, before any configuration. Content items (E3 to E6) are native almost nowhere.</p>';
  }

  function scenariosTab(ctx) {
    const { U, idx } = ctx;
    return '<div class="grid g2">' + idx.kb.scenarios.map(s => '<div class="sheet scard"><span class="eyebrow">' + s.id + '</span><h3>' + U.esc(s.title) + '</h3><p class="small muted">' + U.esc(s.narrative) + '</p>' +
      s.questions.map(q => '<div class="qrow"><span class="qmark q-na">?</span><div>' + U.esc(q.q) + '</div><span class="xs muted">' + q.needs.join(' ') + '</span></div>').join('') +
      '<div class="row" style="margin-top:6px">' + s.refs.map(r => '<span class="tag">' + U.esc(idx.frameworks[idx.refs[r].fw].name.split(' (')[0] + ' ' + idx.refs[r].ref) + '</span>').join('') + '</div></div>').join('') + '</div>';
  }

  function refsTab(ctx) {
    const { U, idx } = ctx;
    return idx.kb.frameworks.map(f => {
      const refs = idx.kb.refs.filter(r => r.fw === f.id);
      const used = refs.map(r => ({ r, n: idx.kb.platforms.reduce((a, p) => a + p.controls.filter(c => (c.refs || []).indexOf(r.id) >= 0).length, 0) }));
      return '<div class="sheet" style="margin-bottom:12px"><div class="sheet-head"><h3>' + U.esc(f.name) + '</h3><span class="tag">' + f.kind + '</span></div><table class="tbl"><tbody>' + used.map(x => '<tr><td class="mono" style="width:150px">' + U.esc(x.r.ref) + '</td><td>' + U.esc(x.r.title) + '</td><td class="xs muted num" style="width:110px">' + U.plural(x.n, 'check') + '</td></tr>').join('') + '</tbody></table></div>';
    }).join('');
  }

  function methodTab(ctx) {
    const { U, idx } = ctx;
    const principles = [
      ['Prove it by retrieval', 'A setting is a claim; a retrieved record is evidence. Every platform gets a retrieval test at a set age, and the result is hashed.'],
      ['Read-only, always', 'Assessors never change client settings. Where a change is needed to test something, the client makes it through change control.'],
      ['Coverage has a start date', 'Logging is never retroactive. The date each control was switched on is recorded, because everything before it is lost.'],
      ['Name the trade-offs', 'Zero-retention and privacy modes are legitimate choices that remove evidence. The assessment makes each one an owned, documented decision with compensating capture.'],
      ['Measure blind spots, not people', 'Shadow AI is assessed through the organisation\'s own network, identity and endpoint telemetry. No personal account is ever accessed.'],
      ['Score the weakest surface', 'A platform scores by its weakest in-scope surface. An average would hide the gap that matters in an incident.']
    ];
    const phases = [
      ['Mobilise', 'Scope, legal approval for content sampling, evidence protocol, read-only access.', '2-3 days'],
      ['Discover', 'Collectors on endpoints, cloud and SaaS control planes, and network logs; AI inventory including shadow AI.', '2-4 days'],
      ['Verify configuration', 'Four questions and configuration checks per platform, with evidence for every verdict.', '3-5 days'],
      ['Prove retrieval', 'Retrieve real records at 7, 30, 90 days and the target age; hash and log each sample.', '1-2 days'],
      ['Interviews and tabletop', 'People, access, legal groundwork; walk the incident scenarios with responders.', '1-2 days'],
      ['Score, report, hand over', 'Levels, scenarios, coverage, lookback, roadmap with owners; schedule the drift re-run.', '2-3 days']
    ];
    return '<div class="grid g2"><div class="sheet"><div class="sheet-head"><h3>Principles</h3></div><div class="sheet-body">' + principles.map(p => '<div style="margin-bottom:12px"><b>' + U.esc(p[0]) + '</b><div class="small muted">' + U.esc(p[1]) + '</div></div>').join('') + '</div></div>' +
      '<div class="sheet"><div class="sheet-head"><h3>Engagement phases</h3><span class="sub">Indicative effort for 6 to 10 platforms</span></div><table class="tbl"><tbody>' + phases.map((p, i) => '<tr><td class="mono" style="width:36px;color:var(--accent);font-weight:700">P' + i + '</td><td><b>' + U.esc(p[0]) + '</b><div class="small muted">' + U.esc(p[1]) + '</div></td><td class="xs muted" style="white-space:nowrap">' + p[2] + '</td></tr>').join('') + '</tbody></table></div></div>' +
      '<div class="grid g2 section"><div class="sheet"><div class="sheet-head"><h3>Readiness levels</h3></div><table class="tbl"><tbody>' + idx.kb.levels.map(l => '<tr><td style="width:46px">' + U.lvl(l.n) + '</td><td><b>' + U.esc(l.label) + '</b><div class="small muted">' + U.esc(l.desc) + '</div></td></tr>').join('') + '</tbody></table><div class="sheet-body xs muted">Level 2 needs input and output content (and tool calls where the platform can capture them). Level 3 adds retention at target, protection from deletion and a passed retrieval test. A failed retrieval test caps a platform at Level 1.</div></div>' +
      '<div class="sheet"><div class="sheet-head"><h3>Severity</h3></div><div class="sheet-body small"><p>Each check carries a forensic weight (decisive, significant, supporting). Severity starts from that weight, rises one step for a failed key question (K1 to K4), and falls one step for a partial result or two for an unevidenced claim.</p><table class="tbl" style="margin-top:8px"><tbody><tr><td>' + U.sevTag('critical') + '</td><td>A key question fails on a decisive check: the evidence an investigation needs does not exist or can be destroyed.</td></tr><tr><td>' + U.sevTag('high') + '</td><td>A decisive check fails, or a key question is only partly met.</td></tr><tr><td>' + U.sevTag('medium') + '</td><td>A significant check fails, or a decisive check is partial.</td></tr><tr><td>' + U.sevTag('low') + '</td><td>Supporting checks and unevidenced claims.</td></tr></tbody></table><p style="margin-top:8px">Remediation windows: high-value, low-effort fixes in the first 30 days; larger changes in 31 to 90 days; architecture after 90 days.</p></div></div></div>' +
      '<div class="section"><h2>The four questions</h2><div class="sheet questions">' + idx.kb.keys.map(k => '<div><div class="kid">' + k.id + '</div><div class="kq">' + U.esc(k.label) + '</div><div class="kd">' + U.esc(k.desc) + '</div></div>').join('') + '</div></div>';
  }

  A.views.library = {
    render(ctx) {
      const { U, S } = ctx;
      const tab = S.ui.libTab || 'platforms';
      const tabs = [['platforms', 'Platforms'], ['evidence', 'Evidence model'], ['scenarios', 'Scenarios'], ['refs', 'References'], ['method', 'Method']];
      const body = { platforms: platformsTab, evidence: evidenceTab, scenarios: scenariosTab, refs: refsTab, method: methodTab }[tab](ctx);
      return '<div class="page-head"><div><span class="eyebrow">Reference</span><h1>Library</h1><p>The research behind every check: what each platform records, where, for how long, what is off by default, and how confident the research is.</p></div></div>' +
        '<div class="tabs" role="tablist">' + tabs.map(t => '<button role="tab" aria-selected="' + (tab === t[0]) + '" class="' + (tab === t[0] ? 'on' : '') + '" data-action="lib-tab" data-tab="' + t[0] + '">' + t[1] + '</button>').join('') + '</div>' + body;
    }
  };

  A.actions['lib-tab'] = (el, ev, ctx) => { ctx.S.ui.libTab = el.dataset.tab; ctx.S.saveUI(); ctx.render(); };
  A.actions['lib-select'] = (el, ev, ctx) => { ctx.S.ui.libSel = el.dataset.pid; ctx.S.saveUI(); ctx.render({ keepScroll: true }); };
})(typeof window !== 'undefined' ? window : globalThis);
