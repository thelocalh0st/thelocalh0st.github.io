/* Runbook: the field plan generated from the scoped estate. Exportable as a standalone document. */
(function (root) {
  'use strict';
  const A = root.AIFR;

  const CONFIG_ASPECTS = ['capture', 'coverage', 'void', 'retention', 'integrity', 'central'];

  function collectorItems(ctx) {
    const { idx, eng, E } = ctx;
    const scoped = E.scopedIds(idx, eng);
    const has = id => scoped.indexOf(id) >= 0;
    const anyCat = cat => scoped.some(pid => idx.platforms[pid].category === cat);
    const ref = (eng.meta.ref || 'engagement').replace(/[^A-Za-z0-9_-]/g, '');
    const items = [];
    if (has('endpoint-ai') || anyCat('coding')) items.push({
      id: 'col-endpoint', t: 'Run the endpoint collector across developer endpoints and a sample of business users',
      d: 'Inventories AI tools, local transcripts and their retention, MCP servers, local model runtimes, AI extensions and agentic browsers, process auditing and time sync. Read-only. Inventory mode never copies transcript content.',
      cmds: [['powershell', '# Windows: deploy via Intune or SCCM as SYSTEM to cover every profile\npowershell.exe -ExecutionPolicy Bypass -File .\\Invoke-AIFREndpointScan.ps1 -AllUsers -OutputPath "\\\\fileserver\\aifr$\\' + ref + '"'], ['bash', '# macOS and Linux\nsudo python3 -m aifr_collect endpoint --all-users --out ./evidence']]
    });
    if (has('m365-copilot') || has('copilot-studio')) items.push({
      id: 'col-m365', t: 'Run the Microsoft 365 collector', d: 'Reads audit ingestion, audit retention policies, retention policies, role groups and samples CopilotInteraction records. Needs Exchange Online and Security & Compliance PowerShell with read-only roles.',
      cmds: [['powershell', 'Connect-ExchangeOnline -UserPrincipalName reader@tenant.example\nConnect-IPPSSession -UserPrincipalName reader@tenant.example\n.\\Invoke-AIFRM365Collect.ps1 -OutputPath .\\evidence -SampleDays 30']]
    });
    if (has('aws-bedrock') || has('amazon-q-kiro')) items.push({ id: 'col-aws', t: 'Run the AWS collector', d: 'Bedrock invocation logging per Region, log group retention, Object Lock, CloudTrail trails and Bedrock data events. Uses the AWS CLI under a SecurityAudit role.', cmds: [['bash', 'python -m aifr_collect aws --profile audit --regions ap-south-1 eu-west-1 us-east-1 --out ./evidence']] });
    if (has('azure-openai') || (has('identity') && (eng.scope.platforms.identity.variant || 'entra') === 'entra')) items.push({ id: 'col-azure', t: 'Run the Azure collector', d: 'AI resources, diagnostic settings, key authentication, workspace retention, Defender for AI and Entra ID log export. Uses the Azure CLI with Reader and Monitoring Reader.', cmds: [['bash', 'az login\npython -m aifr_collect azure --subscription SUBSCRIPTION_ID --out ./evidence']] });
    if (has('gcp-vertex') || has('gemini-enterprise') || has('google-code')) items.push({ id: 'col-gcp', t: 'Run the Google Cloud collector', d: 'Data Access audit configuration for Vertex AI, log bucket retention and locks, sinks, and Gemini Code Assist logging settings.', cmds: [['bash', 'gcloud auth login\npython -m aifr_collect gcp --project PROJECT_ID --out ./evidence']] });
    if (has('github-copilot')) items.push({ id: 'col-github', t: 'Run the GitHub collector', d: 'Audit log streams, Copilot and agent events, MCP registry events and the usage-records API.', cmds: [['bash', 'export GITHUB_TOKEN=...   # classic PAT, read:audit_log and read:enterprise\npython -m aifr_collect github --enterprise ENTERPRISE_SLUG --out ./evidence']] });
    if (has('claude-enterprise') || has('anthropic-api') || has('claude-code')) items.push({ id: 'col-anthropic', t: 'Run the Anthropic collector', d: 'Activity Feed reachability and the local-session capture check. Uses a read-only Compliance Access Key.', cmds: [['bash', 'export ANTHROPIC_COMPLIANCE_KEY=...   # read:compliance_activities, read:compliance_user_data\npython -m aifr_collect anthropic --out ./evidence']] });
    if (has('openai-api')) items.push({ id: 'col-openai', t: 'Run the OpenAI API collector', d: 'Organisation audit logging state, projects and key ownership.', cmds: [['bash', 'export OPENAI_ADMIN_KEY=...\npython -m aifr_collect openai --out ./evidence']] });
    if (has('ai-gateway') || has('selfhosted-inference') || has('chat-frontend')) items.push({ id: 'col-selfhosted', t: 'Run the self-hosted collector on gateway and inference hosts', d: 'Gateway content logging and retention settings, unauthenticated model endpoints, container log drivers, host auditing and Open WebUI audit level.', cmds: [['bash', 'python3 -m aifr_collect selfhosted --config ./litellm-config.yaml \\\n  --probe http://MODEL_HOST:11434 http://MODEL_HOST:8000 --out ./evidence']] });
    if (has('shadow-ai')) items.push({ id: 'col-shadow', t: 'Analyse 30 to 90 days of proxy or DNS logs for AI destinations', d: 'Maps traffic to about 150 AI services, separates enterprise and consumer endpoints, and reports users, volumes and lookback. Export the logs from the SIEM or proxy as CSV.', cmds: [['bash', 'python -m aifr_collect shadow --logs ./proxy-export.csv --sanctioned m365-copilot,chatgpt-enterprise --out ./evidence']] });
    items.push({ id: 'col-import', t: 'Import every bundle with its .sha256 sidecar', d: 'Drop both files into Evidence. The Workbench recomputes the SHA-256, compares it with the sidecar and records it in the evidence register.' });
    return items;
  }

  function model(ctx) {
    const { idx, eng, E } = ctx;
    const scoped = E.scopedIds(idx, eng);
    const m = eng.meta;
    const india = m.jurisdictions.indexOf('IN') >= 0;
    const ctrl = filter => {
      const out = [];
      scoped.forEach(pid => E.applicable(idx, eng, pid).forEach(c => { if (filter(c)) out.push(c); }));
      return out;
    };
    const P = [];
    P.push({
      id: 'P0', title: 'Mobilise', desc: 'Agree scope, legal cover and access before fieldwork starts. Nothing is collected until these are in place.',
      items: [
        { id: 'p0-scope', t: 'Confirm scope, objective and evidence target with the sponsor', d: U(ctx).plural(scoped.length, 'platform') + ' in scope; target lookback ' + E.targetDays(eng) + ' days' + (m.jurisdictions.length ? '; jurisdictions ' + m.jurisdictions.join(', ') : '') + '.' },
        { id: 'p0-legal', t: 'Obtain written approval for content sampling', d: 'Retrieval tests touch real prompts and responses. Agree test users, consent, redaction and who may view samples with legal and the DPO before Phase 3.' },
        { id: 'p0-evidence', t: 'Agree the evidence-handling protocol', d: 'Every artefact is hashed (SHA-256) on receipt, kept only in the agreed case folder and referenced by ID in the report.' + (india ? ' Prepare certificate templates under s.63(4) Bharatiya Sakshya Adhiniyam (Parts A and B, including hash values) in case findings feed proceedings in India.' : '') },
        { id: 'p0-access', t: 'Request named, time-boxed, read-only access', d: 'Roles per platform are listed below. No shared administrator credentials; access is revoked at close.', access: true },
        { id: 'p0-norisk', t: 'Confirm assessors will not change client settings', d: 'Where a setting must change to be tested, the client changes it through its own change process and the change is recorded.' }
      ]
    });
    P.push({ id: 'P1', title: 'Discover', desc: 'Establish what AI is actually in use, sanctioned or not, and run the automated collectors.', items: collectorItems(ctx), controls: ctrl(c => c.aspect === 'inventory') });
    const groups = scoped.map(pid => ({ pid, name: idx.platforms[pid].name, controls: E.applicable(idx, eng, pid).filter(c => CONFIG_ASPECTS.indexOf(c.aspect) >= 0).sort((a, b) => (b.key ? 1 : 0) - (a.key ? 1 : 0)) })).filter(g => g.controls.length);
    P.push({ id: 'P2', title: 'Verify configuration', desc: 'For each platform, answer the four questions first (marked K1 to K4), then the remaining checks. Record evidence for every verdict.', groups });
    P.push({ id: 'P3', title: 'Prove retrieval', desc: 'A configuration setting is a claim; a retrieved record is evidence. For each platform, retrieve real records at set ages and hash what you retrieve.', controls: ctrl(c => c.aspect === 'retrieval'), sampling: true });
    const sc = E.scenarios(idx, eng).filter(s => s.applicable);
    P.push({
      id: 'P4', title: 'Readiness interviews and tabletop', desc: 'Test the people, access and legal groundwork, then walk the incident scenarios with the response team.',
      controls: ctrl(c => c.aspect === 'process' || c.aspect === 'access'),
      items: sc.map(s => ({ id: 'p4-' + s.id, t: 'Walk scenario ' + s.id + ': ' + s.title, d: s.narrative + ' For each investigator question, ask the responders to name the source, the role that retrieves it and how long it takes.' }))
    });
    P.push({
      id: 'P5', title: 'Score, report and hand over', desc: 'Close open checks, validate findings with owners, and leave the client with dates, not just scores.',
      items: [
        { id: 'p5-open', t: 'Resolve every open check or mark it not applicable with a reason', d: 'Unassessed checks are listed in Assess with the filter "Not assessed".' },
        { id: 'p5-validate', t: 'Validate draft findings with platform owners', d: 'Factual accuracy only. Severity follows the scoring rules.' },
        { id: 'p5-dates', t: 'Record the coverage start date of every non-retroactive control', d: 'The report states the period that can no longer be reconstructed for each platform.' },
        { id: 'p5-issue', t: 'Issue the report and the engagement file, and record both SHA-256 values', d: 'The engagement file is the system of record for re-assessment.' },
        { id: 'p5-owners', t: 'Agree remediation owners and dates for the 30, 90 and 90+ day windows', d: '' },
        { id: 'p5-drift', t: 'Schedule a re-run of the collectors in six months', d: 'Detects drift: logging switched off, retention shortened, new AI tools.' }
      ]
    });
    return P;
  }

  function U(ctx) { return ctx.U; }

  function controlRow(ctx, c, opts) {
    const { U } = ctx;
    const r = ctx.S.result(c.id);
    const p = ctx.idx.platforms[c.platform];
    return '<div class="rb-item' + (r.status !== 'open' ? ' done' : '') + '">' +
      '<span>' + U.statusChip(r.status, ' ') + '</span>' +
      '<div><div class="rt"><span class="mono xs muted">' + c.id + '</span> ' + U.esc(c.title) + ' ' + (c.key ? '<span class="tag key">' + c.key + '</span> ' : '') + U.method(c.method) + (opts && opts.showPlatform ? ' <span class="xs muted">' + U.esc(p.short) + '</span>' : '') + '</div>' +
      '<details><summary>How to check</summary><div class="rb-detail"><div>' + U.esc(c.how) + '</div>' + (c.cmd || []).map(x => U.codeBlock(x.lang, x.code)).join('') + '<div class="callout expect"><b>Expected:</b> ' + U.esc(c.expect) + '</div></div></details></div>' +
      '<button class="btn sm" data-action="open-control" data-cid="' + c.id + '">Assess</button></div>';
  }

  function taskRow(ctx, it) {
    const { U, eng } = ctx;
    const done = !!eng.runbook[it.id];
    let extra = '';
    if (it.cmds) extra += '<details' + (done ? '' : ' open') + '><summary>Commands</summary><div class="rb-detail">' + it.cmds.map(x => U.codeBlock(x[0], x[1])).join('') + '</div></details>';
    if (it.access) extra += accessTable(ctx);
    return '<div class="rb-item' + (done ? ' done' : '') + '"><input type="checkbox" class="cb" data-action="rb-toggle" data-id="' + it.id + '"' + (done ? ' checked' : '') + ' aria-label="Mark done"><div><div class="rt">' + U.esc(it.t) + '</div>' + (it.d ? '<div class="rd">' + U.esc(it.d) + '</div>' : '') + extra + '</div><span></span></div>';
  }

  function accessTable(ctx) {
    const { U, idx, eng, E } = ctx;
    const rows = [];
    E.scopedIds(idx, eng).forEach(pid => (idx.platforms[pid].access || []).forEach(a => rows.push([idx.platforms[pid].short, a.role, a.purpose])));
    return '<div class="tbl-wrap" style="margin-top:8px"><table class="tbl"><thead><tr><th>Platform</th><th>Role</th><th>Purpose</th></tr></thead><tbody>' + rows.map(r => '<tr><td>' + U.esc(r[0]) + '</td><td>' + U.esc(r[1]) + '</td><td class="muted">' + U.esc(r[2]) + '</td></tr>').join('') + '</tbody></table></div>';
  }

  function samplingTable(ctx) {
    const { U, idx, eng, E } = ctx;
    const t = E.targetDays(eng);
    const ages = [7, 30, 90, t];
    const rows = [];
    E.scopedIds(idx, eng).forEach(pid => (idx.platforms[pid].sources || []).filter(s => s.content === 'content').forEach(s => rows.push([idx.platforms[pid].short, s.name])));
    if (!rows.length) return '';
    return '<div class="sheet-body"><div class="block-title">Sampling plan: retrieve one named record at each age, hash it, and record the result</div><div class="tbl-wrap"><table class="tbl"><thead><tr><th>Platform</th><th>Content source</th>' + ages.map(a => '<th>' + a + ' days</th>').join('') + '</tr></thead><tbody>' +
      rows.map(r => '<tr><td>' + U.esc(r[0]) + '</td><td>' + U.esc(r[1]) + '</td>' + ages.map(() => '<td class="muted xs">full / metadata / none</td>').join('') + '</tr>').join('') + '</tbody></table></div></div>';
  }

  function openCount(ctx) {
    if (!ctx.eng) return 0;
    let n = 0;
    model(ctx).forEach(ph => {
      (ph.items || []).forEach(it => { if (!ctx.eng.runbook[it.id]) n++; });
    });
    return n;
  }

  /* Standalone, printable field runbook. */
  function exportHTML(ctx) {
    const { U, eng, idx } = ctx;
    const m = eng.meta;
    const P = model(ctx);
    const esc = U.esc;
    const box = '<span class="bx"></span>';
    const ctrlHtml = c => '<div class="it">' + box + '<div><div class="t"><span class="id">' + c.id + '</span> ' + esc(c.title) + (c.key ? ' <span class="k">' + c.key + '</span>' : '') + ' <span class="m">' + c.method + '</span></div><div class="d">' + esc(c.how) + '</div>' + (c.cmd || []).map(x => '<pre>' + esc(x.code) + '</pre>').join('') + '<div class="e"><b>Expected:</b> ' + esc(c.expect) + '</div><div class="res">Result: Met / Partial / Gap / Claimed / N/A &nbsp; Evidence ref: ____________</div></div></div>';
    let body = '';
    P.forEach(ph => {
      body += '<section><h2><span class="pn">' + ph.id + '</span> ' + esc(ph.title) + '</h2><p class="pd">' + esc(ph.desc) + '</p>';
      (ph.items || []).forEach(it => {
        body += '<div class="it">' + box + '<div><div class="t">' + esc(it.t) + '</div>' + (it.d ? '<div class="d">' + esc(it.d) + '</div>' : '') + (it.cmds || []).map(x => '<pre>' + esc(x[1]) + '</pre>').join('') + (it.access ? accessTable(ctx).replace(/class="tbl-wrap"[^>]*/, '') : '') + '</div></div>';
      });
      (ph.controls || []).forEach(c => { body += ctrlHtml(c); });
      (ph.groups || []).forEach(g => { body += '<h3>' + esc(g.name) + '</h3>'; g.controls.forEach(c => { body += ctrlHtml(c); }); });
      if (ph.sampling) body += samplingTable(ctx);
      body += '</section>';
    });
    const css = 'body{font:10.5pt/1.45 "Segoe UI",system-ui,sans-serif;color:#0e1626;margin:0;background:#fff}main{max-width:190mm;margin:0 auto;padding:14mm 0}h1{font:600 22pt/1.2 Cambria,Georgia,serif;margin:0}h2{font:600 14pt/1.3 Cambria,Georgia,serif;margin:10mm 0 2mm;border-bottom:1pt solid #c9cfd9;padding-bottom:2mm}h3{font-size:11pt;margin:6mm 0 2mm}.pn{font:700 10pt monospace;color:#23379a}.pd{color:#5d6779;margin:0 0 3mm}.meta{color:#5d6779;margin:2mm 0 6mm}.it{display:grid;grid-template-columns:7mm 1fr;gap:2mm;padding:2.5mm 0;border-bottom:.5pt solid #e3e6ec;break-inside:avoid}.bx{width:3.6mm;height:3.6mm;border:1pt solid #6f7888;border-radius:.6mm;margin-top:1mm}.t{font-weight:600}.d{color:#364154;font-size:9.5pt}.e{font-size:9pt;margin-top:1mm}.res{font-size:8.5pt;color:#6f7888;margin-top:1.5mm}.id{font:600 8.5pt monospace;color:#6f7888}.k{font-size:8pt;font-weight:700;color:#23379a;background:#e7ebfa;padding:0 1.5mm;border-radius:1mm}.m{font-size:8pt;color:#6f7888;text-transform:uppercase}pre{background:#f3f5f8;border:.5pt solid #dfe3ea;padding:2mm 3mm;font:8.5pt/1.45 Consolas,monospace;white-space:pre-wrap;margin:1.5mm 0}table{width:100%;border-collapse:collapse;font-size:8.5pt;margin-top:2mm}th,td{text-align:left;border-bottom:.5pt solid #dfe3ea;padding:1.5mm}th{font-size:7.5pt;text-transform:uppercase;color:#5d6779}.block-title{font-weight:700;margin-top:4mm}@page{size:A4;margin:14mm}';
    return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>' + esc((m.client || 'Client') + ' AI forensic readiness field runbook') + '</title><style>' + css + '</style></head><body><main>' +
      '<div style="font-size:8pt;text-transform:uppercase;letter-spacing:1pt;color:#5d6779">' + esc(m.classification || 'Confidential') + '</div><h1>AI forensic readiness field runbook</h1><div class="meta">' + esc(m.client || '') + ' · ' + esc(m.ref || '') + ' · generated ' + U.fmtDate(new Date().toISOString()) + ' · knowledge base ' + esc(idx.kb.kb_version) + '</div>' +
      body + '</main></body></html>';
  }

  A.views.runbook = {
    model, openCount, exportHTML,
    render(ctx) {
      const { U, eng } = ctx;
      if (!eng) return '<div class="sheet empty">Start or open an engagement first.</div>';
      if (!Object.keys(eng.scope.platforms).length) return '<div class="sheet empty">Select the AI estate in Scope to generate the runbook.<p style="margin-top:10px"><button class="btn primary" data-action="go" data-view="scope">Go to Scope</button></p></div>';
      const P = model(ctx);
      let h = '<div class="page-head"><div><span class="eyebrow">Step 2</span><h1>Field runbook</h1><p>Generated for this estate. Work through the phases in order: discovery before configuration, configuration before retrieval, retrieval before scoring.</p></div>' +
        '<div class="row"><button class="btn" data-action="export-runbook">' + U.icon('download') + 'Export runbook</button></div></div>';
      P.forEach(ph => {
        const tasks = (ph.items || []).length, done = (ph.items || []).filter(it => eng.runbook[it.id]).length;
        const ctrls = (ph.controls || []).concat(...(ph.groups || []).map(g => g.controls));
        const assessed = ctrls.filter(c => ctx.S.result(c.id).status !== 'open').length;
        h += '<div class="sheet phase"><div class="phase-head"><span class="phase-num">' + ph.id + '</span><div style="flex:1"><h2>' + U.esc(ph.title) + '</h2><p>' + U.esc(ph.desc) + '</p></div><span class="xs muted num" style="white-space:nowrap">' +
          (tasks ? done + '/' + tasks + ' steps' : '') + (tasks && ctrls.length ? ' · ' : '') + (ctrls.length ? assessed + '/' + ctrls.length + ' checks' : '') + '</span></div>';
        (ph.items || []).forEach(it => { h += taskRow(ctx, it); });
        (ph.controls || []).forEach(c => { h += controlRow(ctx, c, { showPlatform: true }); });
        (ph.groups || []).forEach(g => {
          const a = g.controls.filter(c => ctx.S.result(c.id).status !== 'open').length;
          h += '<div class="rb-plat"><b>' + U.esc(g.name) + '</b><span class="xs muted">' + a + ' of ' + g.controls.length + ' assessed</span></div>';
          g.controls.forEach(c => { h += controlRow(ctx, c); });
        });
        if (ph.sampling) h += samplingTable(ctx);
        h += '</div>';
      });
      return h;
    }
  };

  A.actions['rb-toggle'] = (el, ev, ctx) => { ctx.S.toggleRunbook(el.dataset.id); };
  A.actions['export-runbook'] = (el, ev, ctx) => {
    ctx.U.download(ctx.S.fileName('_runbook.html'), exportHTML(ctx), 'text/html');
    ctx.S.log('Field runbook exported');
    ctx.S.commit({ quiet: true });
    ctx.U.toast('Runbook exported');
  };
})(typeof window !== 'undefined' ? window : globalThis);
