/* Assess: check-by-check decisions with evidence. Keyboard: arrows move, M P G C N U set status. */
(function (root) {
  'use strict';
  const A = root.AIFR;
  const STATUSES = [['met', 'Met', 'M'], ['partial', 'Partial', 'P'], ['gap', 'Gap', 'G'], ['unverified', 'Claimed', 'C'], ['na', 'N/A', 'N'], ['open', 'Not assessed', 'U']];
  const WEIGHT = { 1: 'Supporting', 2: 'Significant', 3: 'Decisive' };

  function filtered(ctx) {
    const { idx, eng, E, S } = ctx;
    const f = S.ui.filters;
    const q = (f.q || '').toLowerCase();
    const out = [];
    E.scopedIds(idx, eng).forEach(pid => {
      if (f.platform && f.platform !== pid) return;
      E.applicable(idx, eng, pid).forEach(c => {
        const st = S.result(c.id).status || 'open';
        if (f.domain && c.domain !== f.domain) return;
        if (f.status && st !== f.status) return;
        if (f.key === 'any' && !c.key) return;
        if (f.key && f.key !== 'any' && c.key !== f.key) return;
        if (f.method && c.method !== f.method) return;
        if (q && (c.id + ' ' + c.title + ' ' + c.how).toLowerCase().indexOf(q) < 0) return;
        out.push(c);
      });
    });
    return out;
  }

  function sel(ctx, list) {
    const id = ctx.S.ui.sel;
    if (id && ctx.idx.controls[id] && ctx.E.applies(ctx.eng, ctx.idx.controls[id])) return ctx.idx.controls[id];
    return list[0] || null;
  }

  function filterBar(ctx) {
    const { U, idx, eng, E, S } = ctx;
    const f = S.ui.filters;
    const opt = (v, l, cur) => '<option value="' + v + '"' + (cur === v ? ' selected' : '') + '>' + U.esc(l) + '</option>';
    return '<div class="filters">' +
      '<input class="input full" type="search" placeholder="Search checks" value="' + U.esc(f.q || '') + '" data-filter="q" aria-label="Search checks">' +
      '<select class="input" data-filter="platform" aria-label="Platform">' + opt('', 'All platforms', f.platform) + E.scopedIds(idx, eng).map(pid => opt(pid, idx.platforms[pid].short, f.platform)).join('') + '</select>' +
      '<select class="input" data-filter="status" aria-label="Status">' + opt('', 'Any status', f.status) + STATUSES.map(s => opt(s[0], s[1], f.status)).join('') + '</select>' +
      '<select class="input" data-filter="domain" aria-label="Domain">' + opt('', 'All domains', f.domain) + idx.kb.domains.map(d => opt(d.id, d.label, f.domain)).join('') + '</select>' +
      '<select class="input" data-filter="key" aria-label="Key question">' + opt('', 'All checks', f.key) + opt('any', 'Four questions only', f.key) + idx.kb.keys.map(k => opt(k.id, k.id + ' ' + k.label, f.key)).join('') + '</select>' +
      '<select class="input full" data-filter="method" aria-label="Method">' + opt('', 'Any method', f.method) + opt('auto', 'Automated', f.method) + opt('guided', 'Guided', f.method) + opt('interview', 'Interview', f.method) + '</select></div>';
  }

  function listHtml(ctx, list, cur) {
    const { U, idx, S } = ctx;
    if (!list.length) return '<div class="empty small">No checks match these filters.</div>';
    let h = '', last = '';
    list.forEach(c => {
      if (c.platform !== last) {
        last = c.platform;
        const n = list.filter(x => x.platform === c.platform);
        h += '<div class="cgroup"><span>' + U.esc(idx.platforms[c.platform].short) + '</span><span class="num">' + n.filter(x => S.result(x.id).status !== 'open').length + '/' + n.length + '</span></div>';
      }
      const st = S.result(c.id).status || 'open';
      h += '<div class="citem' + (cur && cur.id === c.id ? ' sel' : '') + '" data-action="select-control" data-cid="' + c.id + '"><span class="cid">' + c.id + '</span><span class="ct">' + U.esc(c.title) + (c.key ? ' <span class="tag key">' + c.key + '</span>' : '') + '</span>' + U.statusChip(st, ' ') + '</div>';
    });
    return h;
  }

  function retentionEditor(ctx, c) {
    const { U, idx, eng } = ctx;
    const p = idx.platforms[c.platform];
    let sources = (p.sources || []);
    if (!sources.length) return '';
    return '<div><div class="block-title">Retention observed</div><div class="tbl-wrap"><table class="tbl"><thead><tr><th>Source</th><th>Vendor default</th><th>Days kept here</th><th>Oldest record found</th></tr></thead><tbody>' +
      sources.map(s => {
        const r = eng.retention[s.id] || {};
        return '<tr><td><b>' + U.esc(s.name) + '</b><div class="xs muted">' + U.esc(s.where || '') + '</div></td><td class="xs">' + U.esc(s.retention) + '</td><td style="width:110px"><input class="input" type="number" min="0" data-ret="' + s.id + '" data-field="days" value="' + U.esc(r.days == null ? '' : r.days) + '" placeholder="' + (s.days == null ? '' : s.days) + '" aria-label="Days kept"></td><td style="width:150px"><input class="input" type="date" data-ret="' + s.id + '" data-field="oldest" value="' + U.esc(r.oldest || '') + '" aria-label="Oldest record"></td></tr>';
      }).join('') + '</tbody></table></div><div class="xs muted" style="margin-top:4px">Leave blank to use the vendor default. Lookback is measured against the engagement target of ' + ctx.E.targetDays(eng) + ' days.</div></div>';
  }

  function detailHtml(ctx, c, list) {
    const { U, idx, eng, S, I } = ctx;
    if (!c) return '<div class="sheet empty">Select a check.</div>';
    const p = idx.platforms[c.platform];
    const r = S.result(c.id);
    const st = r.status || 'open';
    const agg = I.collected()[c.id];
    const i = list.findIndex(x => x.id === c.id);
    const evNames = idx.kb.evidence.reduce((m, e) => { m[e.id] = e.label; return m; }, {});
    let h = '<div class="sheet detail"><div class="detail-head"><div class="row" style="justify-content:space-between"><span class="eyebrow">' + U.esc(p.short) + ' · ' + U.esc(idx.kb.domains.find(d => d.id === c.domain).label) + '</span>' +
      '<span class="row"><button class="btn ghost sm" data-action="step-control" data-dir="-1"' + (i <= 0 ? ' disabled' : '') + '>Previous</button><button class="btn ghost sm" data-action="step-control" data-dir="1"' + (i < 0 || i >= list.length - 1 ? ' disabled' : '') + '>Next</button></span></div>' +
      '<h2>' + U.esc(c.title) + '</h2><div class="row" style="margin-top:8px"><span class="mono small">' + c.id + '</span>' + (c.key ? '<span class="tag key" data-tip="' + U.esc(idx.kb.keys.find(k => k.id === c.key).label) + '">' + c.key + ' ' + U.esc(idx.kb.keys.find(k => k.id === c.key).label) + '</span>' : '') + U.method(c.method) + '<span class="tag">' + WEIGHT[c.weight] + '</span>' +
      (c.provides || []).map(e => '<span class="tag" data-tip="' + U.esc(evNames[e]) + '">' + e + ' ' + U.esc(evNames[e]) + '</span>').join('') + '</div></div>';
    h += '<div class="detail-body">';
    h += '<div><div class="block-title">Verdict</div><div class="seg" role="radiogroup" aria-label="Verdict">' + STATUSES.map(s => '<button role="radio" aria-checked="' + (st === s[0]) + '" class="s-' + s[0] + (st === s[0] ? ' on' : '') + '" data-action="set-status" data-cid="' + c.id + '" data-status="' + s[0] + '">' + s[1] + ' <kbd>' + s[2] + '</kbd></button>').join('') + '</div>' +
      (r.by ? '<div class="xs muted" style="margin-top:6px">' + (r.source === 'collector' ? 'Set by collector' : 'Set by ' + U.esc(r.by)) + ' · ' + U.fmtDateTime(r.at) + '</div>' : '') + '</div>';
    if (agg) h += '<div class="callout"><b>Collector results:</b> ' + agg.met + ' met, ' + agg.partial + ' partial, ' + agg.gap + ' gap' + (agg.na ? ', ' + agg.na + ' not applicable' : '') + ' across ' + U.plural(agg.targets, 'target') + '.' + (agg.details.length ? '<ul class="bul" style="margin-top:4px">' + agg.details.map(d => '<li class="xs">' + U.esc(d) + '</li>').join('') + '</ul>' : '') + '</div>';
    h += '<div class="callout impact"><b>Why it matters:</b> ' + U.esc(c.impact) + '</div>';
    h += '<div><div class="block-title">How to check</div><p class="small">' + U.esc(c.how) + '</p>' + (c.cmd || []).map(x => '<div style="margin-top:8px">' + U.codeBlock(x.lang, x.code) + '</div>').join('') + '<div class="callout expect" style="margin-top:8px"><b>Expected:</b> ' + U.esc(c.expect) + '</div></div>';
    h += '<div><div class="block-title">Evidence</div><textarea class="input code" id="ev-paste" placeholder="Paste command output or a screenshot transcript here"></textarea>' +
      '<div class="row" style="margin-top:8px">' + (c.eval ? '<button class="btn sm" data-action="evaluate" data-cid="' + c.id + '">Suggest verdict</button>' : '') + '<button class="btn sm" data-action="attach-text" data-cid="' + c.id + '">Attach as evidence</button>' +
      '<label class="btn sm">' + U.icon('file') + 'Attach file<input type="file" hidden data-action-change="attach-file" data-cid="' + c.id + '"></label><span class="xs muted">Files are hashed; only name, size and SHA-256 are stored here.</span></div><div id="suggest-slot"></div>';
    const evs = r.evidence || [];
    if (evs.length) h += '<div class="ev-list" style="margin-top:10px">' + evs.map((e, k) => '<div class="ev-item"><div><b>' + U.esc(e.label) + '</b>' + (e.name ? ' <span class="muted">' + U.esc(e.name) + '</span>' : '') + '<div class="hash">SHA-256 ' + e.sha256 + '</div><div class="xs muted">' + U.bytes(e.bytes) + ' · ' + U.fmtDateTime(e.addedAt) + '</div></div><button class="btn ghost sm" data-action="remove-evidence" data-cid="' + c.id + '" data-i="' + k + '">Remove</button>' + (e.text ? '<pre>' + U.esc(e.text) + '</pre>' : '') + '</div>').join('') + '</div>';
    h += '</div>';
    h += '<div class="field"><label for="note-' + c.id + '">Finding note</label><textarea class="input" id="note-' + c.id + '" data-note="' + c.id + '" rows="3" placeholder="What you observed, with scope (for example: 3 of 5 resources)">' + U.esc(r.note || '') + '</textarea></div>';
    if (c.aspect === 'retention' || c.key === 'K2') h += retentionEditor(ctx, c);
    h += '<div class="callout fix"><b>Remediation:</b> ' + U.esc(c.fix) + '<div class="xs muted" style="margin-top:4px">Effort ' + c.effort + ' · Owner: ' + U.esc(c.owner) + '</div></div>';
    if ((c.refs || []).length) h += '<div><div class="block-title">References</div><div class="row">' + c.refs.map(rid => { const ref = idx.refs[rid]; const fw = idx.frameworks[ref.fw]; return '<span class="tag" data-tip="' + U.esc(ref.title) + '">' + U.esc(fw.name.split(' (')[0] + ' ' + ref.ref) + '</span>'; }).join('') + '</div></div>';
    h += '</div></div>';
    return h;
  }

  A.views.assess = {
    filtered, sel,
    render(ctx) {
      const { U, eng } = ctx;
      if (!eng) return '<div class="sheet empty">Start or open an engagement first.</div>';
      if (!Object.keys(eng.scope.platforms).length) return '<div class="sheet empty">Select the AI estate in Scope first.</div>';
      const list = filtered(ctx);
      const cur = sel(ctx, list);
      const pr = ctx.E.progress(ctx.idx, eng);
      return '<div class="page-head"><div><span class="eyebrow">Step 4</span><h1>Assess</h1><p>Decide each check on evidence. A claim without evidence is recorded as Claimed, which scores below Met.</p></div><div class="xs muted num">' + pr.assessed + ' of ' + pr.total + ' assessed · keys: ↑ ↓ move, M P G C N U set verdict</div></div>' +
        '<div class="assess"><div class="sheet" style="overflow:hidden">' + filterBar(ctx) + '<div class="clist" id="clist" data-keep-scroll="clist">' + listHtml(ctx, list, cur) + '</div></div>' + detailHtml(ctx, cur, list) + '</div>';
    },
    mount(el, ctx) {
      const s = el.querySelector('.citem.sel');
      const box = el.querySelector('#clist');
      if (s && box && !ctx.keepScroll) {
        const top = s.offsetTop - box.offsetTop;
        if (top < box.scrollTop || top > box.scrollTop + box.clientHeight - 40) box.scrollTop = top - 80;
      }
    }
  };

  A.actions['select-control'] = (el, ev, ctx) => { ctx.S.ui.sel = el.dataset.cid; ctx.S.saveUI(); ctx.render({ keepScroll: true }); };
  A.actions['open-control'] = (el, ev, ctx) => {
    ev.preventDefault();
    const c = ctx.idx.controls[el.dataset.cid];
    if (!c) return;
    const f = ctx.S.ui.filters;
    Object.keys(f).forEach(k => { f[k] = ''; });
    ctx.S.go('assess', c.id);
  };
  A.actions['set-status'] = (el, ev, ctx) => { ctx.S.setStatus(el.dataset.cid, el.dataset.status); };
  A.actions['step-control'] = (el, ev, ctx) => {
    const list = filtered(ctx);
    const cur = sel(ctx, list);
    const i = list.findIndex(x => cur && x.id === cur.id) + Number(el.dataset.dir);
    if (i >= 0 && i < list.length) { ctx.S.ui.sel = list[i].id; ctx.S.saveUI(); ctx.render(); }
  };
  A.actions['evaluate'] = (el, ev, ctx) => {
    const c = ctx.idx.controls[el.dataset.cid];
    const text = (document.getElementById('ev-paste') || {}).value || '';
    const slot = document.getElementById('suggest-slot');
    const res = ctx.E.evaluateText(c, text);
    if (!text.trim()) { ctx.U.toast('Paste the command output first.'); return; }
    slot.innerHTML = res
      ? '<div class="suggest" style="margin-top:8px">Output matches the rule for <b>' + ({ met: 'Met', partial: 'Partial', gap: 'Gap' }[res.status]) + '</b>.<button class="btn sm primary" data-action="accept-suggest" data-cid="' + c.id + '" data-status="' + res.status + '">Apply and attach output</button></div>'
      : '<div class="suggest" style="margin-top:8px">No rule matched. Decide the verdict manually and attach the output.</div>';
  };
  A.actions['accept-suggest'] = async (el, ev, ctx) => {
    await attachText(ctx, el.dataset.cid);
    ctx.S.setStatus(el.dataset.cid, el.dataset.status);
  };
  async function attachText(ctx, cid) {
    const ta = document.getElementById('ev-paste');
    const text = ta ? ta.value : '';
    if (!text.trim()) { ctx.U.toast('Nothing to attach.'); return false; }
    const sha = await ctx.U.sha256(text);
    const keep = text.length > 20000 ? text.slice(0, 20000) + '\n[truncated in the engagement file; full output hashed]' : text;
    ctx.S.addEvidence(cid, { kind: 'text', label: 'Command output', sha256: sha, bytes: new TextEncoder().encode(text).length, addedAt: ctx.U.now(), text: keep });
    ctx.U.toast('Output attached. SHA-256 ' + sha.slice(0, 16) + '…');
    return true;
  }
  A.actions['attach-text'] = (el, ev, ctx) => { attachText(ctx, el.dataset.cid); };
  A.actions['attach-file'] = async (el, ev, ctx) => {
    const f = el.files && el.files[0];
    if (!f) return;
    const buf = await ctx.U.readFile(f);
    const sha = await ctx.U.sha256(buf);
    ctx.S.addEvidence(el.dataset.cid, { kind: 'file', label: 'File', name: f.name, sha256: sha, bytes: f.size, addedAt: ctx.U.now() });
    ctx.U.toast('File registered. SHA-256 ' + sha.slice(0, 16) + '…');
  };
  A.actions['remove-evidence'] = (el, ev, ctx) => { ctx.S.removeEvidence(el.dataset.cid, Number(el.dataset.i)); };
  A.actions['go-platform'] = (el, ev, ctx) => {
    ev.preventDefault();
    const f = ctx.S.ui.filters;
    Object.keys(f).forEach(k => { f[k] = ''; });
    f.platform = el.dataset.pid;
    ctx.S.ui.sel = null;
    ctx.S.go('assess');
  };

  A.keys = A.keys || {};
  A.keys.assess = (e, ctx) => {
    const list = filtered(ctx);
    const cur = sel(ctx, list);
    if (!cur) return false;
    const k = e.key.toLowerCase();
    if (k === 'arrowdown' || k === 'arrowup' || k === 'j' || k === 'k') {
      const i = list.findIndex(x => x.id === cur.id) + ((k === 'arrowdown' || k === 'j') ? 1 : -1);
      if (i >= 0 && i < list.length) { ctx.S.ui.sel = list[i].id; ctx.S.saveUI(); ctx.render(); }
      return true;
    }
    const map = { m: 'met', p: 'partial', g: 'gap', c: 'unverified', n: 'na', u: 'open' };
    if (map[k]) { ctx.S.ui.sel = cur.id; ctx.S.setStatus(cur.id, map[k]); return true; }
    return false;
  };
})(typeof window !== 'undefined' ? window : globalThis);
