/* Evidence: collector bundle intake, fleet picture, shadow AI picture, evidence register. */
(function (root) {
  'use strict';
  const A = root.AIFR;

  function fleetBlock(ctx, f) {
    const { U } = ctx;
    if (!f) return '';
    let h = '<div class="section"><h2>Endpoint fleet</h2><p class="lede">Built from ' + U.plural(f.endpoints, 'endpoint bundle') + '. Local AI transcripts are the most detailed and the most volatile evidence in the estate.</p>' +
      '<div class="grid g4">' +
      '<div class="sheet kpi"><span class="k-label">Endpoints scanned</span><span class="k-value num">' + f.endpoints + '</span><span class="k-note">' + f.withAI + ' with at least one AI tool</span></div>' +
      '<div class="sheet kpi"><span class="k-label">Local transcripts</span><span class="k-value num">' + f.transcripts.toLocaleString() + '</span><span class="k-note">Session files found on endpoints</span></div>' +
      '<div class="sheet kpi"><span class="k-label">MCP servers</span><span class="k-value num">' + f.mcp.length + '</span><span class="k-note">Distinct servers configured</span></div>' +
      '<div class="sheet kpi"><span class="k-label">Exposed model runtimes</span><span class="k-value num">' + f.exposed + '</span><span class="k-note">Endpoints listening beyond localhost</span></div></div>';
    h += '<div class="sheet section"><div class="sheet-head"><h3>AI tools found</h3><span class="sub">Retention is the shortest effective setting per endpoint</span></div><div class="tbl-wrap"><table class="tbl"><thead><tr><th>Tool</th><th>Endpoints</th><th>With transcripts</th><th>Transcripts</th><th>Size</th><th>Median retention</th><th>Managed policy</th><th>Central capture</th><th>Oldest record</th></tr></thead><tbody>' +
      f.tools.map(t => '<tr><td><b>' + U.esc(t.name) + '</b></td><td class="num">' + t.hosts + '</td><td class="num">' + t.withTranscripts + '</td><td class="num">' + t.transcripts.toLocaleString() + '</td><td class="num">' + U.bytes(t.bytes) + '</td><td class="num">' + (t.medianRetention == null ? '<span class="muted">–</span>' : U.days(t.medianRetention)) + '</td><td class="num">' + t.managed + ' / ' + t.hosts + '</td><td class="num">' + t.central + ' / ' + t.hosts + '</td><td class="num">' + (t.oldest ? U.fmtDate(t.oldest) : '–') + '</td></tr>').join('') +
      '</tbody></table></div></div>';
    if (f.mcp.length) h += '<div class="sheet section"><div class="sheet-head"><h3>MCP servers configured on endpoints</h3><span class="sub">Compare with the approved list (AGT-05)</span></div><div class="tbl-wrap" style="max-height:320px;overflow:auto"><table class="tbl"><thead><tr><th>Server</th><th>Transport</th><th>Command or URL</th><th>Clients</th><th>Endpoints</th></tr></thead><tbody>' +
      f.mcp.slice(0, 60).map(m => '<tr><td><b>' + U.esc(m.name) + '</b></td><td>' + U.esc(m.transport) + '</td><td class="mono xs">' + U.esc(m.target) + '</td><td class="xs">' + U.esc(m.clients.join(', ')) + '</td><td class="num">' + m.hosts + '</td></tr>').join('') + '</tbody></table></div></div>';
    if (f.extensions.length || f.agentic.length) h += '<div class="sheet section"><div class="sheet-head"><h3>AI browser extensions and agentic browsers</h3></div><div class="sheet-body"><div class="row">' +
      f.agentic.map(a => '<span class="chip st-gap">' + U.esc(a.name) + ' · ' + a.hosts + '</span>').join('') +
      f.extensions.slice(0, 40).map(x => '<span class="chip st-open">' + U.esc(x.name) + ' · ' + x.hosts + '</span>').join('') + '</div></div></div>';
    return h + '</div>';
  }

  function shadowBlock(ctx, s) {
    const { U } = ctx;
    if (!s) return '';
    const apps = s.apps || [];
    return '<div class="section"><h2>Shadow AI</h2><p class="lede">From ' + U.esc(s.source || 'network logs') + ' covering ' + U.fmtDate(s.first) + ' to ' + U.fmtDate(s.last) + ' (' + U.plural(s.span_days || 0, 'day') + '). ' + U.plural(s.events || 0, 'event') + ' matched ' + U.plural(apps.length, 'AI service') + '.</p>' +
      '<div class="sheet"><div class="tbl-wrap" style="max-height:420px;overflow:auto"><table class="tbl"><thead><tr><th>Service</th><th>Category</th><th>Account type</th><th>Sanctioned</th><th>Users</th><th>Devices</th><th>Requests</th><th>Uploaded</th><th>Last seen</th></tr></thead><tbody>' +
      apps.map(a => '<tr><td><b>' + U.esc(a.app) + '</b><div class="xs muted">' + U.esc((a.domains || []).slice(0, 3).join(', ')) + '</div></td><td>' + U.esc(a.category) + '</td><td>' + U.esc(a.tier) + '</td><td>' + (a.sanctioned ? U.statusChip('met', 'Yes') : U.statusChip('gap', 'No')) + '</td><td class="num">' + (a.users == null ? '–' : a.users) + '</td><td class="num">' + (a.hosts == null ? '–' : a.hosts) + '</td><td class="num">' + (a.events || 0).toLocaleString() + '</td><td class="num">' + (a.bytes_out ? U.bytes(a.bytes_out) : '–') + '</td><td class="num">' + U.fmtDate(a.last) + '</td></tr>').join('') +
      '</tbody></table></div></div></div>';
  }

  A.views.collect = {
    render(ctx) {
      const { U, eng, I } = ctx;
      if (!eng) return '<div class="sheet empty">Start or open an engagement first.</div>';
      const reg = I.register();
      let h = '<div class="page-head"><div><span class="eyebrow">Step 3</span><h1>Evidence intake</h1><p>Import the bundles produced by the AIFR collectors. Each file is hashed on receipt; drop the matching .sha256 sidecar with it to verify integrity. Collector results fill checks automatically. Your own decisions always take precedence.</p></div></div>';
      h += '<label class="drop" id="dropzone" data-drop="1"><input type="file" multiple accept=".json,.sha256" data-action-change="import-bundles" hidden><h3>Drop collector bundles here</h3><p>.json bundles and their .sha256 sidecars, any number at once. Or click to choose files.</p></label>';
      h += '<div class="sheet section"><div class="sheet-head"><h3>Imported bundles</h3><span class="sub">' + U.plural(eng.bundles.length, 'bundle') + '</span></div>' +
        (eng.bundles.length ? '<div class="tbl-wrap" style="max-height:380px;overflow:auto"><table class="tbl"><thead><tr><th>Collector</th><th>Target</th><th>Collected</th><th>Checks</th><th>SHA-256</th><th></th></tr></thead><tbody>' +
          eng.bundles.slice().sort((a, b) => (b.importedAt || '').localeCompare(a.importedAt || '')).map(b => '<tr><td><b>' + U.esc(b.collector) + '</b><div class="xs muted">' + U.esc(b.impl ? b.impl + ' ' : '') + U.esc(b.version) + '</div></td><td>' + U.esc(b.target || '–') + '<div class="xs muted">' + U.esc(b.os || b.targetType) + '</div></td><td class="num small">' + U.fmtDateTime(b.collectedAt) + '</td><td class="num">' + b.obs.length + '</td><td><div class="hash">' + b.sha256 + '</div>' +
            (b.verified === true ? '<span class="verified">Sidecar verified</span>' : b.verified === false ? '<span class="sev sev-critical">Sidecar mismatch</span>' : '<span class="unverified-h">No sidecar supplied</span>') + '</td><td><button class="btn ghost sm" data-action="remove-bundle" data-id="' + U.esc(b.id) + '">Remove</button></td></tr>').join('') + '</tbody></table></div>'
          : '<div class="empty">No bundles yet. The runbook lists the collector commands for this estate.</div>') + '</div>';
      h += fleetBlock(ctx, I.fleet());
      h += shadowBlock(ctx, I.shadow());
      h += '<div class="section"><h2>Evidence register</h2><p class="lede">Every hashed artefact in this engagement. Hashes are computed when files are imported or output is attached.</p><div class="sheet">' +
        (reg.length ? '<div class="tbl-wrap" style="max-height:420px;overflow:auto"><table class="tbl"><thead><tr><th>Received</th><th>Type</th><th>Reference</th><th>Item</th><th>Size</th><th>SHA-256</th></tr></thead><tbody>' +
          reg.map(r => '<tr><td class="num xs">' + U.fmtDateTime(r.at) + '</td><td class="small">' + U.esc(r.kind) + '</td><td class="mono xs">' + U.esc(r.ref) + '</td><td class="small">' + U.esc(r.label) + '</td><td class="num xs">' + U.bytes(r.bytes) + '</td><td class="hash">' + r.sha256 + '</td></tr>').join('') + '</tbody></table></div>'
          : '<div class="empty">Nothing registered yet.</div>') + '</div></div>';
      return h;
    },
    mount(el, ctx) {
      const dz = el.querySelector('#dropzone');
      if (!dz) return;
      ['dragenter', 'dragover'].forEach(t => dz.addEventListener(t, e => { e.preventDefault(); dz.classList.add('over'); }));
      ['dragleave', 'drop'].forEach(t => dz.addEventListener(t, e => { e.preventDefault(); dz.classList.remove('over'); }));
      dz.addEventListener('drop', e => { if (e.dataTransfer && e.dataTransfer.files.length) importFiles(ctx, e.dataTransfer.files); });
    }
  };

  async function importFiles(ctx, files) {
    const res = await ctx.I.importFiles(files);
    if (res.engagement) { ctx.U.toast('That is an engagement file. Use "Open engagement file" from the menu.'); }
    const parts = [];
    if (res.added) parts.push(res.added + ' imported');
    if (res.replaced) parts.push(res.replaced + ' replaced');
    if (res.skipped) parts.push(res.skipped + ' already present');
    if (res.errors.length) parts.push(res.errors.length + ' rejected: ' + res.errors[0]);
    ctx.U.toast(parts.join(', ') || 'Nothing imported');
    if (!res.added && !res.replaced) ctx.S.emit();
  }

  A.actions['import-bundles'] = (el, ev, ctx) => { if (el.files && el.files.length) importFiles(ctx, el.files).then(() => { el.value = ''; }); };
  A.actions['remove-bundle'] = (el, ev, ctx) => { ctx.I.removeBundle(el.dataset.id); ctx.U.toast('Bundle removed; collector results recalculated'); };
})(typeof window !== 'undefined' ? window : globalThis);
