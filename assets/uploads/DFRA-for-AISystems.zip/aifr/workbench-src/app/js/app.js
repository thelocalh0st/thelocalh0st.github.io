/* Shell: navigation, rendering, event delegation, keyboard and file menu. */
(function (root) {
  'use strict';
  const A = root.AIFR, U = A.util, S = A.store, E = A.engine, I = A.importer, C = A.charts;
  const NAV = [['overview', 'Overview', ''], ['scope', 'Scope', '1'], ['runbook', 'Runbook', '2'], ['collect', 'Evidence', '3'], ['assess', 'Assess', '4'], ['results', 'Results', '5'], ['report', 'Report', '6']];
  let menuOpen = false;
  const armed = {};

  function ctx(extra) { return Object.assign({ A, U, S, E, I, C, idx: S.idx, eng: S.eng, render }, extra || {}); }

  function rail(c) {
    const pr = c.eng ? E.progress(c.idx, c.eng) : null;
    const badge = {
      scope: c.eng ? Object.keys(c.eng.scope.platforms).length || '' : '',
      collect: c.eng && c.eng.bundles.length ? c.eng.bundles.length : '',
      assess: pr && pr.total ? pr.pct + '%' : ''
    };
    const btn = n => '<button class="' + (S.ui.view === n[0] ? 'active' : '') + '" data-action="go" data-view="' + n[0] + '"' + (S.ui.view === n[0] ? ' aria-current="page"' : '') + '><span class="step">' + (n[2] || '·') + '</span><span>' + n[1] + '</span><span class="badge">' + (badge[n[0]] || '') + '</span></button>';
    return '<div class="brand"><div class="brand-mark">AIFR</div><div><div class="brand-name">AIFR Workbench</div><div class="brand-sub">AI forensic readiness</div></div></div>' +
      '<nav class="nav" aria-label="Engagement steps"><div class="nav-label">Engagement</div>' + NAV.map(btn).join('') +
      '<div class="nav-label">Reference</div>' + btn(['library', 'Library', '']) + '</nav>' +
      '<div class="rail-foot"><span class="offline"><span class="dot"></span>Offline. No data leaves this machine.</span><span>Knowledge base ' + U.esc(c.idx.kb.kb_version) + '</span></div>';
  }

  function topbar(c) {
    const m = c.eng && c.eng.meta;
    const saved = S.storageOk ? (S.savedAt ? 'Saved in this browser ' + U.fmtDateTime(S.savedAt).split(', ')[1] : '') : 'Not saved: browser storage unavailable';
    return '<header class="topbar">' +
      (c.eng ? '<div class="case"><span class="case-client" id="tb-client">' + U.esc(m.client || 'Untitled engagement') + '</span><span class="case-meta"><span class="mono" id="tb-ref">' + U.esc(m.ref || '') + '</span><span>' + U.plural(Object.keys(c.eng.scope.platforms).length, 'platform') + ' in scope</span></span></div>' + (c.eng.sample ? '<span class="sample-flag">Sample data · fictional</span>' : '') : '<div class="case"><span class="case-client">No engagement open</span></div>') +
      '<span class="spacer"></span><span class="saved">' + U.esc(saved) + '</span>' +
      (c.eng ? '<button class="btn" data-action="save-file">' + U.icon('download') + 'Save engagement file</button>' : '') +
      '<div class="menu"><button class="btn ghost" data-action="menu" aria-haspopup="true" aria-expanded="' + menuOpen + '" aria-label="More">' + U.icon('more') + '</button>' +
      (menuOpen ? '<div class="menu-pop" role="menu">' +
        '<label class="btn ghost" style="justify-content:flex-start;border:0">' + U.icon('upload') + 'Open engagement file…<input type="file" accept=".json" hidden data-action-change="open-file"></label>' +
        '<button data-action="new-engagement">New engagement<small>Replaces the engagement held in this browser</small></button>' +
        '<button data-action="load-sample">Load the sample engagement<small>Fictional client for demonstration and training</small></button>' +
        (c.eng ? '<button data-action="close-engagement">Close engagement<small>Clears it from this browser. Save the file first.</small></button>' : '') +
        '<hr><button data-action="theme">Theme: ' + ({ '': 'follow system', dark: 'dark', light: 'light' }[S.ui.theme || '']) + '<small>Click to change</small></button>' +
        '<div style="padding:6px 10px"><label class="flabel" for="assessor">Your name (activity log)</label><input class="input" id="assessor" data-assessor="1" value="' + U.esc(S.ui.assessor || '') + '" placeholder="Assessor" style="margin-top:4px"></div>' +
        '</div>' : '') + '</div></header>';
  }

  function render(opts) {
    opts = opts || {};
    const c = ctx(opts);
    const app = document.getElementById('app');
    const keep = {};
    U.$$('[data-keep-scroll]').forEach(el => { keep[el.dataset.keepScroll] = el.scrollTop; });
    const winY = window.scrollY;
    const focus = document.activeElement && (document.activeElement.dataset.filter || document.activeElement.dataset.libq) ? { filter: document.activeElement.dataset.filter, libq: document.activeElement.dataset.libq, pos: document.activeElement.selectionStart } : null;
    const view = A.views[S.ui.view] || A.views.overview;
    let body;
    try { body = view.render(c); } catch (e) { console.error(e); body = '<div class="sheet empty">This view could not be drawn: ' + U.esc(e.message) + '</div>'; }
    if (S.ui.view !== 'report') document.documentElement.classList.remove('reading');
    app.innerHTML = '<aside class="rail">' + rail(c) + '</aside><div class="main">' + topbar(c) + '<main class="view view-' + U.esc(S.ui.view) + '" id="view">' + body + '</main></div>';
    U.$$('[data-keep-scroll]').forEach(el => { if (keep[el.dataset.keepScroll] != null) el.scrollTop = keep[el.dataset.keepScroll]; });
    window.scrollTo(0, winY);
    if (focus) {
      const el = focus.filter ? U.$('[data-filter="' + focus.filter + '"]') : U.$('[data-libq]');
      if (el) { el.focus(); try { el.setSelectionRange(focus.pos, focus.pos); } catch (e) { /* not a text input */ } }
    }
    if (view.mount) view.mount(U.$('#view'), c);
    applyTheme();
  }

  function applyTheme() {
    if (S.ui.theme) document.documentElement.setAttribute('data-theme', S.ui.theme);
    else document.documentElement.removeAttribute('data-theme');
  }

  function setPath(path, value) {
    const parts = path.split('.');
    let o = S.eng;
    for (let i = 0; i < parts.length - 1; i++) o = o[parts[i]];
    o[parts[parts.length - 1]] = value;
  }

  function confirmTwice(key, msg) {
    if (armed[key] && Date.now() - armed[key] < 5000) { delete armed[key]; return true; }
    armed[key] = Date.now();
    U.toast(msg);
    return false;
  }

  /* ---- global actions ---- */
  A.actions.go = (el, ev) => {
    ev.preventDefault();
    menuOpen = false;
    S.go(el.dataset.view);
    if (el.dataset.anchor) setTimeout(() => { const t = document.getElementById(el.dataset.anchor); if (t) t.scrollIntoView({ block: 'start' }); }, 30);
  };
  A.actions.menu = () => { menuOpen = !menuOpen; render(); };
  A.actions['save-file'] = () => { S.exportEngagement(); U.toast('Engagement file saved to your downloads folder'); };
  A.actions['new-engagement'] = () => {
    if (S.eng && !confirmTwice('new', 'Click again to start a new engagement. Save the current engagement file first.')) return;
    menuOpen = false; S.newEngagement();
  };
  A.actions['load-sample'] = () => {
    if (S.eng && !S.eng.sample && !confirmTwice('sample', 'Click again to replace the current engagement with the sample. Save it first.')) return;
    menuOpen = false; S.loadSample();
  };
  A.actions['close-engagement'] = () => {
    if (!confirmTwice('close', 'Click again to clear this engagement from the browser. Save the file first.')) return;
    menuOpen = false; S.close(); U.toast('Engagement closed');
  };
  A.actions.theme = () => { S.ui.theme = { '': 'dark', dark: 'light', light: '' }[S.ui.theme || '']; S.saveUI(); render(); };
  A.actions['open-file'] = async el => {
    const f = el.files && el.files[0];
    if (!f) return;
    try {
      const buf = await U.readFile(f);
      const obj = JSON.parse(U.decode(buf));
      menuOpen = false;
      S.openObject(obj);
      U.toast('Opened ' + f.name);
    } catch (e) { U.toast('Could not open: ' + e.message); }
  };
  A.actions.copy = async (el, ev) => { ev.stopPropagation(); const ok = await U.copy(el.dataset.text); U.toast(ok ? 'Copied' : 'Copy failed. Select the text instead.'); };

  /* ---- events ---- */
  function bindEvents() {
    document.addEventListener('click', e => {
      if (menuOpen && !e.target.closest('.menu')) { menuOpen = false; render(); }
      const t = e.target.closest('[data-action]');
      if (!t) return;
      const fn = A.actions[t.dataset.action];
      if (fn) fn(t, e, ctx());
    });
    document.addEventListener('change', e => {
      const t = e.target;
      if (t.dataset.actionChange) { const fn = A.actions[t.dataset.actionChange]; if (fn) fn(t, e, ctx()); return; }
      if (!S.eng) return;
      if (t.dataset.bindChange) { setPath(t.dataset.bindChange, t.value); S.commit(); return; }
      if (t.dataset.scope && t.tagName === 'SELECT') { S.setScopeField(t.dataset.scope, t.dataset.field, t.value); return; }
      if (t.dataset.filter && t.tagName === 'SELECT') { S.ui.filters[t.dataset.filter] = t.value; S.ui.sel = null; S.saveUI(); render(); return; }
      if (t.dataset.bind) { render(); return; }
      if (t.dataset.ret) { S.commit(); }
    });
    const searchRender = U.debounce(() => render(), 160);
    document.addEventListener('input', e => {
      const t = e.target;
      if (t.dataset.assessor) { S.ui.assessor = t.value; S.saveUI(); return; }
      if (t.dataset.libq) { S.ui.libQ = t.value; S.saveUI(); searchRender(); return; }
      if (t.dataset.filter === 'q') { S.ui.filters.q = t.value; S.saveUI(); searchRender(); return; }
      if (!S.eng) return;
      if (t.dataset.bind) {
        const num = t.type === 'number';
        setPath(t.dataset.bind, num ? (t.value === '' ? '' : Number(t.value)) : t.value);
        S.commit({ quiet: true });
        if (t.dataset.bind === 'meta.client') { const el = U.$('#tb-client'); if (el) el.textContent = t.value || 'Untitled engagement'; }
        if (t.dataset.bind === 'meta.ref') { const el = U.$('#tb-ref'); if (el) el.textContent = t.value; }
        return;
      }
      if (t.dataset.scope && t.tagName === 'INPUT') { S.setScopeField(t.dataset.scope, t.dataset.field, t.value, true); return; }
      if (t.dataset.note) { S.setNote(t.dataset.note, t.value); return; }
      if (t.dataset.ret) { S.setRetention(t.dataset.ret, t.dataset.field, t.dataset.field === 'days' ? (t.value === '' ? '' : Number(t.value)) : t.value); }
    });
    document.addEventListener('keydown', e => {
      const t = e.target;
      if (t.classList && t.classList.contains('pcard') && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); S.toggleScope(t.dataset.pid); return; }
      if (e.key === 'Escape' && menuOpen) { menuOpen = false; render(); return; }
      if (t.matches && t.matches('input, textarea, select, [contenteditable]')) return;
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      if (S.eng && S.ui.view === 'assess' && A.keys && A.keys.assess) { if (A.keys.assess(e, ctx())) e.preventDefault(); }
    });
    window.addEventListener('storage', ev => { if (ev.key && ev.key.indexOf('aifr.workbench.engagement') === 0) { S.init(); render(); } });
  }

  /* Deep links: #results opens a view; #sample-results also loads the sample when no client engagement is open. */
  function fromHash() {
    const tokens = (location.hash || '').slice(1).toLowerCase().split(/[-,&/]/).filter(Boolean);
    if (!tokens.length) return;
    if (tokens.indexOf('sample') >= 0 && (!S.eng || S.eng.sample)) S.loadSampleQuiet();
    if (tokens.indexOf('dark') >= 0) S.ui.theme = 'dark';
    if (tokens.indexOf('light') >= 0) S.ui.theme = 'light';
    const v = tokens.find(t => A.views[t]);
    if (v) S.ui.view = v;
  }

  function start() {
    S.init();
    fromHash();
    applyTheme();
    C.installTips();
    S.on(() => render());
    bindEvents();
    render();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
  A.app = { render };
})(typeof window !== 'undefined' ? window : globalThis);
