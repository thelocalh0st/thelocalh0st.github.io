/* Visual components shared by Results and the client report. All return HTML/SVG strings. */
(function (root) {
  'use strict';
  const U = root.AIFR.util;
  const C = {};
  const esc = U.esc;

  const EV_GLYPH = { ok: '✓', assumed: '✓', partial: '◐', claimed: '?', off: '✕', none: '', unknown: '?', na: '·' };
  const EV_LABEL = {
    ok: 'Verified available', assumed: 'Native, not yet verified', partial: 'Partial', claimed: 'Claimed, not evidenced',
    off: 'Available but not enabled', none: 'Not available from the vendor', unknown: 'Not yet assessed', na: 'Not applicable'
  };
  C.EV_LABEL = EV_LABEL;
  const LEVEL_SHORT = ['No record', 'Activity only', 'Content retrievable', 'Content preserved', 'Reconstructable'];
  C.LEVEL_SHORT = LEVEL_SHORT;

  /* Maturity ladder: one row per platform, cells for levels 1-4; dashed cells show what configuration alone reaches. */
  C.ladder = function (rows, opts) {
    opts = opts || {};
    if (!rows.length) return '<div class="empty">No AI platforms in scope.</div>';
    let h = '<div class="ladder" role="table" aria-label="Readiness level by platform">';
    h += '<div class="lh">Platform</div>';
    for (let n = 1; n <= 4; n++) h += '<div class="lh c" title="' + esc(LEVEL_SHORT[n]) + '">' + n + '</div>';
    h += '<div class="lh w">Current level and what holds it back</div>';
    rows.forEach(r => {
      h += '<div class="ln"' + (opts.link ? ' data-action="go-platform" data-pid="' + esc(r.pid) + '" style="cursor:pointer"' : '') + '><span>' + esc(r.name) + '</span></div>';
      for (let n = 1; n <= 4; n++) {
        let cls = 'blank';
        if (n <= r.level) cls = 'f' + n;
        else if (n <= r.achievable) cls = 'ghost';
        h += '<div class="lc"><i class="' + cls + '" data-tip="' + esc(r.name + ': Level ' + n + ' ' + LEVEL_SHORT[n] + (n <= r.level ? ' (reached)' : n <= r.achievable ? ' (reachable by configuration)' : '')) + '"></i></div>';
      }
      h += '<div class="lw"><span>' + U.lvl(r.level) + ' &nbsp;' + esc(r.why) + (r.achievable > r.level ? ' <span class="muted">Reachable: L' + r.achievable + '.</span>' : '') + '</span></div>';
    });
    h += '</div>';
    h += '<div class="legend" style="margin-top:10px"><span><i style="background:var(--lv1)"></i>Level reached</span><span><i style="border:1.5px dashed var(--line-2)"></i>Reachable by configuration alone</span><span>1 Activity only · 2 Content retrievable · 3 Content preserved · 4 Reconstructable</span></div>';
    return h;
  };

  /* Evidence coverage matrix: platforms × E1-E12. */
  C.matrix = function (idx, rows) {
    if (!rows.length) return '<div class="empty">No platforms in scope.</div>';
    const evs = idx.kb.evidence;
    let h = '<div class="tbl-wrap"><table class="matrix" aria-label="Evidence coverage matrix"><thead><tr><th></th>';
    evs.forEach(e => { h += '<th data-tip="' + esc(e.id + ' ' + e.label + ': ' + e.q) + '">' + e.id + '<br><span style="font-weight:500">' + esc(e.label) + '</span></th>'; });
    h += '</tr></thead><tbody>';
    rows.forEach(r => {
      h += '<tr><th class="rowh">' + esc(r.name) + '</th>';
      evs.forEach(e => {
        const st = r.ev[e.id];
        h += '<td class="cell ev-' + st + '" data-tip="' + esc(r.name + ' · ' + e.id + ' ' + e.label + ': ' + EV_LABEL[st]) + '">' + EV_GLYPH[st] + '</td>';
      });
      h += '</tr>';
    });
    h += '</tbody></table></div>';
    h += C.matrixLegend();
    return h;
  };
  C.matrixLegend = function () {
    const items = ['ok', 'assumed', 'partial', 'claimed', 'off', 'none', 'unknown'];
    return '<div class="legend" style="margin-top:10px">' + items.map(s => '<span><i class="ev-' + s + '" style="width:14px;height:14px;display:inline-grid;place-items:center;font-size:9px;font-style:normal;font-weight:800">' + EV_GLYPH[s] + '</i>' + EV_LABEL[s] + '</span>').join('') + '</div>';
  };

  /* Four questions grid. */
  C.keyGrid = function (idx, kg) {
    if (!kg.rows.length) return '<div class="empty">No key checks in scope.</div>';
    const glyph = { met: '✓', partial: '◐', gap: '✕', open: '?', unverified: '?', none: '', na: '·' };
    const cls = { met: 'ok', partial: 'partial', gap: 'off', open: 'unknown', unverified: 'claimed', none: 'unknown', na: 'na' };
    let h = '<div class="tbl-wrap"><table class="matrix kgrid"><thead><tr><th></th>';
    idx.kb.keys.forEach(k => { h += '<th data-tip="' + esc(k.desc) + '">' + k.id + '<br><span style="font-weight:500">' + esc(k.label) + '</span></th>'; });
    h += '</tr></thead><tbody>';
    kg.rows.forEach(r => {
      h += '<tr><th class="rowh">' + esc(r.name) + '</th>';
      idx.kb.keys.forEach(k => { const s = r.cells[k.id]; h += '<td class="cell ev-' + cls[s] + '" data-tip="' + esc(r.name + ' · ' + k.label + ' ' + (s === 'na' ? 'No check' : s)) + '">' + glyph[s] + '</td>'; });
      h += '</tr>';
    });
    return h + '</tbody></table></div>';
  };

  /* Lookback (evidence horizon): bars of retained days against target and legal floors. */
  C.horizon = function (hz, opts) {
    opts = opts || {};
    const rows = hz.rows.filter(r => r.days != null).sort((a, b) => a.days - b.days);
    const unset = hz.rows.filter(r => r.days == null);
    if (!rows.length) return '<div class="empty">No retention values recorded yet.</div>';
    const floorMax = Math.max.apply(null, [0].concat(hz.floors.map(f => f.days)));
    const cap = Math.max(hz.target * 1.3, floorMax * 1.3, 120);
    const W = opts.width || 900, labelW = opts.labelW || 300, valW = 86, rowH = opts.rowH || 22, top = 34;
    const plotW = W - labelW - valW;
    const x = d => labelW + Math.min(d, cap) / cap * plotW;
    const H = top + rows.length * rowH + 14;
    // red: below the lowest legal floor that applies; amber: between that floor and the target
    const floorWarn = hz.floors.length ? Math.min.apply(null, hz.floors.map(f => f.days)) : 90;
    let s = '<svg class="svg-chart" viewBox="0 0 ' + W + ' ' + H + '" width="100%" role="img" aria-label="Retention by evidence source">';
    // ticks
    const step = cap > 700 ? 180 : cap > 360 ? 90 : 30;
    s += '<g class="grid">';
    for (let d = 0; d <= cap; d += step) s += '<line x1="' + x(d) + '" x2="' + x(d) + '" y1="' + (top - 6) + '" y2="' + (H - 10) + '"/><text x="' + x(d) + '" y="' + (top - 10) + '" text-anchor="middle">' + d + '</text>';
    s += '</g>';
    rows.forEach((r, i) => {
      const y = top + i * rowH;
      const tone = r.days >= hz.target ? 'good' : r.days >= floorWarn ? 'warn' : 'bad';
      const w = Math.max(r.days === 0 ? 0 : 2, x(r.days) - labelW);
      const label = r.platform + ' · ' + r.name;
      s += '<text class="lbl" x="' + (labelW - 8) + '" y="' + (y + rowH / 2 + 4) + '" text-anchor="end">' + esc(label.length > 46 ? label.slice(0, 45) + '…' : label) + '</text>';
      s += '<rect x="' + labelW + '" y="' + (y + 5) + '" width="' + w + '" height="' + (rowH - 10) + '" rx="2" class="hz-' + tone + '" data-tip="' + esc(label + ': ' + U.days(r.days) + (r.assessed ? ' (assessed)' : ' (vendor default)') + (r.oldest ? '; oldest record ' + U.fmtDate(r.oldest) : '')) + '"/>';
      if (r.days > cap) s += '<path d="M' + (x(cap) + 2) + ' ' + (y + 6) + 'l6 ' + ((rowH - 12) / 2) + 'l-6 ' + ((rowH - 12) / 2) + 'z" class="hz-' + tone + '"/>';
      s += '<text x="' + (Math.min(x(r.days), x(cap)) + (r.days > cap ? 14 : 6)) + '" y="' + (y + rowH / 2 + 4) + '" class="lbl" style="font-weight:600">' + esc(r.days === 0 ? 'not kept' : U.days(r.days)) + (r.assessed ? '' : ' *') + '</text>';
    });
    // reference lines
    hz.floors.forEach(f => {
      s += '<line x1="' + x(f.days) + '" x2="' + x(f.days) + '" y1="' + (top - 4) + '" y2="' + (H - 10) + '" class="hz-floor"><title>' + esc(f.label) + '</title></line>';
    });
    s += '<line x1="' + x(hz.target) + '" x2="' + x(hz.target) + '" y1="' + (top - 4) + '" y2="' + (H - 10) + '" class="hz-target"/>';
    s += '</svg>';
    let legend = '<div class="legend" style="margin-top:8px"><span><i class="hz-good-bg"></i>Meets target (' + hz.target + ' days)</span><span><i class="hz-warn-bg"></i>Below target</span><span><i class="hz-bad-bg"></i>Below ' + (hz.floors.length ? 'the lowest legal floor (' + floorWarn + ' days)' : floorWarn + ' days') + '</span><span><i style="border-left:2px solid var(--accent);border-radius:0;height:12px"></i>Target</span>';
    hz.floors.forEach(f => { legend += '<span><i style="border-left:2px dashed var(--muted);border-radius:0;height:12px"></i>' + esc(f.label) + ' (' + f.days + ' d)</span>'; });
    legend += '<span>* vendor default, not yet confirmed in this tenant</span></div>';
    if (unset.length && !opts.hideUnset) legend += '<details class="xs muted" style="margin-top:8px"><summary style="cursor:pointer">' + U.plural(unset.length, 'source') + ' with client-set retention not yet recorded</summary><p style="margin-top:4px">' + unset.map(r => esc(r.platform + ' · ' + r.name)).join('; ') + '. Record them in Assess, on the retention check of each platform.</p></details>';
    return s + legend;
  };

  /* Capability domains as bars. */
  C.domainBars = function (doms) {
    return doms.map(d => {
      const v = d.score == null ? null : Math.round(d.score * 100);
      const tone = v == null ? '' : v < 40 ? 'lo' : v < 70 ? 'mid' : 'hi';
      return '<div class="dbar"><div><div style="font-weight:600">' + esc(d.label) + '</div><div class="xs muted">' + d.assessed + ' of ' + d.total + ' checks assessed</div></div>' +
        '<div class="track ' + tone + '"><span style="width:' + (v || 0) + '%"></span></div><div class="num" style="text-align:right;font-weight:650">' + (v == null ? '–' : v + '%') + '</div></div>';
    }).join('');
  };

  /* Scenario cards. */
  C.scenarioCards = function (list, opts) {
    opts = opts || {};
    return list.filter(s => s.applicable).map(s => {
      const pills = s.questions.map(q => '<span class="p-' + q.status + '" data-tip="' + esc(q.q) + '"></span>').join('');
      let qs = '';
      if (opts.expand) {
        qs = s.questions.map(q => {
          const mark = { yes: '✓', partial: '◐', no: '✕', na: '·' }[q.status];
          const per = q.per.filter(p => p.v < 2).map(p => '<span class="' + (p.v === 1 ? 'st-partial' : 'st-gap') + '">' + esc(p.name) + (p.gaps.length ? ' · ' + p.gaps.join(' ') : '') + '</span>').join('');
          return '<div class="qrow"><span class="qmark q-' + q.status + '">' + mark + '</span><div>' + esc(q.q) + (per ? '<div class="qper">' + per + '</div>' : '') + '</div><span class="xs muted">' + q.needs.join(' ') + '</span></div>';
        }).join('');
      }
      return '<div class="sheet scard"><div class="sc-top"><div><span class="eyebrow">' + s.id + '</span><h3>' + esc(s.title) + '</h3></div><div class="score">' + s.yes + '<small> / ' + s.total + '</small></div></div>' +
        '<div class="pills">' + pills + '</div><div class="xs muted">' + s.yes + ' answerable, ' + s.partial + ' in part, across ' + esc(s.platforms.join(', ')) + '</div>' + qs + '</div>';
    }).join('');
  };

  /* Target-state architecture with component status. */
  C.architecture = function (idx, eng, comps, scoped) {
    const E = root.AIFR.engine;
    const by = {}; comps.forEach(c => { by[c.id] = c; });
    const cats = idx.kb.categories.map(c => ({ label: c.label, n: scoped.filter(pid => idx.platforms[pid].category === c.id).length })).filter(c => c.n);
    const W = 980, H = 470;
    const tone = c => c.state === 'met' ? 'good' : c.state === 'partial' ? 'warn' : c.state === 'gap' ? 'bad' : 'open';
    const pct = c => c.score == null ? 'not assessed' : Math.round(c.score * 100) + '% in place';
    const lines = (label, max) => {
      const out = [''];
      label.split(' ').forEach(w => { const l = out[out.length - 1]; if ((l + ' ' + w).trim().length > max && l) out.push(w); else out[out.length - 1] = (l + ' ' + w).trim(); });
      return out;
    };
    const box = (c, x, y, w, h) => {
      const t = tone(c);
      const ls = lines(c.label, Math.floor((w - 24) / 7.4));
      return '<g data-tip="' + esc(c.label + ': ' + c.desc + ' ' + (c.total ? pct(c) + ', ' + c.gaps + ' gaps across ' + c.total + ' checks' : 'No checks in scope')) + '">' +
        '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="7" class="arch-box arch-' + t + '"/>' +
        '<rect x="' + x + '" y="' + y + '" width="5" height="' + h + '" rx="2" class="arch-strip-' + t + '"/>' +
        ls.map((l, i) => '<text x="' + (x + 16) + '" y="' + (y + 24 + i * 17) + '" class="lbl" style="font-weight:650;font-size:13.5px">' + esc(l) + '</text>').join('') +
        '<text x="' + (x + 16) + '" y="' + (y + 26 + ls.length * 17) + '" style="font-size:12px">' + esc(c.total ? pct(c) : 'not in scope') + '</text>' +
        (c.total ? '<text x="' + (x + 16) + '" y="' + (y + 42 + ls.length * 17) + '" style="font-size:12px">' + esc(U.plural(c.gaps, 'gap') + ' of ' + c.total + ' checks') + '</text>' : '') + '</g>';
    };
    let s = '<svg class="svg-chart" viewBox="0 0 ' + W + ' ' + H + '" width="100%" role="img" aria-label="Target-state evidence architecture">';
    s += '<defs><marker id="arr" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L8 4L0 8z" class="arch-arrow"/></marker></defs>';
    // columns: estate | capture | store | investigate
    const top = 36, capH = 72, capGap = 12, bottom = top + 5 * capH + 4 * capGap;
    const X = { est: 20, cap: 258, sto: 604, inv: 838 }, Wd = { est: 196, cap: 300, sto: 196, inv: 126 };
    const heads = [['AI estate', X.est], ['Capture', X.cap], ['Evidence store', X.sto], ['Investigate', X.inv]];
    heads.forEach(hd => { s += '<text x="' + hd[1] + '" y="20" style="font-weight:700;letter-spacing:1px;text-transform:uppercase;font-size:10.5px">' + hd[0] + '</text>'; });
    s += '<rect x="' + X.est + '" y="' + top + '" width="' + Wd.est + '" height="' + (bottom - top) + '" rx="8" class="arch-estate"/>';
    const SHORT = { 'Workplace AI assistants': 'Workplace AI', 'AI coding assistants & agents': 'Coding assistants', 'Cloud AI platforms & APIs': 'Cloud AI platforms', 'Internal & self-hosted AI': 'Internal AI', 'Foundations': 'Foundations' };
    cats.forEach((c, i) => { s += '<text x="' + (X.est + 16) + '" y="' + (top + 30 + i * 30) + '" class="lbl" style="font-size:13px">' + esc(SHORT[c.label] || c.label) + '</text><text x="' + (X.est + Wd.est - 14) + '" y="' + (top + 30 + i * 30) + '" text-anchor="end" style="font-weight:700;font-size:13px">' + c.n + '</text>'; });
    ['C1', 'C2', 'C3', 'C4', 'C5'].forEach((id, i) => { s += box(by[id], X.cap, top + i * (capH + capGap), Wd.cap, capH); });
    const stoH = (bottom - top - 16) / 2;
    s += box(by.C6, X.sto, top, Wd.sto, stoH);
    s += box(by.C7, X.sto, top + stoH + 16, Wd.sto, stoH);
    s += box(by.C8, X.inv, top, Wd.inv, bottom - top);
    // flows: estate -> capture -> central retention -> integrity; both stores -> investigation
    for (let i = 0; i < 5; i++) {
      const y = top + i * (capH + capGap) + capH / 2;
      s += '<line x1="' + (X.est + Wd.est + 2) + '" y1="' + y + '" x2="' + (X.cap - 4) + '" y2="' + y + '" class="arch-flow" marker-end="url(#arr)"/>';
      s += '<line x1="' + (X.cap + Wd.cap + 2) + '" y1="' + y + '" x2="' + (X.sto - 4) + '" y2="' + (top + 30 + i * ((stoH - 50) / 4)) + '" class="arch-flow" marker-end="url(#arr)"/>';
    }
    s += '<line x1="' + (X.sto + Wd.sto / 2) + '" y1="' + (top + stoH + 2) + '" x2="' + (X.sto + Wd.sto / 2) + '" y2="' + (top + stoH + 12) + '" class="arch-flow" marker-end="url(#arr)"/>';
    s += '<line x1="' + (X.sto + Wd.sto + 2) + '" y1="' + (top + stoH / 2) + '" x2="' + (X.inv - 4) + '" y2="' + (top + stoH / 2) + '" class="arch-flow" marker-end="url(#arr)"/>';
    s += '<line x1="' + (X.sto + Wd.sto + 2) + '" y1="' + (top + stoH * 1.5 + 16) + '" x2="' + (X.inv - 4) + '" y2="' + (top + stoH * 1.5 + 16) + '" class="arch-flow" marker-end="url(#arr)"/>';
    s += '</svg>';
    s += '<div class="legend" style="margin-top:8px"><span><i class="hz-good-bg"></i>In place (85%+)</span><span><i class="hz-warn-bg"></i>Partly in place</span><span><i class="hz-bad-bg"></i>Largely missing</span><span><i style="background:var(--surface-3)"></i>Not assessed</span></div>';
    return s;
  };

  C.roadmap = function (rm, opts) {
    opts = opts || {};
    return '<div class="roadmap">' + rm.map(ph => {
      const items = ph.items.slice(0, opts.limit || 12);
      return '<div class="sheet rm-col"><h3><span>' + esc(ph.label) + '</span><span class="muted num">' + ph.items.length + '</span></h3>' +
        (items.length ? items.map(f => '<div class="rm-item"' + (opts.link ? ' data-action="open-control" data-cid="' + esc(f.id) + '" style="cursor:pointer"' : '') + '><span class="rmt">' + esc(f.title) + '</span><span class="xs" style="color:var(--ink-2)">' + esc(f.fix) + '</span><span class="rmm">' + U.sevTag(f.severity) + '<span class="mono">' + esc(f.id) + '</span><span>' + esc(f.platform) + '</span><span>Effort ' + f.effort + '</span><span>' + esc(f.owner) + '</span></span></div>').join('') : '<div class="empty small">Nothing in this window.</div>') +
        (ph.items.length > items.length ? '<div class="rm-item muted small">and ' + (ph.items.length - items.length) + ' more</div>' : '') + '</div>';
    }).join('') + '</div>';
  };

  C.findingsTable = function (list, opts) {
    opts = opts || {};
    if (!list.length) return '<div class="empty">No findings. Every assessed check is met or not applicable.</div>';
    return '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Severity</th><th>Check</th><th>Platform</th><th>Finding</th><th>Status</th><th>Window</th></tr></thead><tbody>' +
      list.map(f => '<tr class="click" data-action="open-control" data-cid="' + esc(f.id) + '"><td>' + U.sevTag(f.severity) + '</td><td class="id">' + esc(f.id) + (f.key ? ' <span class="tag key">' + f.key + '</span>' : '') + '</td><td>' + esc(f.platform) + '</td><td>' + esc(f.title) + (f.note ? '<div class="xs muted">' + esc(f.note) + '</div>' : '') + '</td><td>' + U.statusChip(f.status) + '</td><td class="xs">' + ({ P1: '0-30 d', P2: '31-90 d', P3: '90+ d' }[f.phase]) + '</td></tr>').join('') +
      '</tbody></table></div>';
  };

  /* Tooltip for any element with data-tip. */
  let tipEl = null;
  C.installTips = function () {
    if (tipEl) return;
    tipEl = document.createElement('div'); tipEl.className = 'tip'; tipEl.hidden = true; document.body.appendChild(tipEl);
    document.addEventListener('mouseover', e => {
      const t = e.target.closest && e.target.closest('[data-tip]');
      if (!t) { tipEl.hidden = true; return; }
      tipEl.textContent = t.getAttribute('data-tip'); tipEl.hidden = false;
    });
    document.addEventListener('mousemove', e => {
      if (tipEl.hidden) return;
      const pad = 14, w = tipEl.offsetWidth, h = tipEl.offsetHeight;
      let x = e.clientX + pad, y = e.clientY + pad;
      if (x + w > window.innerWidth - 8) x = e.clientX - w - pad;
      if (y + h > window.innerHeight - 8) y = e.clientY - h - pad;
      tipEl.style.left = x + 'px'; tipEl.style.top = y + 'px';
    });
    document.addEventListener('scroll', () => { tipEl.hidden = true; }, true);
  };

  root.AIFR.charts = C;
})(typeof window !== 'undefined' ? window : globalThis);
