/* Engagement state: load, save (browser storage + engagement file), mutations, activity log. */
(function (root) {
  'use strict';
  const U = root.AIFR.util;
  const E = root.AIFR.engine;
  const KEY = 'aifr.workbench.engagement.v1';
  const UIKEY = 'aifr.workbench.ui.v1';
  const SCHEMA = 'aifr.engagement/1';

  const S = {
    kb: null, idx: null, eng: null, savedAt: null, storageOk: true,
    ui: { view: 'overview', sel: null, filters: { platform: '', domain: '', status: '', key: '', method: '', q: '' }, libSel: null, libTab: 'platforms', theme: '', assessor: '', report: { appendix: true, register: true } },
    listeners: []
  };

  function today() { return new Date().toISOString().slice(0, 10); }

  function blank() {
    return {
      schema: SCHEMA, id: U.uid('eng'), createdAt: U.now(), updatedAt: U.now(),
      meta: { client: '', ref: 'AIFR-' + new Date().getFullYear() + '-', firm: '', lead: '', team: '', start: today(), end: '', sector: '', jurisdictions: [], targetDays: 365, classification: 'Confidential', objective: '', employees: '', endpoints: '' },
      scope: { platforms: {} }, results: {}, retention: {}, runbook: {}, bundles: [], log: []
    };
  }

  function migrate(e) {
    const b = blank();
    const out = Object.assign(b, e);
    out.meta = Object.assign(blank().meta, e.meta || {});
    out.scope = e.scope && e.scope.platforms ? e.scope : { platforms: {} };
    ['results', 'retention', 'runbook'].forEach(k => { if (!out[k] || typeof out[k] !== 'object') out[k] = {}; });
    ['bundles', 'log'].forEach(k => { if (!Array.isArray(out[k])) out[k] = []; });
    // drop scope entries the KB no longer knows
    Object.keys(out.scope.platforms).forEach(pid => { if (!S.idx.platforms[pid]) delete out.scope.platforms[pid]; });
    return out;
  }

  S.init = function () {
    S.kb = JSON.parse(document.getElementById('aifr-kb').textContent);
    S.idx = E.indexKB(S.kb);
    try { const ui = JSON.parse(localStorage.getItem(UIKEY) || 'null'); if (ui) S.ui = Object.assign(S.ui, ui, { filters: Object.assign(S.ui.filters, ui.filters || {}) }); } catch (e) { /* storage unavailable */ }
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) { S.eng = migrate(JSON.parse(raw)); S.savedAt = S.eng.updatedAt; }
    } catch (e) { S.storageOk = false; }
  };

  S.sample = function () {
    try { return JSON.parse(document.getElementById('aifr-sample').textContent); } catch (e) { return null; }
  };

  S.on = fn => { S.listeners.push(fn); };
  S.emit = () => { S.listeners.forEach(fn => fn()); };

  function persist() {
    if (!S.eng) return;
    try {
      localStorage.setItem(KEY, JSON.stringify(S.eng));
      S.savedAt = U.now(); S.storageOk = true;
    } catch (e) {
      S.storageOk = false;
      U.toast('Browser storage is unavailable or full. Save the engagement file to keep your work.');
    }
  }
  const persistSoon = U.debounce(persist, 400);
  S.saveUI = () => { try { localStorage.setItem(UIKEY, JSON.stringify(S.ui)); } catch (e) { /* ignore */ } };

  S.commit = function (opts) {
    if (S.eng) S.eng.updatedAt = U.now();
    if (opts && opts.quiet) { persistSoon(); return; }
    persist();
    S.emit();
  };

  S.who = () => S.ui.assessor || (S.eng && S.eng.meta.lead) || 'Assessor';
  S.log = function (action) {
    if (!S.eng) return;
    S.eng.log.push({ at: U.now(), by: S.who(), action });
    if (S.eng.log.length > 500) S.eng.log.splice(0, S.eng.log.length - 500);
  };

  S.newEngagement = function () {
    S.eng = blank();
    S.log('Engagement created');
    S.ui.view = 'scope'; S.ui.sel = null; S.saveUI();
    S.commit();
  };
  S.loadSample = function () {
    const s = S.sample();
    if (!s) { U.toast('No sample is bundled with this build.'); return; }
    S.eng = migrate(s);
    S.ui.view = 'overview'; S.ui.sel = null; S.saveUI();
    S.commit();
    U.toast('Sample engagement loaded. All names and figures are fictional.');
  };
  S.loadSampleQuiet = function () {
    const s = S.sample();
    if (!s) return false;
    S.eng = migrate(s);
    S.commit({ quiet: true });
    return true;
  };
  S.openObject = function (obj) {
    if (!obj || typeof obj.schema !== 'string' || obj.schema.indexOf('aifr.engagement/') !== 0) throw new Error('This file is not an AIFR engagement file.');
    S.eng = migrate(obj);
    S.log('Engagement file opened');
    S.ui.view = 'overview'; S.ui.sel = null; S.saveUI();
    S.commit();
  };
  S.close = function () {
    S.eng = null;
    try { localStorage.removeItem(KEY); } catch (e) { /* ignore */ }
    S.ui.view = 'overview'; S.saveUI();
    S.emit();
  };
  S.fileName = function (suffix) {
    const m = S.eng.meta;
    const base = [U.slug(m.client) || 'engagement', U.slug(m.ref)].filter(Boolean).join('_');
    return base + '_' + today() + (suffix || '.aifr.json');
  };
  S.exportEngagement = function () {
    S.log('Engagement file saved');
    S.commit({ quiet: true });
    U.download(S.fileName(), JSON.stringify(S.eng, null, 1), 'application/json');
  };

  /* ---- navigation ---- */
  S.go = function (view, sel) {
    S.ui.view = view;
    if (sel !== undefined) S.ui.sel = sel;
    S.saveUI();
    S.emit();
    window.scrollTo(0, 0);
  };

  /* ---- mutations ---- */
  S.setMeta = function (field, value, quiet) { S.eng.meta[field] = value; S.commit({ quiet: !!quiet }); };

  S.toggleScope = function (pid) {
    const sp = S.eng.scope.platforms;
    if (sp[pid]) { delete sp[pid]; S.log('Removed from scope: ' + S.idx.platforms[pid].short); }
    else { sp[pid] = { variant: '', owner: '', notes: '' }; S.log('Added to scope: ' + S.idx.platforms[pid].short); }
    S.commit();
  };
  S.setScopeField = function (pid, field, value, quiet) {
    if (!S.eng.scope.platforms[pid]) return;
    S.eng.scope.platforms[pid][field] = value;
    S.commit({ quiet: !!quiet });
  };

  S.result = cid => (S.eng && S.eng.results[cid]) || { status: 'open', evidence: [] };
  S.ensureResult = function (cid) {
    if (!S.eng.results[cid]) S.eng.results[cid] = { status: 'open', note: '', evidence: [] };
    if (!S.eng.results[cid].evidence) S.eng.results[cid].evidence = [];
    return S.eng.results[cid];
  };
  S.setStatus = function (cid, status) {
    const r = S.ensureResult(cid);
    if (r.status === status) return;
    const prev = r.status;
    r.status = status; r.source = 'manual'; r.by = S.who(); r.at = U.now();
    S.log(cid + ': ' + (prev || 'open') + ' → ' + status);
    S.commit();
  };
  S.setNote = function (cid, note) { const r = S.ensureResult(cid); r.note = note; S.commit({ quiet: true }); };
  S.addEvidence = function (cid, item) {
    const r = S.ensureResult(cid);
    r.evidence.push(item);
    S.log(cid + ': evidence added (' + item.label + ', SHA-256 ' + item.sha256.slice(0, 12) + '…)');
    S.commit();
  };
  S.removeEvidence = function (cid, i) {
    const r = S.ensureResult(cid);
    const it = r.evidence.splice(i, 1)[0];
    if (it) S.log(cid + ': evidence removed (' + it.label + ')');
    S.commit();
  };
  S.setRetention = function (sid, field, value) {
    const r = S.eng.retention[sid] || (S.eng.retention[sid] = {});
    r[field] = value; r.src = 'manual';
    if ((r.days === '' || r.days == null) && !r.oldest) delete S.eng.retention[sid];
    S.commit({ quiet: true });
  };
  S.toggleRunbook = function (id) {
    S.eng.runbook[id] = !S.eng.runbook[id];
    S.commit();
  };

  root.AIFR.store = S;
})(typeof window !== 'undefined' ? window : globalThis);
